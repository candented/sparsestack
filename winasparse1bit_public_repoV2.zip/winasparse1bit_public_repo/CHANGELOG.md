# Changelog

All notable changes to the WINASPARSE1BIT public repository are documented
here. The format follows [Keep a Changelog](https://keepachangelog.com/),
and the project uses [Semantic Versioning](https://semver.org/).

---

## [v2-preprint-2026-06] — 2026-06-08

This release accompanies version 2 of the preprint
(`docs/WINASPARSE1BIT_arxiv_v2.pdf`, 37 pages, June 2026), which
supersedes the March 2026 v1 draft archived at
`docs/archive/WINASPARSE1BIT_paper_v1.tex`.

### Added

#### Causal language-model track (Phase 15)

- `sparse_llm/causal_transformer.py` — `CausalSparseTransformer`, a causal
  autoregressive variant reusing `LowBitLinear` and `WINA_MLP`. Adds
  rotary position embeddings (RoPE), causal attention masking,
  per-position LM head, and optional weight tying.
- `train_lm.py` — supervised language-model training (single-GPU and DDP)
  with the new **config-gated sparse-mode resolver** (`lm.sparse` block).
  Defaults preserve the legacy `mode="dense"` behaviour so prior Phase 15
  presets are unaffected.
- `eval_lm.py` — perplexity, accuracy, and sparsity-aware evaluation for
  causal LM checkpoints.
- `generate.py` — text-generation utility for sampling from a trained LM
  checkpoint in any of the three sparsity modes.
- `load_checkpoint.py` — checkpoint loader that re-instantiates the model
  from the saved `model_info.json` shape.
- Phase 15A / 15B / 15C presets in `config/global_params.yaml`
  (TinyStories proof-of-concept, full TinyStories, OpenWebText paper run).
- `phase15a_tinystories_poc_sparse` preset that explicitly opts into
  sparse-mode LM training.

#### Auto-phase methodology

- `auto_phase.py` — Tier-A automated hyperparameter sweep over
  `lambda_final`, `entropy_bonus`, `learning_rate`, and
  `acc_penalty_scale`. Config-only overrides, journal at
  `logs/auto_phase/journal.jsonl`.
- `auto_phase_transfer.py` — transfer-aware variant that scores each
  configuration by 0.4·acc_source + 0.6·acc_transfer. Produces the
  **iter7_hifi** tuned baseline (math-CoT 95.6% acc, 7.3% FLOPs,
  +0.48 trace-utilisation delta).

#### Cross-task circuit transfer

- `cross_task_transfer.py` — three-arm ablation (baseline / frozen /
  free) for testing whether a converged sparse circuit transfers to a
  new task with the connectivity mask held fixed. Demonstrates the
  math-CoT → FLD topology transfer at ~33% lower FLOPs at equal accuracy.

#### Mechanistic interpretability

- `mech_interp.py` — cross-seed circuit overlap analysis (top-k weight
  IoU). Reports the v2 null result: circuits across seeds are
  indistinguishable from random under index-aware overlap.

#### Hybrid architecture

- `sparse_llm/hybrid.py` — `HybridStack` Sparse-Dense-Sparse sandwich
  used in the Phase 10 Track 3 equivalence experiment.

#### Datasets module

- `sparse_llm/datasets/` — restructured dataset loaders for
  lexical reasoning, formal logic deduction (FLD), math chain-of-thought
  verification, and causal LM (TinyStories / OpenWebText). Includes
  `lm_dataset.py` with `ChunkedLMDataset` and `StreamingLMDataset`.

#### Verifiers

- `verifiers/` — `LogicalChecker`, `OCTManifold`, `SymbolicChecker` for
  task-level outcome verification.

#### Tests

- `tests/test_causal_transformer.py`, `test_hybrid_architecture.py`,
  `test_parity_cot.py`, `test_phase13_datasets.py`,
  `test_lexical_real.py`, `test_masks_and_flops.py`,
  `test_reward_fn.py`, `test_smoke_easy.py`,
  `test_symbolic_checker.py`. The existing
  `test_baseline_behavior.py` is retained as the v0.2 regression shield.

#### Documentation

- `docs/WINASPARSE1BIT_arxiv_v2.tex` + `.pdf` — the v2 preprint (37 pages).
- `docs/compile_preprint.sh` — reusable compile script (locates pdflatex
  on PATH or in known MiKTeX install paths, configures unattended
  package installation, runs two pdflatex passes, places PDF next to
  source).
- `.zenodo.json` — Zenodo deposit metadata (title, authors, keywords,
  description, license, related identifiers).
- `CITATION.cff` — GitHub / Zenodo citation widget metadata.
- This `CHANGELOG.md`.

### Changed

- `config/global_params.yaml` — refreshed with the full v2 preset library
  including Phase 13 FLD presets, Phase 14B math-verification presets,
  Phase 15 LM presets, and the `phase15a_tinystories_poc_sparse` opt-in.
- `sparse_llm/__init__.py` — exports `CausalSparseTransformer` and
  `HybridStack` alongside the existing public API.
- `README.md` — overhauled to reflect v2 findings, results tables, and
  the LM track.
- `FILE_MANIFEST.md` — updated to enumerate the v2 file set.
- `REPOSITORY_INFO.md` — updated with Zenodo workflow notes.
- `requirements.txt` — adds `tiktoken`, `datasets`, `cryptography`
  (tooling) and `tqdm` dependencies for the LM track.

### Fixed

- **Long-standing LM training-loop bypass.** Prior versions of
  `train_lm.py` (predating this release) hard-coded `mode="dense"` on
  both the training forward pass (line 426) and the evaluation forward
  pass (line 543) regardless of any sparse configuration. This meant
  every Phase 15 run trained a dense GPT-style baseline despite the
  architecture supporting three sparse modes. The June 2026 fix
  introduces a config-gated `resolve_lm_sparse_cfg()` resolver and
  surfaces the resolved mode in the startup log line
  (`LM sparse: enabled=… train_mode=… eval_mode=…`). Existing v1-era
  presets without an `lm.sparse` block are byte-identical in behaviour.

### Notes on open items (carried over from v1)

- **Phase 14B winner-rerun failure.** The math-verification 3-GPU sweep
  produced single-seed candidates above the 70% promotion threshold but
  the winner rerun did not reproduce. Root cause unresolved; documented
  in the v2 preprint §6.8.
- **iter7_hifi is single-seed.** Multi-seed validation across
  {42, 43, 101, 777} is the prerequisite to promoting the configuration
  to a frozen preset (`model_zero_math_v2_tuned`).
- **No scale LM result yet.** Phase 15 smoke is functional; full-scale
  TinyStories / OpenWebText runs are planned but not in v2.
- **Cross-seed circuit non-canonicality.** Index-aware top-k IoU is at
  random baseline. Permutation-aware similarity is an open analysis.

---

## [v1-paper-2026-01] — 2026-01-29

Initial public release accompanying the v1 paper draft
(`docs/archive/WINASPARSE1BIT_paper_v1.tex`).

### Included

- `sparse_llm/` — `LowBitLinear`, `WINA_MLP`, `SparseTransformer`,
  `TinyTransformer` (dense baseline), masks and utilities.
- `rl/` — REINFORCE controller, environment, action grid, reward
  function with lambda annealing, policy network.
- `config/global_params.yaml` — Phase 7 / 8 / 9a presets.
- `tools/generate_lexical_deep.py` — WordNet-derived dataset generator.
- `main.py` — classification training entry point.
- `docs/WINASPARSE1BIT_paper.tex` — v1 paper source (now archived).
- `README.md`, `FILE_MANIFEST.md`, `REPOSITORY_INFO.md`, MIT `LICENSE`.

### Headline results (preserved through v2)

- Phase 8 Model Zero (dim=256): 78.91% acc / 0.066 FLOPs / 88.4%
  connectivity sparsity, multi-seed across {42, 101, 777, 999}.
- 15.2× efficiency vs dense float32 baseline; +6.71% absolute accuracy.

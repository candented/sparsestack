"""Transfer-optimized autoresearch loop (C1).

Extends auto_phase.py with a two-phase per-iteration evaluation:

  Phase A: train math_cot for 2500 steps with the proposed config.
           Archive the final checkpoint.
  Phase B: frozen-circuit transfer to FLD-no-trace for 1500 steps using
           the Phase-A checkpoint. Parse transfer accuracy.

Composite = 0.4 * acc_math_cot + 0.6 * acc_fld_no_trace_frozen

Goal: find configs whose discovered circuits transfer fully (close acc on
both tasks), not just configs that maximize math_cot in isolation. Direct
response to the partial-transfer finding from rev_1.

Usage:
    python auto_phase_transfer.py --iterations 12
    python auto_phase_transfer.py --report
"""

from __future__ import annotations

import argparse
import json
import random
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from auto_phase import (
    SEARCH_AXES,
    config_key,
    sample_config,
    parse_log,
)

JOURNAL_PATH = ROOT / "logs" / "auto_phase_transfer" / "journal.jsonl"
RUN_LOG_DIR = ROOT / "logs" / "auto_phase_transfer" / "runs"
SOURCE_CKPT_BASE = ROOT / "checkpoints" / "auto_phase_transfer"

SOURCE_PRESET = "model_zero_math_v1"
TRANSFER_PRESET = "fld_mixed_v1"
DEFAULT_SOURCE_STEPS = 2500
DEFAULT_TRANSFER_STEPS = 1500
DEFAULT_SEED = 42

# Composite weights -- bias toward transfer to find genuinely general configs
W_SOURCE = 0.4
W_TRANSFER = 0.6


def load_journal() -> list[dict]:
    if not JOURNAL_PATH.exists():
        return []
    with open(JOURNAL_PATH, "r") as f:
        return [json.loads(line) for line in f if line.strip()]


def append_journal(entry: dict) -> None:
    JOURNAL_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(JOURNAL_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")


def composite_transfer_score(metrics_a: dict | None, metrics_b: dict | None) -> tuple[float, dict]:
    """Composite favoring transfer accuracy over source accuracy."""
    if metrics_a is None or metrics_b is None:
        return -1e9, {"reason": "parse_failed"}
    acc_a = metrics_a.get("acc", 0.0)
    acc_b = metrics_b.get("acc", 0.0)
    score = W_SOURCE * acc_a + W_TRANSFER * acc_b
    return score, {"acc_source": acc_a, "acc_transfer": acc_b, "weighted": score}


def archive_source_ckpt(seed: int, iter_idx: int) -> Path:
    """Move the just-saved source checkpoint into a per-iter archive path."""
    src_dir = ROOT / "checkpoints" / SOURCE_PRESET / f"seed{seed}" / "final"
    if not src_dir.exists():
        raise RuntimeError(f"Phase A checkpoint not found at {src_dir}")
    archive_dir = SOURCE_CKPT_BASE / f"iter_{iter_idx:03d}_seed_{seed}"
    archive_dir.mkdir(parents=True, exist_ok=True)
    archive_ckpt = archive_dir / "checkpoint.pt"
    if archive_ckpt.exists():
        archive_ckpt.unlink()
    # Move (faster than copy for ~50 MB ckpts)
    shutil.copy2(src_dir / "checkpoint.pt", archive_ckpt)
    # Also copy config files for reference
    for fname in ("config.json", "model_info.json"):
        src_file = src_dir / fname
        if src_file.exists():
            shutil.copy2(src_file, archive_dir / fname)
    return archive_ckpt


def run_phase_a(config: dict, seed: int, iter_idx: int) -> tuple[dict | None, Path, int]:
    """Run source-task training and archive the resulting checkpoint."""
    overrides = [f"{k}={v}" for k, v in config.items()]
    overrides += [
        f"training.seed={seed}",
        f"annealing.total_steps={DEFAULT_SOURCE_STEPS}",
        "training.summary_log_steps=500",
        "training.save_checkpoints=true",  # Need final ckpt for Phase B
        "training.checkpoint_interval=99999",  # Skip periodic, only final
        "training.debug_scan_actions=false",
        "training.debug_prediction_delta=false",
    ]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = RUN_LOG_DIR / f"iter{iter_idx:03d}_seed{seed}_phaseA_{timestamp}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, "main.py", f"preset={SOURCE_PRESET}", "training.device=cuda"] + overrides
    print(f"[XFER_AP]   PhaseA: {' '.join(overrides[:4])} ...")
    with open(log_path, "w") as f:
        proc = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, cwd=str(ROOT))
    metrics = parse_log(log_path)
    return metrics, log_path, proc.returncode


def run_phase_b(source_ckpt: Path, seed: int, iter_idx: int) -> tuple[dict | None, Path, int]:
    """Run frozen-circuit transfer to FLD-no-trace using Phase-A checkpoint."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = RUN_LOG_DIR / f"iter{iter_idx:03d}_seed{seed}_phaseB_{timestamp}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    rel_ckpt = source_ckpt.relative_to(ROOT)
    cmd = [
        sys.executable, "cross_task_transfer.py",
        "--mode", "frozen",
        "--source-ckpt", str(rel_ckpt),
        "--target-preset", TRANSFER_PRESET,
        "--seed", str(seed),
        "--steps", str(DEFAULT_TRANSFER_STEPS),
        "--summary-log-steps", "500",
        "--fld-no-trace",
    ]
    print(f"[XFER_AP]   PhaseB: source={rel_ckpt}")
    with open(log_path, "w") as f:
        proc = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, cwd=str(ROOT))
    metrics = parse_log(log_path)
    return metrics, log_path, proc.returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--iterations", type=int, default=12)
    ap.add_argument("--seed", type=int, default=DEFAULT_SEED)
    ap.add_argument("--rng-seed", type=int, default=0)
    ap.add_argument("--report", action="store_true")
    ap.add_argument("--top", type=int, default=10)
    args = ap.parse_args()

    history = load_journal()

    if args.report:
        report(history, args.top)
        return

    rng = random.Random(args.rng_seed)
    print(f"[XFER_AP] journal has {len(history)} prior runs")
    if history:
        best = max(history, key=lambda h: h.get("composite", -1e9))
        print(f"[XFER_AP] current best: composite={best['composite']:.4f} "
              f"acc_src={best['phase_a_metrics']['acc']:.4f} "
              f"acc_xfer={best['phase_b_metrics']['acc']:.4f}")

    for it in range(args.iterations):
        config = sample_config(history, rng)
        if config is None:
            print("[XFER_AP] search space exhausted")
            break
        iter_idx = len(history) + 1
        print(f"\n[XFER_AP] iter {it + 1}/{args.iterations} (global {iter_idx}) seed={args.seed}")
        print(f"[XFER_AP]   config={config}")

        t0 = time.time()
        # Phase A
        m_a, log_a, rc_a = run_phase_a(config, args.seed, iter_idx)
        if m_a is None or rc_a != 0:
            print(f"[XFER_AP]   PhaseA FAILED rc={rc_a}, skipping iter")
            entry = {
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "iteration": iter_idx,
                "seed": args.seed,
                "config": config,
                "phase_a_metrics": m_a,
                "phase_b_metrics": None,
                "composite": -1e9,
                "log_phase_a": str(log_a.relative_to(ROOT)),
                "log_phase_b": None,
                "elapsed_sec": round(time.time() - t0, 1),
                "phase_a_rc": rc_a,
            }
            history.append(entry)
            append_journal(entry)
            continue

        # Archive checkpoint
        try:
            archived_ckpt = archive_source_ckpt(args.seed, iter_idx)
        except RuntimeError as e:
            print(f"[XFER_AP]   archive failed: {e}")
            continue

        # Phase B
        m_b, log_b, rc_b = run_phase_b(archived_ckpt, args.seed, iter_idx)

        score, score_breakdown = composite_transfer_score(m_a, m_b)
        elapsed = time.time() - t0

        entry = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "iteration": iter_idx,
            "seed": args.seed,
            "config": config,
            "phase_a_metrics": m_a,
            "phase_b_metrics": m_b,
            "composite": score,
            "score_breakdown": score_breakdown,
            "log_phase_a": str(log_a.relative_to(ROOT)),
            "log_phase_b": str(log_b.relative_to(ROOT)),
            "archived_ckpt": str(archived_ckpt.relative_to(ROOT)),
            "elapsed_sec": round(elapsed, 1),
            "phase_a_rc": rc_a,
            "phase_b_rc": rc_b,
        }
        history.append(entry)
        append_journal(entry)

        if m_a and m_b:
            print(f"[XFER_AP]   acc_src={m_a['acc']:.4f} acc_xfer={m_b['acc']:.4f} "
                  f"composite={score:.4f} ({elapsed:.0f}s)")
        else:
            print(f"[XFER_AP]   PARSE FAILED rc_a={rc_a} rc_b={rc_b}")

    print("\n" + "=" * 70)
    report(history, args.top)


def report(history: list[dict], top: int) -> None:
    if not history:
        print("[XFER_AP] journal empty")
        return
    valid = [h for h in history if h.get("phase_b_metrics") is not None]
    print(f"[XFER_AP] {len(valid)} valid runs out of {len(history)} total")
    valid.sort(key=lambda h: -h["composite"])
    print(f"\n[XFER_AP] top {min(top, len(valid))} configs by composite (0.4*acc_src + 0.6*acc_xfer):")
    for rank, h in enumerate(valid[:top], 1):
        a = h["phase_a_metrics"]["acc"]
        b = h["phase_b_metrics"]["acc"]
        gap = a - b
        print(f"  {rank:2d}. composite={h['composite']:.4f}  "
              f"acc_src={a:.4f}  acc_xfer={b:.4f}  gap={gap:+.4f}  iter={h['iteration']}")
        print(f"      config: {h['config']}")


if __name__ == "__main__":
    main()

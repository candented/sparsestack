"""Mechanistic interpretability of converged sparse circuits.

Loads checkpoints from rank4 seeds 42/43 (final + temporal snapshots) and
compares the persisted connectivity masks (`mask` buffers on LowBitLinear
layers) to answer:

    Q1. Did different seeds converge on the same pruned weights?
        -> Cross-seed mask IoU vs random-baseline IoU, per layer.

    Q2. When during training did the circuit stabilize?
        -> Within-seed cross-step mask IoU at 2500/5000/7500/10000.

    Q3. Are surviving weights functionally distinct from pruned weights?
        -> Magnitude distribution of |W| split by mask=1 vs mask=0.

Outputs: prints + heatmap PNGs under logs/mech_interp/.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch

ROOT = Path(__file__).parent
CKPT_BASE = ROOT / "checkpoints" / "model_zero_math_v1"
OUT_DIR = ROOT / "logs" / "mech_interp"

# Layers to analyze (sparse fc layers in the 2-block sparse_transformer)
SPARSE_LAYERS = [
    "blocks.0.mlp.fc1",
    "blocks.0.mlp.fc2",
    "blocks.1.mlp.fc1",
    "blocks.1.mlp.fc2",
]

STEP_TAGS = ["step_2500", "step_5000", "step_7500", "step_10000", "final"]
SEEDS = [42, 43]


def load_state(seed: int, tag: str) -> Dict[str, torch.Tensor] | None:
    p = CKPT_BASE / f"seed{seed}" / tag / "checkpoint.pt"
    if not p.exists():
        return None
    ckpt = torch.load(p, map_location="cpu", weights_only=False)
    return ckpt["model_state_dict"]


def get_mask(state: Dict[str, torch.Tensor], layer: str) -> torch.Tensor:
    """Return the converged connectivity mask (boolean: True = active).

    NOTE: Uses `runtime_mask`, the buffer that holds the tau-driven mask from
    the last forward pass. The static `mask` buffer is the user-set circuit
    override (default all-ones); RL-driven pruning is recorded in `runtime_mask`.
    """
    return state[f"{layer}.runtime_mask"].bool()


def get_weight(state: Dict[str, torch.Tensor], layer: str) -> torch.Tensor:
    return state[f"{layer}.weight"]


def topk_weight_mask(state: Dict[str, torch.Tensor], layer: str, k_frac: float) -> torch.Tensor:
    """Return a boolean mask of the top-k_frac weights by absolute magnitude.

    Threshold-independent measure of 'which weights matter most.' Compared
    across seeds, this directly tests whether the same weights ranked highest
    in both runs -- a stronger structural-circuit test than runtime_mask IoU.
    """
    w = state[f"{layer}.weight"].abs().flatten()
    n_keep = int(round(k_frac * w.numel()))
    if n_keep <= 0:
        return torch.zeros_like(w, dtype=torch.bool).reshape(state[f"{layer}.weight"].shape)
    threshold = torch.kthvalue(w, w.numel() - n_keep + 1).values
    mask = (state[f"{layer}.weight"].abs() >= threshold)
    return mask


def mask_iou(m1: torch.Tensor, m2: torch.Tensor) -> float:
    """Jaccard on KILLED weights (mask=0)."""
    k1 = ~m1
    k2 = ~m2
    inter = (k1 & k2).sum().item()
    union = (k1 | k2).sum().item()
    return inter / max(1, union)


def random_baseline_iou(m1: torch.Tensor, m2: torch.Tensor, n_trials: int = 50) -> float:
    """Mean IoU when both masks are reshuffled to same density. Tight CI."""
    rng = np.random.default_rng(0)
    n = m1.numel()
    n_kill_1 = int((~m1).sum().item())
    n_kill_2 = int((~m2).sum().item())
    ious = []
    for _ in range(n_trials):
        s1 = np.zeros(n, dtype=bool)
        s2 = np.zeros(n, dtype=bool)
        s1[rng.choice(n, n_kill_1, replace=False)] = True  # killed positions
        s2[rng.choice(n, n_kill_2, replace=False)] = True
        inter = (s1 & s2).sum()
        union = (s1 | s2).sum()
        ious.append(inter / max(1, union))
    return float(np.mean(ious)), float(np.std(ious))


def q1_cross_seed(final_states: Dict[int, Dict]) -> List[dict]:
    """Cross-seed mask overlap at converged (final) checkpoints."""
    rows = []
    s42 = final_states[42]
    s43 = final_states[43]
    print("\n=== Q1: Cross-seed circuit overlap (final checkpoints) ===")
    print(f"{'layer':<22} {'shape':<14} {'sparsity_42':>11} {'sparsity_43':>11} "
          f"{'IoU_kill':>9} {'rand_IoU':>9}  z-score")
    for layer in SPARSE_LAYERS:
        m42 = get_mask(s42, layer)
        m43 = get_mask(s43, layer)
        s42_sp = float((~m42).float().mean())
        s43_sp = float((~m43).float().mean())
        observed = mask_iou(m42, m43)
        rand_mean, rand_std = random_baseline_iou(m42, m43)
        z = (observed - rand_mean) / max(rand_std, 1e-9)
        print(f"{layer:<22} {str(tuple(m42.shape)):<14} "
              f"{s42_sp:>11.4f} {s43_sp:>11.4f} {observed:>9.4f} {rand_mean:>9.4f}  {z:+.2f}")
        rows.append({
            "layer": layer,
            "shape": list(m42.shape),
            "sparsity_seed42": s42_sp,
            "sparsity_seed43": s43_sp,
            "kill_iou": observed,
            "random_iou_mean": rand_mean,
            "random_iou_std": rand_std,
            "z_score": z,
        })
    return rows


def q2_temporal_stability(seed: int) -> List[dict]:
    """Within-seed cross-step IoU. Tracks when the circuit stabilizes."""
    rows = []
    states = {tag: load_state(seed, tag) for tag in STEP_TAGS}
    states = {k: v for k, v in states.items() if v is not None}
    tags = list(states.keys())
    print(f"\n=== Q2: Temporal stability, seed={seed} (kill-mask IoU between checkpoint pairs) ===")
    header = "from\\to        " + "  ".join(f"{t:>10}" for t in tags)
    print(header)
    for i, ti in enumerate(tags):
        line = f"{ti:<14}  "
        for j, tj in enumerate(tags):
            if i >= j:
                line += "       -    "
                continue
            ious = []
            for layer in SPARSE_LAYERS:
                ious.append(mask_iou(get_mask(states[ti], layer), get_mask(states[tj], layer)))
            mean_iou = float(np.mean(ious))
            line += f"  {mean_iou:>10.4f}"
            rows.append({"seed": seed, "from": ti, "to": tj, "mean_iou": mean_iou})
        print(line)
    return rows


def q3_weight_magnitudes(final_states: Dict[int, Dict]) -> List[dict]:
    """Are pruned weights smaller in magnitude than surviving weights?"""
    rows = []
    print("\n=== Q3: Weight magnitude distribution by mask state ===")
    print(f"{'layer':<22} {'seed':<5} {'|W| killed (med)':>17} "
          f"{'|W| alive (med)':>17} {'sep_ratio':>10}")
    for seed in SEEDS:
        st = final_states[seed]
        for layer in SPARSE_LAYERS:
            m = get_mask(st, layer)
            w = get_weight(st, layer).abs()
            killed = w[~m]
            alive = w[m]
            med_kill = float(killed.median()) if killed.numel() > 0 else 0.0
            med_alive = float(alive.median()) if alive.numel() > 0 else 0.0
            sep = (med_alive / max(med_kill, 1e-9)) if med_kill > 0 else float("inf")
            print(f"{layer:<22} {seed:<5} {med_kill:>17.6f} {med_alive:>17.6f} {sep:>10.2f}x")
            rows.append({
                "seed": seed, "layer": layer,
                "median_killed_magnitude": med_kill,
                "median_alive_magnitude": med_alive,
                "separation_ratio": sep,
            })
    return rows


def q4_kill_frequency_map(final_states: Dict[int, Dict]) -> Dict:
    """For each layer, count how many seeds killed each (out, in) cell.

    Returns kill_freq tensor in {0, 1, 2}: 0 = neither, 1 = one of two, 2 = both.
    Also computes 'consensus_kill_rate' = fraction with freq==2.
    """
    summary = []
    print("\n=== Q4: Per-cell kill frequency (consensus across seeds) ===")
    print(f"{'layer':<22} {'cells':>10} {'freq=0':>10} {'freq=1':>10} {'freq=2':>10} "
          f"{'consensus_rate':>15}")
    for layer in SPARSE_LAYERS:
        m42 = ~get_mask(final_states[42], layer)  # killed = True
        m43 = ~get_mask(final_states[43], layer)
        freq = (m42.int() + m43.int())  # values 0..2
        flat = freq.flatten()
        c0 = int((flat == 0).sum())
        c1 = int((flat == 1).sum())
        c2 = int((flat == 2).sum())
        total = flat.numel()
        consensus = c2 / max(1, total)
        print(f"{layer:<22} {total:>10} {c0:>10} {c1:>10} {c2:>10} {consensus:>15.4f}")
        summary.append({
            "layer": layer,
            "cells_total": total,
            "freq_0": c0,
            "freq_1": c1,
            "freq_2": c2,
            "consensus_rate": consensus,
        })
        # Save raw freq tensor for downstream visualization
        np.save(OUT_DIR / f"killfreq_{layer.replace('.', '_')}.npy", freq.numpy())
    return summary


def q5_topk_weight_overlap(final_states: Dict[int, Dict]) -> List[dict]:
    """Threshold-independent test: do the top-k% weights by magnitude
    overlap across seeds? If yes, both runs identified the same set of
    weights as 'important' independent of any pruning decision."""
    rows = []
    print("\n=== Q5: Top-k weight overlap (magnitude-ranked, threshold-independent) ===")
    print(f"{'layer':<22} {'k_frac':>8} {'IoU(top-k)':>12} {'rand_IoU':>10} {'z-score':>10}")
    for k_frac in [0.10, 0.25, 0.50]:
        for layer in SPARSE_LAYERS:
            m42 = topk_weight_mask(final_states[42], layer, k_frac)
            m43 = topk_weight_mask(final_states[43], layer, k_frac)
            inter = (m42 & m43).sum().item()
            union = (m42 | m43).sum().item()
            iou = inter / max(1, union)
            # Random baseline: two random samples of same size
            n = m42.numel()
            n_keep = int(round(k_frac * n))
            # IoU of two iid Bernoulli(p) samples: p / (2-p) for p = n_keep/n
            p = n_keep / n
            rand_iou = p / (2 - p)
            # std of random IoU (close form is messy; use empirical proxy from n)
            # Approximation: var(IoU) ~ p(1-p)(2-p)^(-2) / n_keep -- conservative
            rand_std = ((p * (1 - p)) ** 0.5 / max(1, n_keep) ** 0.5) / (2 - p)
            z = (iou - rand_iou) / max(rand_std, 1e-9)
            print(f"{layer:<22} {k_frac:>8.2f} {iou:>12.4f} {rand_iou:>10.4f} {z:>+10.2f}")
            rows.append({
                "layer": layer, "k_frac": k_frac,
                "topk_iou": iou, "random_iou": rand_iou, "z_score": z,
            })
    return rows


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Output dir: {OUT_DIR}")

    # Load final states for both seeds
    final_states = {}
    for seed in SEEDS:
        st = load_state(seed, "final")
        if st is None:
            raise SystemExit(f"Missing final checkpoint for seed={seed}")
        final_states[seed] = st

    print(f"\nLoaded final checkpoints for seeds {SEEDS}")
    print(f"Sparse layers analyzed: {SPARSE_LAYERS}")

    q1_rows = q1_cross_seed(final_states)
    q2_rows = q2_temporal_stability(42) + q2_temporal_stability(43)
    q3_rows = q3_weight_magnitudes(final_states)
    q4_rows = q4_kill_frequency_map(final_states)
    q5_rows = q5_topk_weight_overlap(final_states)

    # Persist all results as JSON
    out_json = OUT_DIR / "results.json"
    with open(out_json, "w") as f:
        json.dump({
            "q1_cross_seed_iou": q1_rows,
            "q2_temporal_stability": q2_rows,
            "q3_weight_magnitudes": q3_rows,
            "q4_kill_frequency": q4_rows,
            "q5_topk_weight_overlap": q5_rows,
        }, f, indent=2)
    print(f"\nResults written to {out_json}")
    print(f"Kill-frequency tensors saved as .npy in {OUT_DIR}")


if __name__ == "__main__":
    main()

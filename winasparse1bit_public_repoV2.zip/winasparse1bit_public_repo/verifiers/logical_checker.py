"""
LogicalChecker - Ground-truth verification for logical reasoning tasks.

Extends verification capabilities for Phase 11 LADDER integration.
Provides proof traces for implication chains, recursive parity, and SAT-lite tasks.
"""

from __future__ import annotations

import random
from typing import Dict, List, Tuple, Optional

import torch


class LogicalChecker:
    """
    Verifier for logical reasoning tasks.

    Supports:
    - ImplicationChecker: Validates transitivity chains
    - RecursiveParityChecker: Validates nested XOR
    - SATChecker: Validates satisfiability claims

    Integrates with LADDER for self-improvement training data generation.
    """

    def __init__(self, vocab_size: int, seq_len: int) -> None:
        self.vocab_size = max(1, int(vocab_size))
        self.seq_len = max(1, int(seq_len))

        # Token mapping (mirrors LogicalDataset)
        self._build_token_map()

    def _build_token_map(self) -> None:
        """Build token indices for logical symbols."""
        self.special_start = 4
        self.var_tokens = {chr(65 + i): self.special_start + i for i in range(26)}
        self.op_base = 30
        self.token_map = {
            '>': self.op_base,
            '&': self.op_base + 1,
            '|': self.op_base + 2,
            '~': self.op_base + 3,
            'T': self.op_base + 4,
            'F': self.op_base + 5,
            ':': self.op_base + 6,
            '?': self.op_base + 7,
            ' ': self.op_base + 8,
            '^': self.op_base + 9,
            '(': self.op_base + 10,
            ')': self.op_base + 11,
            '0': self.op_base + 12,
            '1': self.op_base + 13,
            '=': self.op_base + 14,
            'S': self.op_base + 15,
            '[TRACE]': self.op_base + 16,
            '[END]': self.op_base + 17,
            '[STEP]': self.op_base + 18,
        }

    def build_batch(
        self,
        task_spec: Dict[str, object],
        batch_size: int,
        device: torch.device,
        hard_mode: bool = False,
        difficulty: str | None = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Build batch following SymbolicChecker contract.

        task_spec keys:
        - checker: "ImplicationChecker" | "RecursiveParityChecker" | "SATChecker"
        - chain_depth: int (for implication)
        - recursive_steps: int (for parity)
        - num_clauses, num_vars: int (for SAT)
        """
        verifier_spec = task_spec.get("verifier_spec", {}) or {}
        checker = verifier_spec.get("checker", "ImplicationChecker")

        # Get difficulty-adjusted parameters
        effective_hard = hard_mode or (difficulty == "hard")
        params = self._get_params(verifier_spec, effective_hard)

        if checker == "ImplicationChecker":
            return self._build_implication_batch(params, batch_size, device)
        elif checker == "RecursiveParityChecker":
            return self._build_parity_batch(params, batch_size, device)
        elif checker == "ParityCotChecker":
            return self._build_parity_cot_batch(params, batch_size, device)
        elif checker == "SATChecker":
            return self._build_sat_batch(params, batch_size, device)
        else:
            raise ValueError(f"Unknown logical checker: {checker}")

    def _get_params(self, verifier_spec: Dict, hard_mode: bool) -> Dict:
        """Extract and adjust parameters based on difficulty."""
        params = {
            "chain_depth": int(verifier_spec.get("chain_depth", 3)),
            "recursive_steps": int(verifier_spec.get("recursive_steps", 2)),
            "num_clauses": int(verifier_spec.get("num_clauses", 3)),
            "num_vars": int(verifier_spec.get("num_vars", 4)),
        }

        if hard_mode:
            params["chain_depth"] = min(6, params["chain_depth"] + 2)
            params["recursive_steps"] = min(4, params["recursive_steps"] + 1)
            params["num_clauses"] = min(5, params["num_clauses"] + 1)

        return params

    # =========================================================================
    # Implication Chain Generation and Verification
    # =========================================================================

    def _build_implication_batch(
        self,
        params: Dict,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate implication chain verification batch."""
        prompts: List[torch.Tensor] = []
        labels: List[int] = []

        depth = params["chain_depth"]

        for _ in range(batch_size):
            expr, label = self._sample_implication_instance(depth)
            prompts.append(self._encode_prompt(expr))
            labels.append(label)

        x = torch.stack(prompts).to(device)
        y = torch.tensor(labels, dtype=torch.long, device=device)
        return x, y

    def _sample_implication_instance(self, depth: int) -> Tuple[str, int]:
        """Generate single implication chain instance."""
        vars_list = [chr(65 + i) for i in range(depth + 1)]

        # Build chain: A->B B->C ...
        chain_parts = []
        for i in range(depth):
            chain_parts.append(f"{vars_list[i]}->{vars_list[i+1]}")

        is_positive = random.random() < 0.5

        if is_positive:
            premise = f"{vars_list[0]}:T"
            query_var = vars_list[-1]
            label = 1
        else:
            corruption = random.choice(['false_premise', 'broken_chain', 'wrong_query'])

            if corruption == 'false_premise':
                premise = f"{vars_list[0]}:F"
                query_var = vars_list[-1]
                label = 0
            elif corruption == 'broken_chain':
                break_idx = random.randint(0, depth - 1)
                new_var = chr(65 + depth + 1)
                chain_parts[break_idx] = f"{vars_list[break_idx]}->{new_var}"
                premise = f"{vars_list[0]}:T"
                query_var = vars_list[-1]
                label = 0
            else:
                premise = f"{vars_list[0]}:T"
                query_var = chr(65 + random.randint(depth + 2, min(25, depth + 5)))
                label = 0

        chain_str = " ".join(chain_parts)
        expr = f"{premise} {chain_str} ? {query_var}"

        return expr, label

    def verify_implication(
        self,
        chain: List[Tuple[str, str]],
        premise: Tuple[str, bool],
        query: str
    ) -> Tuple[bool, Dict]:
        """
        Verify implication chain and return proof trace.

        Proof trace format (for LADDER):
        {
            "chain": [(A,B), (B,C), (C,D)],
            "premise": (A, True),
            "query": D,
            "derivation": [
                {"step": 1, "apply": "A->B", "result": "B=T"},
                {"step": 2, "apply": "B->C", "result": "C=T"},
                ...
            ],
            "conclusion": True
        }
        """
        derivation = []
        current_var, current_val = premise

        # Create chain lookup
        chain_map = {src: tgt for src, tgt in chain}

        step = 1
        visited = {current_var}

        while current_var in chain_map and current_val:
            next_var = chain_map[current_var]
            if next_var in visited:
                break  # Cycle detected
            derivation.append({
                "step": step,
                "apply": f"{current_var}->{next_var}",
                "result": f"{next_var}={'T' if current_val else 'F'}"
            })
            current_var = next_var
            visited.add(current_var)
            step += 1

        conclusion = (current_var == query) and current_val

        return conclusion, {
            "chain": chain,
            "premise": premise,
            "query": query,
            "derivation": derivation,
            "conclusion": conclusion
        }

    # =========================================================================
    # Recursive Parity Generation and Verification
    # =========================================================================

    def _build_parity_batch(
        self,
        params: Dict,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate recursive parity verification batch."""
        prompts: List[torch.Tensor] = []
        labels: List[int] = []

        steps = params["recursive_steps"]

        for _ in range(batch_size):
            expr, label = self._sample_parity_instance(steps)
            prompts.append(self._encode_prompt(expr))
            labels.append(label)

        x = torch.stack(prompts).to(device)
        y = torch.tensor(labels, dtype=torch.long, device=device)
        return x, y

    def _sample_parity_instance(self, steps: int) -> Tuple[str, int]:
        """Generate single recursive parity instance."""
        num_leaves = 2 ** steps
        values = [random.randint(0, 1) for _ in range(num_leaves)]

        expr, result = self._build_nested_xor(values)
        full_expr = f"{expr}=?"

        return full_expr, result

    def _build_nested_xor(self, values: List[int]) -> Tuple[str, int]:
        """Recursively build XOR expression tree and compute result."""
        if len(values) == 1:
            return str(values[0]), values[0]

        mid = len(values) // 2
        left_expr, left_val = self._build_nested_xor(values[:mid])
        right_expr, right_val = self._build_nested_xor(values[mid:])

        result = left_val ^ right_val
        expr = f"({left_expr}^{right_expr})"
        return expr, result

    def _build_nested_xor_with_trace(self, values: List[int]) -> Tuple[str, int, List[str]]:
        """
        Recursively build XOR tree, compute result, and generate trace steps.

        Returns:
            (expression, result, trace_steps)
        """
        if len(values) == 1:
            return str(values[0]), values[0], []

        mid = len(values) // 2
        left_expr, left_val, left_trace = self._build_nested_xor_with_trace(values[:mid])
        right_expr, right_val, right_trace = self._build_nested_xor_with_trace(values[mid:])

        result = left_val ^ right_val
        expr = f"({left_expr}^{right_expr})"
        step = f"{left_val}^{right_val}={result}"
        trace = left_trace + right_trace + [step]

        return expr, result, trace

    def _build_parity_cot_batch(
        self,
        params: Dict,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate parity verification batch WITH embedded reasoning traces."""
        prompts: List[torch.Tensor] = []
        labels: List[int] = []

        steps = params["recursive_steps"]

        for _ in range(batch_size):
            num_leaves = 2 ** steps
            values = [random.randint(0, 1) for _ in range(num_leaves)]

            expr, result, trace_steps = self._build_nested_xor_with_trace(values)
            trace_str = " ".join(trace_steps)
            full_expr = f"{expr}=? [TRACE] {trace_str} [END]"

            prompts.append(self._encode_prompt(full_expr))
            labels.append(result)

        x = torch.stack(prompts).to(device)
        y = torch.tensor(labels, dtype=torch.long, device=device)
        return x, y

    def verify_parity(
        self,
        expression: str,
        claimed_result: int
    ) -> Tuple[bool, Dict]:
        """
        Verify parity expression and return evaluation trace.

        Returns trace with intermediate XOR results.
        """
        # Parse and evaluate (simplified - assumes well-formed expression)
        actual_result = self._eval_parity_expr(expression)

        return claimed_result == actual_result, {
            "expression": expression,
            "claimed": claimed_result,
            "actual": actual_result,
            "correct": claimed_result == actual_result
        }

    def _eval_parity_expr(self, expr: str) -> int:
        """Evaluate a parity expression (simplified parser)."""
        # Strip =? suffix if present
        expr = expr.replace("=?", "").strip()

        # Recursive evaluation
        return self._eval_xor_recursive(expr)

    def _eval_xor_recursive(self, s: str) -> int:
        """Recursively evaluate XOR expression."""
        s = s.strip()

        # Base case: single digit
        if s in ('0', '1'):
            return int(s)

        # Strip outer parens
        if s.startswith('(') and s.endswith(')'):
            s = s[1:-1]

        # Find the main XOR operator (not inside parens)
        depth = 0
        for i, c in enumerate(s):
            if c == '(':
                depth += 1
            elif c == ')':
                depth -= 1
            elif c == '^' and depth == 0:
                left = self._eval_xor_recursive(s[:i])
                right = self._eval_xor_recursive(s[i+1:])
                return left ^ right

        # Fallback: try as single digit
        return int(s) if s.isdigit() else 0

    # =========================================================================
    # SAT-lite Generation and Verification
    # =========================================================================

    def _build_sat_batch(
        self,
        params: Dict,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate SAT-lite verification batch."""
        prompts: List[torch.Tensor] = []
        labels: List[int] = []

        num_clauses = params["num_clauses"]
        num_vars = params["num_vars"]

        for _ in range(batch_size):
            expr, label = self._sample_sat_instance(num_clauses, num_vars)
            prompts.append(self._encode_prompt(expr))
            labels.append(label)

        x = torch.stack(prompts).to(device)
        y = torch.tensor(labels, dtype=torch.long, device=device)
        return x, y

    def _sample_sat_instance(self, num_clauses: int, num_vars: int) -> Tuple[str, int]:
        """Generate single SAT instance."""
        var_names = [chr(65 + i) for i in range(num_vars)]

        clauses = []
        clause_strs = []

        for _ in range(num_clauses):
            clause_size = random.randint(2, 3)
            used_vars = random.sample(var_names, min(clause_size, len(var_names)))

            literals = []
            literal_strs = []
            for var in used_vars:
                negated = random.random() < 0.5
                if negated:
                    literals.append((var, True))
                    literal_strs.append(f"~{var}")
                else:
                    literals.append((var, False))
                    literal_strs.append(var)

            clauses.append(literals)
            clause_strs.append("(" + "|".join(literal_strs) + ")")

        formula_str = "&".join(clause_strs)
        is_sat = self._check_sat(clauses, var_names)

        return f"{formula_str} S?", 1 if is_sat else 0

    def _check_sat(self, clauses: List[List[Tuple[str, bool]]], var_names: List[str]) -> bool:
        """Brute-force SAT check."""
        for assignment in range(2 ** len(var_names)):
            values = {var: bool((assignment >> i) & 1) for i, var in enumerate(var_names)}

            if self._eval_cnf(clauses, values):
                return True
        return False

    def _eval_cnf(self, clauses: List[List[Tuple[str, bool]]], values: Dict[str, bool]) -> bool:
        """Evaluate CNF formula under assignment."""
        for clause in clauses:
            clause_sat = False
            for var, is_negated in clause:
                val = values.get(var, False)
                if is_negated:
                    val = not val
                if val:
                    clause_sat = True
                    break
            if not clause_sat:
                return False
        return True

    def verify_sat(
        self,
        clauses: List[List[Tuple[str, bool]]],
        var_names: List[str],
        claimed_sat: bool
    ) -> Tuple[bool, Dict]:
        """
        Verify SAT claim and return satisfying assignment if exists.
        """
        actual_sat = self._check_sat(clauses, var_names)

        # Find satisfying assignment if SAT
        satisfying_assignment = None
        if actual_sat:
            for assignment in range(2 ** len(var_names)):
                values = {var: bool((assignment >> i) & 1) for i, var in enumerate(var_names)}
                if self._eval_cnf(clauses, values):
                    satisfying_assignment = values
                    break

        return claimed_sat == actual_sat, {
            "clauses": clauses,
            "claimed_sat": claimed_sat,
            "actual_sat": actual_sat,
            "satisfying_assignment": satisfying_assignment,
            "correct": claimed_sat == actual_sat
        }

    # =========================================================================
    # Encoding
    # =========================================================================

    def _encode_prompt(self, prompt: str) -> torch.Tensor:
        """Encode prompt string to token tensor."""
        tokens = []
        i = 0
        while i < len(prompt):
            char = prompt[i]

            # Check for multi-char tokens first
            if prompt[i:i+7] == '[TRACE]':
                tokens.append(self.token_map['[TRACE]'])
                i += 7
                continue
            if prompt[i:i+5] == '[END]':
                tokens.append(self.token_map['[END]'])
                i += 5
                continue
            if prompt[i:i+6] == '[STEP]':
                tokens.append(self.token_map['[STEP]'])
                i += 6
                continue

            # Two-char operators
            if i < len(prompt) - 1 and prompt[i:i+2] == '->':
                tokens.append(self.token_map['>'])
                i += 2
                continue

            # Variables
            if char in self.var_tokens:
                tokens.append(self.var_tokens[char])
            elif char in self.token_map:
                tokens.append(self.token_map[char])
            else:
                idx = self.special_start + (ord(char) % (self.vocab_size - self.special_start))
                tokens.append(min(idx, self.vocab_size - 1))

            i += 1

        # Pad/truncate to seq_len
        tokens = tokens[:self.seq_len]
        if len(tokens) < self.seq_len:
            tokens.extend([0] * (self.seq_len - len(tokens)))

        return torch.tensor(tokens, dtype=torch.long)

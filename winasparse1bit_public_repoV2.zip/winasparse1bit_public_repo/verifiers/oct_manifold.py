from __future__ import annotations

import torch
from typing import Tuple, Dict


def build_oct_batch(
    batch_size: int,
    dim: int = 128,
    difficulty: str = "hard",
    device: torch.device | None = None,
    noise_std: float | None = None,
) -> Tuple[torch.Tensor, torch.Tensor, Dict[str, float]]:
    if dim % 2 != 0:
        raise ValueError("OCT manifold requires even dim")
    dev = device or torch.device("cpu")
    half = dim // 2
    noise = 0.01 if noise_std is None else noise_std
    if difficulty == "hard":
        noise = max(noise, 0.02)
    elif difficulty != "medium":
        raise ValueError(f"Unsupported difficulty for oct: {difficulty}")

    base = torch.randn(batch_size, dim, device=dev)
    base = base / (base.norm(dim=-1, keepdim=True).clamp_min(1e-6))
    antonym = base.clone()
    antonym[:, :half] = -antonym[:, :half]  # meaning subspace flip
    if noise > 0:
        antonym = antonym + noise * torch.randn_like(antonym)
        antonym = antonym / (antonym.norm(dim=-1, keepdim=True).clamp_min(1e-6))
    meta = {"noise_std": float(noise)}
    return base, antonym, meta

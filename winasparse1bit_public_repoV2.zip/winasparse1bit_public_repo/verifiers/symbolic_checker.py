from __future__ import annotations

import random
from typing import Dict, List, Tuple

import torch


class SymbolicChecker:
    """Utility to turn symbolic variant specs into token/label tensors."""

    def __init__(self, vocab_size: int, seq_len: int, hard_mode: bool = False) -> None:
        self.vocab_size = max(1, int(vocab_size))
        self.seq_len = max(1, int(seq_len))
        self.hard_mode = hard_mode

    def build_batch(
        self,
        task_spec: Dict[str, object],
        batch_size: int,
        device: torch.device,
        hard_mode: bool = False,
        difficulty: str | None = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        prompts: List[torch.Tensor] = []
        labels: List[int] = []
        effective_difficulty = difficulty or ("hard" if (hard_mode or self.hard_mode) else "medium")
        for _ in range(batch_size):
            prompt, answer = self._sample_instance(task_spec, difficulty=effective_difficulty)
            prompts.append(self._encode_prompt(prompt))
            labels.append(int(answer))
        x = torch.stack(prompts).to(device)
        y = torch.tensor(labels, dtype=torch.long, device=device)
        return x, y

    def _sample_instance(self, task_spec: Dict[str, object], difficulty: str = "medium") -> Tuple[str, int]:
        variables = task_spec.get("input_spec", {}).get("variables", {})
        values_spec = variables.get("values", {})
        min_len = int(values_spec.get("min_len", 3))
        max_len = int(values_spec.get("max_len", 5))
        min_val = int(values_spec.get("min_val", 0))
        max_val = int(values_spec.get("max_val", 9))
        effective_hard = difficulty == "hard"
        if effective_hard:
            min_len = max(min_len + 2, min_len + 1)
            max_len = max_len + 4
            max_val = max_val + 5
        length = random.randint(min_len, max_len)
        values = [random.randint(min_val, max_val) for _ in range(length)]
        prompt_template = task_spec.get("prompt_template", "Values={values}")
        verifier_spec = dict(task_spec.get("verifier_spec", {}))
        if effective_hard:
            checker = verifier_spec.get("checker", "ParityChecker")
            if checker == "ParityChecker":
                verifier_spec["mode"] = verifier_spec.get("mode", random.choice(["ADD", "XOR"]))
            elif checker == "ModSumChecker":
                verifier_spec["modulus"] = max(3, int(verifier_spec.get("modulus", 10)) - 2)
        prompt = str(prompt_template).format(values=values)
        answer = self._compute_answer(values, verifier_spec)
        return prompt, answer

    def _compute_answer(self, values: List[int], verifier_spec: Dict[str, object]) -> int:
        checker = verifier_spec.get("checker", "ParityChecker")
        if checker == "ParityChecker":
            mode = verifier_spec.get("mode", "ADD")
            if mode == "ADD":
                return sum(values) % 2
            if mode == "XOR":
                result = 0
                for value in values:
                    result ^= (value & 1)
                return result
            raise ValueError(f"Unknown ParityChecker mode: {mode}")
        if checker == "ModSumChecker":
            modulus = int(verifier_spec.get("modulus", 10))
            return sum(values) % modulus
        raise ValueError(f"Unknown checker: {checker}")

    def _encode_prompt(self, prompt: str) -> torch.Tensor:
        tokens = [ord(ch) % self.vocab_size for ch in prompt]
        tokens = tokens[: self.seq_len]
        if len(tokens) < self.seq_len:
            tokens.extend([0] * (self.seq_len - len(tokens)))
        return torch.tensor(tokens, dtype=torch.long)

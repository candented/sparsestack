"""
Phase 15: Text Generation with CausalSparseTransformer.

Loads a trained checkpoint and generates text autoregressively with
temperature, top-k, and top-p sampling.

Usage:
    python generate.py --checkpoint checkpoints/phase15/... --prompt "Once upon a time"
    python generate.py --checkpoint checkpoints/phase15/... --interactive
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
import torch.nn.functional as F

from sparse_llm.causal_transformer import CausalSparseTransformer
from sparse_llm.datasets.lm_dataset import get_tokenizer, tokenize_text, get_eot_token
from train_lm import load_checkpoint


@torch.no_grad()
def generate(
    model: CausalSparseTransformer,
    input_ids: torch.Tensor,
    max_new_tokens: int = 256,
    temperature: float = 0.8,
    top_k: int = 50,
    top_p: float = 0.95,
    mode: str = "dense",
    **sparse_kwargs,
) -> torch.Tensor:
    """
    Autoregressive text generation with top-k/top-p sampling.

    Args:
        model: Trained CausalSparseTransformer
        input_ids: (1, prompt_len) initial token IDs
        max_new_tokens: Maximum tokens to generate
        temperature: Sampling temperature (0 = greedy, higher = more random)
        top_k: Keep only top-k logits (0 = disabled)
        top_p: Nucleus sampling threshold (1.0 = disabled)
        mode: Sparsity mode for forward pass

    Returns:
        (1, prompt_len + generated_len) token IDs
    """
    model.eval()
    device = input_ids.device

    for _ in range(max_new_tokens):
        # Crop to max_seq_len if needed
        context = input_ids[:, -model.max_seq_len:]

        # Forward pass
        logits, _ = model(context, mode=mode, **sparse_kwargs)

        # Get logits for last position only
        logits = logits[:, -1, :]  # (1, vocab_size)

        # Temperature
        if temperature > 0:
            logits = logits / temperature
        else:
            # Greedy
            next_token = logits.argmax(dim=-1, keepdim=True)
            input_ids = torch.cat([input_ids, next_token], dim=1)
            continue

        # Top-k filtering
        if top_k > 0:
            top_k_val = min(top_k, logits.size(-1))
            kth_val = torch.topk(logits, top_k_val, dim=-1).values[:, -1:]
            logits = torch.where(logits < kth_val, float("-inf"), logits)

        # Top-p (nucleus) filtering
        if top_p < 1.0:
            sorted_logits, sorted_indices = torch.sort(logits, descending=True, dim=-1)
            cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
            # Remove tokens with cumulative prob above threshold
            sorted_mask = cumulative_probs - F.softmax(sorted_logits, dim=-1) >= top_p
            sorted_logits[sorted_mask] = float("-inf")
            # Scatter back to original indices
            logits = sorted_logits.scatter(1, sorted_indices, sorted_logits)

        # Sample
        probs = F.softmax(logits, dim=-1)
        next_token = torch.multinomial(probs, num_samples=1)

        input_ids = torch.cat([input_ids, next_token], dim=1)

        # Stop on EOT
        if next_token.item() == 50256:  # GPT-2 <|endoftext|>
            break

    return input_ids


def main():
    parser = argparse.ArgumentParser(description="Generate text with CausalSparseTransformer")
    parser.add_argument("--checkpoint", type=str, required=True, help="Path to checkpoint directory")
    parser.add_argument("--prompt", type=str, default="Once upon a time", help="Input prompt")
    parser.add_argument("--max-tokens", type=int, default=256, help="Max tokens to generate")
    parser.add_argument("--temperature", type=float, default=0.8, help="Sampling temperature")
    parser.add_argument("--top-k", type=int, default=50, help="Top-k filtering")
    parser.add_argument("--top-p", type=float, default=0.95, help="Nucleus sampling threshold")
    parser.add_argument("--interactive", action="store_true", help="Interactive prompt mode")
    parser.add_argument("--mode", type=str, default="dense", help="Sparsity mode: dense, circuit_masked, full_sparse")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = torch.device(args.device)

    # Load model
    ckpt_path = Path(args.checkpoint)
    print(f"Loading checkpoint from {ckpt_path}...")
    model, _, step = load_checkpoint(ckpt_path, device)
    model.eval()
    param_info = model.count_parameters()
    print(f"Model loaded (step {step}, {param_info['unique']/1e6:.1f}M params)")
    print(f"Sparsity mode: {args.mode}")

    # Tokenizer
    tokenizer = get_tokenizer("gpt2")

    def generate_from_prompt(prompt: str):
        tokens = tokenize_text(tokenizer, prompt)
        input_ids = torch.tensor([tokens], dtype=torch.long, device=device)

        output_ids = generate(
            model, input_ids,
            max_new_tokens=args.max_tokens,
            temperature=args.temperature,
            top_k=args.top_k,
            top_p=args.top_p,
            mode=args.mode,
        )

        # Decode
        output_tokens = output_ids[0].tolist()
        if hasattr(tokenizer, 'decode'):
            text = tokenizer.decode(output_tokens)
        else:
            text = tokenizer.decode(output_tokens)

        return text

    if args.interactive:
        print("\nInteractive mode. Type 'quit' to exit.\n")
        while True:
            try:
                prompt = input(">>> ")
            except (EOFError, KeyboardInterrupt):
                break
            if prompt.lower() in ("quit", "exit", "q"):
                break
            if not prompt.strip():
                continue
            text = generate_from_prompt(prompt)
            print(f"\n{text}\n")
    else:
        print(f"\nPrompt: {args.prompt}")
        print("-" * 40)
        text = generate_from_prompt(args.prompt)
        print(text)


if __name__ == "__main__":
    main()

from __future__ import annotations

import json
import os
import random
from typing import Any, Dict, List, Optional

try:
    import requests  # type: ignore
except Exception:  # requests may be unavailable; defer failure until needed
    requests = None


class EGMHandler:
    """External Guidance Model interface for variant generation."""

    def __init__(self, endpoint: str, api_key: Optional[str] = None, timeout: float = 10.0) -> None:
        self.endpoint = endpoint.strip()
        self.api_key = api_key or os.getenv("EGM_API_KEY", "")
        self.timeout = timeout

    def fetch_variants(self, recent_performance: List[Dict[str, Any]], difficulty: str = "medium") -> Dict[str, Any]:
        if self.endpoint:
            if requests is None:
                raise RuntimeError("requests is required to call the configured EGM endpoint")
            payload = {
                "mode": "variant_generation",
                "base_task_type": "symbolic_logic",
                "target_difficulty": difficulty,
                "recent_performance": recent_performance,
            }
            headers = {"Content-Type": "application/json"}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            response = requests.post(
                self.endpoint,
                headers=headers,
                data=json.dumps(payload),
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json()
        return self._generate_local_variants(difficulty)

    def _generate_local_variants(self, difficulty: str) -> Dict[str, Any]:
        hard = difficulty == "hard"
        values = {
            "min_len": 5 if hard else 3,
            "max_len": 9 if hard else 5,
            "min_val": 0,
            "max_val": 7 if hard else 3,
        }
        if hard:
            verifier_spec = {
                "checker": random.choice(["ParityChecker", "ModSumChecker"]),
                "mode": random.choice(["ADD", "XOR"]),
                "modulus": random.choice([5, 7]),
            }
        else:
            verifier_spec = {"checker": "ParityChecker", "mode": "ADD"}
        variant = {
            "task_id": f"parity_local_v{random.randint(1, 9999)}",
            "task_type": "Symbolic_Logic",
            "difficulty": difficulty,
            "prompt_template": "Parity({values}) = \\boxed{{X}}",
            "input_spec": {"variables": {"values": values}},
            "verifier_spec": verifier_spec,
        }
        return {"variant_tasks": [variant]}

#!/usr/bin/env bash
# compile_preprint.sh -- Compile a WINASPARSE1BIT preprint to PDF.
#
# Default target: docs/WINASPARSE1BIT_arxiv_v2.tex
#
# What it does
#   1. Locates pdflatex (PATH first, then known MiKTeX install locations).
#   2. (MiKTeX only) Configures unattended package auto-install via initexmf.
#   3. Runs pdflatex twice (no bibtex needed; the .tex uses an inline
#      thebibliography environment). Two passes resolve cross-refs, TOC,
#      and citations.
#   4. Moves the final PDF next to the source .tex.
#   5. Cleans up build/ on success (preserves it on failure for debugging).
#
# Usage
#   bash docs/compile_preprint.sh                       # default v2 target
#   bash docs/compile_preprint.sh path/to/other.tex     # arbitrary tex file
#   PASSES=3 bash docs/compile_preprint.sh              # force 3 passes
#   KEEP_BUILD=1 bash docs/compile_preprint.sh          # keep build/ after
#   PDFLATEX=/abs/path bash docs/compile_preprint.sh    # override binary
#
# Exit codes
#   0 -- PDF produced
#   1 -- pdflatex not found
#   2 -- input file not found
#   3 -- pdflatex error (see preserved build/pass_N.log)

set -euo pipefail

# ----- Locate binaries --------------------------------------------------------

find_binary() {
    local name="$1"
    if command -v "$name" &>/dev/null; then
        command -v "$name"
        return 0
    fi
    local user="${USERNAME:-${USER:-}}"
    local candidates=(
        "/c/Users/$user/AppData/Local/Programs/MiKTeX/miktex/bin/x64"
        "/c/Program Files/MiKTeX/miktex/bin/x64"
        "/c/Program Files (x86)/MiKTeX/miktex/bin/x64"
        "/c/texlive/2024/bin/windows"
        "/c/texlive/2023/bin/windows"
    )
    for prefix in "${candidates[@]}"; do
        if [[ -x "$prefix/$name.exe" ]]; then
            echo "$prefix/$name.exe"
            return 0
        fi
        if [[ -x "$prefix/$name" ]]; then
            echo "$prefix/$name"
            return 0
        fi
    done
    return 1
}

PDFLATEX="${PDFLATEX:-}"
if [[ -z "$PDFLATEX" ]]; then
    PDFLATEX="$(find_binary pdflatex || echo "")"
fi
if [[ -z "$PDFLATEX" || ! -x "$PDFLATEX" ]]; then
    echo "ERROR: pdflatex not found." >&2
    echo "Install MiKTeX via:  winget install MiKTeX.MiKTeX" >&2
    echo "Or set PDFLATEX env var to the binary path." >&2
    exit 1
fi
echo "pdflatex: $PDFLATEX"

INITEXMF="${INITEXMF:-}"
if [[ -z "$INITEXMF" ]]; then
    INITEXMF="$(find_binary initexmf || echo "")"
fi

# ----- One-time MiKTeX unattended-install config ------------------------------
# Idempotent. Configures MiKTeX to auto-install missing LaTeX packages
# without prompting the user. No-op for TeX Live.
if [[ -n "$INITEXMF" && -x "$INITEXMF" ]]; then
    "$INITEXMF" --set-config-value="[MPM]AutoInstall=1" >/dev/null 2>&1 || true
fi

# ----- Resolve input ----------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INPUT_TEX="${1:-$SCRIPT_DIR/WINASPARSE1BIT_arxiv_v2.tex}"

if [[ ! -f "$INPUT_TEX" ]]; then
    echo "ERROR: input not found: $INPUT_TEX" >&2
    exit 2
fi

INPUT_DIR="$(cd "$(dirname "$INPUT_TEX")" && pwd)"
INPUT_BASE="$(basename "$INPUT_TEX" .tex)"
BUILD_DIR="$INPUT_DIR/build"
OUT_PDF="$INPUT_DIR/$INPUT_BASE.pdf"

mkdir -p "$BUILD_DIR"
echo "Input : $INPUT_TEX"
echo "Build : $BUILD_DIR"
echo "Output: $OUT_PDF"

# ----- Compile passes ---------------------------------------------------------
PASSES="${PASSES:-2}"
cd "$INPUT_DIR"

for pass in $(seq 1 "$PASSES"); do
    echo ""
    echo "=== Pass $pass / $PASSES ==="
    LOG="$BUILD_DIR/pass_$pass.log"
    if "$PDFLATEX" \
        -interaction=nonstopmode \
        -halt-on-error \
        -file-line-error \
        -output-directory="$BUILD_DIR" \
        "$INPUT_BASE.tex" > "$LOG" 2>&1 ; then
        # Surface useful end-of-pass info
        grep -E "Output written|Pages:|Underfull|Overfull" "$LOG" \
            | tail -5 || true
    else
        echo "ERROR: pdflatex failed on pass $pass." >&2
        echo "Last 50 lines of $LOG:" >&2
        tail -50 "$LOG" >&2
        echo "" >&2
        echo "Full log preserved at: $LOG" >&2
        exit 3
    fi
done

# ----- Finalize ---------------------------------------------------------------
if [[ -f "$BUILD_DIR/$INPUT_BASE.pdf" ]]; then
    mv -f "$BUILD_DIR/$INPUT_BASE.pdf" "$OUT_PDF"
    size_bytes=$(stat -c %s "$OUT_PDF" 2>/dev/null || stat -f %z "$OUT_PDF" 2>/dev/null || echo 0)
    size_kb=$((size_bytes / 1024))
    pages=$(grep -oE "Pages: [0-9]+" "$BUILD_DIR/pass_$PASSES.log" 2>/dev/null | tail -1 || echo "Pages: ?")
    echo ""
    echo "PDF ready: $OUT_PDF"
    echo "Size: ${size_kb} KB"
    echo "$pages"
else
    echo "ERROR: PDF not produced at $BUILD_DIR/$INPUT_BASE.pdf" >&2
    echo "Build artifacts preserved at $BUILD_DIR" >&2
    exit 3
fi

if [[ "${KEEP_BUILD:-0}" == "0" ]]; then
    rm -rf "$BUILD_DIR"
    echo "Cleaned up build directory."
else
    echo "Build directory kept: $BUILD_DIR"
fi

echo "Done."

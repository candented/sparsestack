import torch

from config.loader import load_config
from main import apply_preset, build_model_and_optimizer
from rl.env import ConfigEnv
from rl.lambda_scheduler import make_lambda_scheduler
from utils import EGMHandler


def _build_env_for_preset(preset: str) -> ConfigEnv:
    cfg = load_config()
    cfg["preset"] = preset
    cfg = apply_preset(cfg)
    cfg.setdefault("training", {})["device"] = "cpu"
    model, optimizer = build_model_and_optimizer(cfg, torch.device("cpu"))
    egm_handler = EGMHandler(endpoint="", api_key="")
    lambda_scheduler = make_lambda_scheduler(cfg)
    env = ConfigEnv(
        model=model,
        optimizer=optimizer,
        cfg=cfg,
        egm_handler=egm_handler,
        lambda_scheduler=lambda_scheduler,
        device=torch.device("cpu"),
    )
    return env


def test_dense_flops_within_band():
    env = _build_env_for_preset("baseline_dense_v1")
    env.reset()
    flops, _, _ = env._gather_model_stats()
    assert 0.4 < flops < 0.8


def test_stacked_flops_within_band():
    env = _build_env_for_preset("stacked_sparsity_full_v1")
    env.reset()
    flops_stacked, _, _ = env._gather_model_stats()
    env_dense = _build_env_for_preset("baseline_dense_v1")
    env_dense.reset()
    flops_dense, _, _ = env_dense._gather_model_stats()
    assert flops_stacked < flops_dense


def test_curriculum_symbolic_flops_band():
    env = _build_env_for_preset("curriculum_symbolic_only_v1")
    env.reset()
    flops_sym, _, _ = env._gather_model_stats()
    env_dense = _build_env_for_preset("baseline_dense_v1")
    env_dense.reset()
    flops_dense, _, _ = env_dense._gather_model_stats()
    assert flops_sym < flops_dense


def test_oct_geometry_band():
    env = _build_env_for_preset("oct_debug_v1")
    # Build a single batch and evaluate geometric metrics
    task_spec = env.egm_handler._generate_local_variants("hard")["variant_tasks"][0]
    x, y, _ = env._build_task_batch(task_spec, task_family="oct", difficulty="hard", use_harder_eval_slice=False, batch_size=2)
    assert x.shape == y.shape
    x_norm = x.norm(dim=-1)
    y_norm = y.norm(dim=-1)
    cos = torch.nn.functional.cosine_similarity(x, y, dim=-1)
    assert torch.allclose(x_norm, torch.ones_like(x_norm), atol=1e-3)
    assert torch.allclose(y_norm, torch.ones_like(y_norm), atol=1e-3)
    assert (cos.abs() < 0.5).all()


def _eval_acc(env: ConfigEnv) -> float:
    task_spec = env.egm_handler._generate_local_variants(env.difficulty)["variant_tasks"][0]
    x, y, _ = env._build_task_batch(
        task_spec,
        task_family=env.task_family,
        difficulty=env.difficulty,
        use_harder_eval_slice=False,
        batch_size=env.batch_size,
    )
    acc, _, _, _ = env._eval_accuracy_for_action(x, y, env.ref_action, tag=None)
    return acc


def test_lexical_anagram_dense_vs_stacked():
    env_dense = _build_env_for_preset("lexical_anagram_dense_v1")
    env_stacked = _build_env_for_preset("lexical_anagram_stacked_v1")
    env_dense.reset()
    env_stacked.reset()
    acc_dense = _eval_acc(env_dense)
    acc_stacked = _eval_acc(env_stacked)
    flops_dense, _, _ = env_dense._gather_model_stats()
    flops_stacked, _, _ = env_stacked._gather_model_stats()
    assert acc_dense > 0.3 and acc_stacked > 0.3
    assert flops_stacked < flops_dense


def test_lexical_synonym_dense_vs_stacked():
    env_dense = _build_env_for_preset("lexical_synonym_dense_v1")
    env_stacked = _build_env_for_preset("lexical_synonym_stacked_v1")
    env_dense.reset()
    env_stacked.reset()
    acc_dense = _eval_acc(env_dense)
    acc_stacked = _eval_acc(env_stacked)
    flops_dense, _, _ = env_dense._gather_model_stats()
    flops_stacked, _, _ = env_stacked._gather_model_stats()
    assert acc_dense > 0.3 and acc_stacked > 0.3
    assert flops_stacked < flops_dense


def test_lexical_anagram_dense_vs_stacked_v2():
    env_dense = _build_env_for_preset("lexical_anagram_dense_v2")
    env_stacked = _build_env_for_preset("lexical_anagram_stacked_v2")
    env_dense.reset()
    env_stacked.reset()
    acc_dense = _eval_acc(env_dense)
    acc_stacked = _eval_acc(env_stacked)
    flops_dense, _, _ = env_dense._gather_model_stats()
    flops_stacked, _, _ = env_stacked._gather_model_stats()
    assert acc_dense > 0.3 and acc_stacked > 0.3
    assert flops_stacked < flops_dense


def test_lexical_synonym_dense_vs_stacked_v2():
    env_dense = _build_env_for_preset("lexical_synonym_dense_v2")
    env_stacked = _build_env_for_preset("lexical_synonym_stacked_v2")
    env_dense.reset()
    env_stacked.reset()
    acc_dense = _eval_acc(env_dense)
    acc_stacked = _eval_acc(env_stacked)
    flops_dense, _, _ = env_dense._gather_model_stats()
    flops_stacked, _, _ = env_stacked._gather_model_stats()
    assert acc_dense > 0.3 and acc_stacked > 0.3
    assert flops_stacked < flops_dense


def test_lexical_antonym_dense_vs_stacked_v2():
    env_dense = _build_env_for_preset("lexical_antonym_dense_v2")
    env_stacked = _build_env_for_preset("lexical_antonym_stacked_v2")
    env_dense.reset()
    env_stacked.reset()
    acc_dense = _eval_acc(env_dense)
    acc_stacked = _eval_acc(env_stacked)
    flops_dense, _, _ = env_dense._gather_model_stats()
    flops_stacked, _, _ = env_stacked._gather_model_stats()
    assert acc_dense > 0.3 and acc_stacked > 0.3
    assert flops_stacked < flops_dense

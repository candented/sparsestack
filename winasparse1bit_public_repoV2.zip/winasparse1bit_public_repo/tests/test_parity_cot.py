"""Tests for Parity Chain-of-Thought (Scratchpad Training) - Phase 12 Cognitive Unlocking."""

import pytest
import torch
from sparse_llm.datasets.logical import LogicalDataset
from verifiers.logical_checker import LogicalChecker


# =============================================================================
# LogicalDataset Parity CoT Tests
# =============================================================================

@pytest.fixture
def logical_ds_parity_cot_easy():
    """LogicalDataset configured for easy parity with CoT (depth=2, 4 leaves)."""
    return LogicalDataset(
        vocab_size=64,
        seq_len=64,
        task_type="parity_cot",
        recursive_steps=2
    )


@pytest.fixture
def logical_ds_parity_cot_medium():
    """LogicalDataset configured for medium parity with CoT (depth=3, 8 leaves)."""
    return LogicalDataset(
        vocab_size=64,
        seq_len=96,
        task_type="parity_cot",
        recursive_steps=3
    )


@pytest.fixture
def logical_ds_parity_cot_hard():
    """LogicalDataset configured for hard parity with CoT (depth=4, 16 leaves)."""
    return LogicalDataset(
        vocab_size=64,
        seq_len=128,
        task_type="parity_cot",
        recursive_steps=4
    )


class TestParityCotBatchShape:
    """Tests for batch shape and dtype."""

    def test_easy_batch_shape(self, logical_ds_parity_cot_easy):
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_easy.build_parity_batch_with_trace(batch_size=8, device=device)

        assert x.shape == (8, 64)
        assert y.shape == (8,)
        assert x.dtype == torch.long
        assert y.dtype == torch.long

    def test_medium_batch_shape(self, logical_ds_parity_cot_medium):
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_medium.build_parity_batch_with_trace(batch_size=8, device=device)

        assert x.shape == (8, 96)
        assert y.shape == (8,)

    def test_hard_batch_shape(self, logical_ds_parity_cot_hard):
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_hard.build_parity_batch_with_trace(batch_size=8, device=device)

        assert x.shape == (8, 128)
        assert y.shape == (8,)


class TestParityCotLabels:
    """Tests for label correctness."""

    def test_labels_binary(self, logical_ds_parity_cot_easy):
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_easy.build_parity_batch_with_trace(batch_size=100, device=device)

        assert y.min() >= 0
        assert y.max() <= 1

    def test_labels_roughly_balanced(self, logical_ds_parity_cot_easy):
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_easy.build_parity_batch_with_trace(batch_size=100, device=device)

        # Expect roughly balanced classes (30-70 range for 100 samples)
        positive_count = y.sum().item()
        assert 20 < positive_count < 80, f"Labels not balanced: {positive_count}/100 positive"


class TestParityCotVocab:
    """Tests for vocabulary constraints."""

    def test_vocab_constraints_easy(self, logical_ds_parity_cot_easy):
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_easy.build_parity_batch_with_trace(batch_size=8, device=device)

        assert x.max() < 64
        assert x.min() >= 0

    def test_vocab_constraints_hard(self, logical_ds_parity_cot_hard):
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_hard.build_parity_batch_with_trace(batch_size=8, device=device)

        assert x.max() < 64
        assert x.min() >= 0


class TestParityCotTokens:
    """Tests for trace token presence."""

    def test_bos_token_present(self, logical_ds_parity_cot_easy):
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_easy.build_parity_batch_with_trace(batch_size=4, device=device)

        # First token should be BOS (1)
        assert (x[:, 0] == 1).all()

    def test_trace_tokens_in_map(self, logical_ds_parity_cot_easy):
        """Verify trace tokens are in the token map."""
        assert '[TRACE]' in logical_ds_parity_cot_easy.token_map
        assert '[END]' in logical_ds_parity_cot_easy.token_map
        assert '[STEP]' in logical_ds_parity_cot_easy.token_map

    def test_trace_token_values(self, logical_ds_parity_cot_easy):
        """Verify trace tokens have correct values."""
        op_base = logical_ds_parity_cot_easy.op_base
        assert logical_ds_parity_cot_easy.token_map['[TRACE]'] == op_base + 16
        assert logical_ds_parity_cot_easy.token_map['[END]'] == op_base + 17
        assert logical_ds_parity_cot_easy.token_map['[STEP]'] == op_base + 18


class TestParityCotTraceGeneration:
    """Tests for trace generation correctness."""

    def test_trace_generation_depth2(self, logical_ds_parity_cot_easy):
        """Test trace generation for depth=2 (4 leaves, 3 XOR steps)."""
        values = [0, 1, 1, 0]  # Example values
        expr, result, trace = logical_ds_parity_cot_easy._build_nested_xor_with_trace(values)

        # Check expression format
        assert expr == "((0^1)^(1^0))"

        # Check trace has correct number of steps (2^n - 1 = 3)
        assert len(trace) == 3

        # Verify each step is valid XOR
        for step in trace:
            assert "^" in step
            assert "=" in step

        # Verify final result
        # (0^1) = 1, (1^0) = 1, (1^1) = 0
        assert result == 0

    def test_trace_generation_depth3(self, logical_ds_parity_cot_medium):
        """Test trace generation for depth=3 (8 leaves, 7 XOR steps)."""
        values = [0, 1, 1, 0, 1, 1, 0, 0]
        expr, result, trace = logical_ds_parity_cot_medium._build_nested_xor_with_trace(values)

        # Check trace has correct number of steps (2^n - 1 = 7)
        assert len(trace) == 7

    def test_trace_generation_depth4(self, logical_ds_parity_cot_hard):
        """Test trace generation for depth=4 (16 leaves, 15 XOR steps)."""
        values = [0, 1] * 8  # 16 values
        expr, result, trace = logical_ds_parity_cot_hard._build_nested_xor_with_trace(values)

        # Check trace has correct number of steps (2^n - 1 = 15)
        assert len(trace) == 15

    def test_trace_mathematical_correctness(self, logical_ds_parity_cot_easy):
        """Test that trace steps are mathematically correct."""
        values = [1, 0, 0, 1]  # (1^0) = 1, (0^1) = 1, (1^1) = 0
        expr, result, trace = logical_ds_parity_cot_easy._build_nested_xor_with_trace(values)

        # Parse and verify each trace step
        for step in trace:
            parts = step.split("=")
            xor_expr = parts[0]
            step_result = int(parts[1])

            # Parse the XOR expression
            operands = xor_expr.split("^")
            left = int(operands[0])
            right = int(operands[1])

            # Verify XOR is correct
            assert (left ^ right) == step_result, f"Step {step} is incorrect"


class TestParityCotRouting:
    """Tests for build_batch routing."""

    def test_build_batch_routes_to_parity_cot(self, logical_ds_parity_cot_easy):
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_easy.build_batch(batch_size=4, device=device)

        assert x.shape == (4, 64)
        assert y.shape == (4,)

    def test_build_batch_override_to_parity_cot(self):
        """Test that we can override task type to parity_cot."""
        ds = LogicalDataset(vocab_size=64, seq_len=64, task_type="implication")
        device = torch.device("cpu")

        x, y = ds.build_batch(batch_size=4, device=device, task_type="parity_cot")

        assert x.shape == (4, 64)
        assert y.shape == (4,)


class TestParityCotSequenceFit:
    """Tests for sequence length fitting."""

    def test_depth4_fits_in_128_tokens(self, logical_ds_parity_cot_hard):
        """Verify depth=4 parity + trace fits in 128 tokens."""
        device = torch.device("cpu")
        x, y = logical_ds_parity_cot_hard.build_parity_batch_with_trace(batch_size=10, device=device)

        # Check no truncation occurred (last non-pad token should include [END])
        # This is approximate - we check that meaningful tokens exist past position 80
        for i in range(10):
            non_pad = (x[i] != 0).sum().item()
            # Depth=4 should produce ~100+ tokens
            assert non_pad > 80, f"Sample {i} has only {non_pad} non-pad tokens"


# =============================================================================
# LogicalChecker Parity CoT Tests
# =============================================================================

@pytest.fixture
def logical_checker():
    """LogicalChecker instance."""
    return LogicalChecker(vocab_size=64, seq_len=128)


class TestLogicalCheckerParityCot:
    """Tests for LogicalChecker parity CoT verification."""

    def test_build_batch_shape(self, logical_checker):
        device = torch.device("cpu")
        task_spec = {
            "verifier_spec": {
                "checker": "ParityCotChecker",
                "recursive_steps": 2
            }
        }
        x, y = logical_checker.build_batch(task_spec, batch_size=8, device=device)

        assert x.shape == (8, 128)
        assert y.shape == (8,)

    def test_trace_tokens_in_checker_map(self, logical_checker):
        """Verify trace tokens are in checker's token map."""
        assert '[TRACE]' in logical_checker.token_map
        assert '[END]' in logical_checker.token_map
        assert '[STEP]' in logical_checker.token_map

    def test_checker_trace_generation(self, logical_checker):
        """Test checker's trace generation."""
        values = [0, 1, 1, 0]
        expr, result, trace = logical_checker._build_nested_xor_with_trace(values)

        assert len(trace) == 3
        assert result == 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestDatasetCheckerConsistency:
    """Tests that LogicalDataset and LogicalChecker produce consistent results."""

    def test_parity_cot_token_encoding_matches(self):
        """Verify that dataset and checker use compatible token encoding."""
        ds = LogicalDataset(vocab_size=64, seq_len=128, task_type="parity_cot")
        checker = LogicalChecker(vocab_size=64, seq_len=128)

        # Both should have same token maps for trace tokens
        assert ds.token_map['[TRACE]'] == checker.token_map['[TRACE]']
        assert ds.token_map['[END]'] == checker.token_map['[END]']
        assert ds.token_map['[STEP]'] == checker.token_map['[STEP]']

    def test_parity_cot_batch_formats_match(self):
        """Verify that dataset and checker produce same tensor shapes."""
        ds = LogicalDataset(vocab_size=64, seq_len=128, task_type="parity_cot", recursive_steps=3)
        checker = LogicalChecker(vocab_size=64, seq_len=128)

        device = torch.device("cpu")

        x_ds, y_ds = ds.build_parity_batch_with_trace(8, device)

        task_spec = {"verifier_spec": {"checker": "ParityCotChecker", "recursive_steps": 3}}
        x_checker, y_checker = checker.build_batch(task_spec, 8, device)

        assert x_ds.shape == x_checker.shape
        assert y_ds.shape == y_checker.shape
        assert x_ds.dtype == x_checker.dtype
        assert y_ds.dtype == y_checker.dtype

"""
Test Phase 13 real reasoning datasets integration.

Tests:
1. FLD dataset loader (modus ponens, syllogisms, etc.)
2. Math CoT dataset loader (word problems, arithmetic)
3. Integration with SparseStack build_batch API
"""

import pytest
import torch

from sparse_llm.datasets.fld_loader import FLDDataset
from sparse_llm.datasets.math_cot_loader import MathCoTDataset


class TestFLDDataset:
    """Test FLD formal logic deduction dataset."""

    def test_fld_init(self):
        """Test FLD dataset initialization."""
        ds = FLDDataset(
            vocab_size=128,
            seq_len=256,
            task_type="mixed",
            include_trace=True
        )
        assert ds.vocab_size == 128
        assert ds.seq_len == 256
        assert ds.include_trace is True

    def test_modus_ponens_generation(self):
        """Test modus ponens example generation."""
        ds = FLDDataset(vocab_size=128, seq_len=256, include_trace=True)
        expr, label, task_type = ds._generate_modus_ponens()

        assert isinstance(expr, str)
        assert label in [0, 1]
        assert task_type == "modus_ponens"
        assert "Therefore" in expr
        assert "[TRACE:" in expr

    def test_syllogism_generation(self):
        """Test syllogism example generation."""
        ds = FLDDataset(vocab_size=128, seq_len=256, include_trace=True)
        expr, label, task_type = ds._generate_syllogism()

        assert isinstance(expr, str)
        assert label in [0, 1]
        assert task_type == "syllogism"
        assert "All" in expr

    def test_fld_batch_generation(self):
        """Test FLD batch generation."""
        ds = FLDDataset(vocab_size=128, seq_len=256, task_type="mixed")
        device = torch.device("cpu")

        x, y = ds.build_batch(8, device, "mixed")

        assert x.shape == (8, 256)
        assert y.shape == (8,)
        assert x.dtype == torch.long
        assert y.dtype == torch.long
        assert torch.all(y >= 0) and torch.all(y <= 1)

    def test_fld_balanced_labels(self):
        """Test that FLD produces roughly balanced labels."""
        ds = FLDDataset(vocab_size=128, seq_len=256, task_type="mixed")
        device = torch.device("cpu")

        # Generate many samples
        all_labels = []
        for _ in range(10):
            _, y = ds.build_batch(32, device, "mixed")
            all_labels.extend(y.tolist())

        # Should be roughly balanced (30-70% range)
        mean_label = sum(all_labels) / len(all_labels)
        assert 0.3 <= mean_label <= 0.7, f"Labels imbalanced: mean={mean_label:.2f}"


class TestMathCoTDataset:
    """Test Math CoT dataset."""

    def test_math_cot_init(self):
        """Test Math CoT dataset initialization."""
        ds = MathCoTDataset(
            vocab_size=128,
            seq_len=512,
            task_type="word_problem",
            difficulty="easy",
            max_samples=100
        )
        assert ds.vocab_size == 128
        assert ds.seq_len == 512
        assert ds.difficulty == "easy"

    def test_arithmetic_problem_generation(self):
        """Test arithmetic problem generation."""
        ds = MathCoTDataset(vocab_size=128, seq_len=512, difficulty="easy")
        problem, solution, answer = ds._generate_arithmetic_problem(num_ops=2)

        assert isinstance(problem, str)
        assert isinstance(solution, str)
        assert isinstance(answer, int)
        assert "Calculate:" in problem
        assert "Answer:" in solution

    def test_word_problem_generation(self):
        """Test word problem generation."""
        ds = MathCoTDataset(vocab_size=128, seq_len=512, difficulty="easy")
        problem, solution, answer = ds._generate_word_problem()

        assert isinstance(problem, str)
        assert isinstance(solution, str)
        assert isinstance(answer, int)
        assert "Answer:" in solution

    def test_math_cot_batch_generation(self):
        """Test Math CoT batch generation."""
        ds = MathCoTDataset(
            vocab_size=128,
            seq_len=512,
            task_type="word_problem",
            difficulty="easy"
        )
        device = torch.device("cpu")

        x, y = ds.build_batch(8, device, "word_problem")

        assert x.shape == (8, 512)
        assert y.shape == (8,)
        assert x.dtype == torch.long
        assert y.dtype == torch.long

    def test_math_cot_mixed_batch(self):
        """Test mixed Math CoT batch."""
        ds = MathCoTDataset(vocab_size=128, seq_len=512, task_type="mixed")
        device = torch.device("cpu")

        x, y = ds.build_batch(8, device, "mixed")

        assert x.shape == (8, 512)
        assert y.shape == (8,)


class TestDatasetIntegration:
    """Test integration with SparseStack training flow."""

    def test_fld_sequence_encoding(self):
        """Test that FLD sequences encode/decode correctly."""
        ds = FLDDataset(vocab_size=128, seq_len=256, include_trace=True)

        # Generate and encode
        expr, label, _ = ds._generate_modus_ponens()
        tokens = ds._encode_text(expr)

        # Check token range
        assert all(0 <= t < ds.vocab_size for t in tokens), "Tokens out of range"

        # Check sequence fits in seq_len
        assert len(tokens) + 2 <= ds.seq_len, "Sequence too long"

    def test_math_cot_sequence_encoding(self):
        """Test that Math CoT sequences encode/decode correctly."""
        ds = MathCoTDataset(vocab_size=128, seq_len=512, difficulty="easy")

        # Generate and encode
        problem, solution, _ = ds._generate_word_problem()
        text = f"{problem}\n[SOLUTION]\n{solution}"
        tokens = ds._encode_text(text)

        # Check token range
        assert all(0 <= t < ds.vocab_size for t in tokens), "Tokens out of range"

    def test_batch_device_placement(self):
        """Test batch tensors are on correct device."""
        if not torch.cuda.is_available():
            pytest.skip("CUDA not available")

        device = torch.device("cuda:0")

        # FLD
        fld_ds = FLDDataset(vocab_size=128, seq_len=256)
        x, y = fld_ds.build_batch(4, device, "mixed")
        assert x.device.type == "cuda"
        assert y.device.type == "cuda"

        # Math CoT
        math_ds = MathCoTDataset(vocab_size=128, seq_len=512)
        x, y = math_ds.build_batch(4, device, "word_problem")
        assert x.device.type == "cuda"
        assert y.device.type == "cuda"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

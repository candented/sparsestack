"""
Tests for Phase 15 CausalSparseTransformer.

Validates:
- Output shape is (batch, seq_len, vocab_size)
- Causal mask prevents future token leakage
- RoPE produces correct shapes and position-dependent output
- Sparse mode forward pass works
- Weight tying between embedding and LM head
- Parameter counting handles tied weights
"""

import pytest
import torch

from sparse_llm.causal_transformer import (
    RotaryPositionEmbedding,
    CausalSelfAttention,
    CausalTransformerBlock,
    CausalSparseTransformer,
    apply_rotary_pos_emb,
    _rotate_half,
)


# Small model config for fast tests
VOCAB = 256
DIM = 64
HEADS = 4
MLP_DIM = 128
LAYERS = 2
SEQ_LEN = 32
BATCH = 2


@pytest.fixture
def model():
    return CausalSparseTransformer(
        vocab_size=VOCAB,
        dim=DIM,
        num_heads=HEADS,
        mlp_hidden_dim=MLP_DIM,
        num_layers=LAYERS,
        max_seq_len=SEQ_LEN,
        tie_embeddings=True,
    )


@pytest.fixture
def input_ids():
    return torch.randint(0, VOCAB, (BATCH, SEQ_LEN))


class TestOutputShape:
    def test_dense_mode_shape(self, model, input_ids):
        logits, log = model(input_ids, mode="dense")
        assert logits.shape == (BATCH, SEQ_LEN, VOCAB)

    def test_sparse_mode_shape(self, model, input_ids):
        logits, log = model(input_ids, mode="full_sparse")
        assert logits.shape == (BATCH, SEQ_LEN, VOCAB)

    def test_circuit_masked_shape(self, model, input_ids):
        logits, log = model(input_ids, mode="circuit_masked")
        assert logits.shape == (BATCH, SEQ_LEN, VOCAB)

    def test_single_token(self, model):
        ids = torch.randint(0, VOCAB, (1, 1))
        logits, _ = model(ids, mode="dense")
        assert logits.shape == (1, 1, VOCAB)


class TestCausalMask:
    def test_future_token_independence(self, model):
        """Changing a future token should NOT affect predictions at earlier positions."""
        ids_a = torch.randint(0, VOCAB, (1, SEQ_LEN))
        ids_b = ids_a.clone()
        # Change only the last token
        ids_b[0, -1] = (ids_b[0, -1] + 1) % VOCAB

        model.eval()
        with torch.no_grad():
            logits_a, _ = model(ids_a, mode="dense")
            logits_b, _ = model(ids_b, mode="dense")

        # All positions except the last should be identical
        # (causal mask means position i only sees tokens 0..i)
        diff = (logits_a[0, :-1] - logits_b[0, :-1]).abs().max().item()
        assert diff < 1e-5, f"Future token change affected earlier positions: max diff = {diff}"

    def test_past_token_dependence(self, model):
        """Changing an early token SHOULD affect later predictions."""
        ids_a = torch.randint(0, VOCAB, (1, SEQ_LEN))
        ids_b = ids_a.clone()
        # Change the first token
        ids_b[0, 0] = (ids_b[0, 0] + 1) % VOCAB

        model.eval()
        with torch.no_grad():
            logits_a, _ = model(ids_a, mode="dense")
            logits_b, _ = model(ids_b, mode="dense")

        # Later positions should differ
        diff = (logits_a[0, -1] - logits_b[0, -1]).abs().max().item()
        assert diff > 1e-5, "Changing first token had no effect on last position"


class TestRoPE:
    def test_rope_shape(self):
        rope = RotaryPositionEmbedding(dim=32, max_seq_len=64)
        cos, sin = rope(torch.zeros(1), seq_len=16)
        assert cos.shape == (16, 32)
        assert sin.shape == (16, 32)

    def test_rope_cache_extension(self):
        rope = RotaryPositionEmbedding(dim=32, max_seq_len=16)
        # Request longer than initial cache
        cos, sin = rope(torch.zeros(1), seq_len=64)
        assert cos.shape == (64, 32)

    def test_rotate_half(self):
        x = torch.tensor([[1.0, 2.0, 3.0, 4.0]])
        rotated = _rotate_half(x)
        expected = torch.tensor([[-3.0, -4.0, 1.0, 2.0]])
        assert torch.allclose(rotated, expected)

    def test_apply_rotary_preserves_shape(self):
        B, H, S, D = 2, 4, 16, 32
        q = torch.randn(B, H, S, D)
        k = torch.randn(B, H, S, D)
        cos = torch.randn(S, D)
        sin = torch.randn(S, D)
        q_rot, k_rot = apply_rotary_pos_emb(q, k, cos, sin)
        assert q_rot.shape == q.shape
        assert k_rot.shape == k.shape


class TestWeightTying:
    def test_weights_are_shared(self):
        model = CausalSparseTransformer(
            vocab_size=VOCAB, dim=DIM, num_heads=HEADS,
            mlp_hidden_dim=MLP_DIM, num_layers=LAYERS,
            tie_embeddings=True,
        )
        assert model.lm_head.weight.data_ptr() == model.token_emb.weight.data_ptr()

    def test_weights_not_shared(self):
        model = CausalSparseTransformer(
            vocab_size=VOCAB, dim=DIM, num_heads=HEADS,
            mlp_hidden_dim=MLP_DIM, num_layers=LAYERS,
            tie_embeddings=False,
        )
        assert model.lm_head.weight.data_ptr() != model.token_emb.weight.data_ptr()

    def test_count_parameters_handles_tying(self):
        tied = CausalSparseTransformer(
            vocab_size=VOCAB, dim=DIM, num_heads=HEADS,
            mlp_hidden_dim=MLP_DIM, num_layers=LAYERS,
            tie_embeddings=True,
        )
        untied = CausalSparseTransformer(
            vocab_size=VOCAB, dim=DIM, num_heads=HEADS,
            mlp_hidden_dim=MLP_DIM, num_layers=LAYERS,
            tie_embeddings=False,
        )
        tied_params = tied.count_parameters()
        untied_params = untied.count_parameters()
        # Unique params should differ by ~vocab_size * dim
        diff = untied_params["unique"] - tied_params["unique"]
        assert diff == VOCAB * DIM


class TestSparsityInterface:
    def test_log_contains_expected_keys(self, model, input_ids):
        _, log = model(input_ids, mode="dense")
        assert "num_blocks" in log
        assert "blocks" in log
        assert len(log["blocks"]) == LAYERS

    def test_topk_mode(self, model, input_ids):
        logits, _ = model(
            input_ids, mode="full_sparse",
            gate_mode="topk", neuron_topk_fraction=0.5,
        )
        assert logits.shape == (BATCH, SEQ_LEN, VOCAB)

    def test_per_block_topk(self, model, input_ids):
        fractions = [0.3, 0.7]  # One per layer
        logits, _ = model(
            input_ids, mode="full_sparse",
            gate_mode="topk", neuron_topk_fraction=fractions,
        )
        assert logits.shape == (BATCH, SEQ_LEN, VOCAB)


class TestSequenceLengthValidation:
    def test_exceeds_max_seq_len(self, model):
        too_long = torch.randint(0, VOCAB, (1, SEQ_LEN + 10))
        with pytest.raises(ValueError, match="exceeds max"):
            model(too_long)


class TestAttention:
    def test_causal_self_attention_shape(self):
        attn = CausalSelfAttention(dim=DIM, num_heads=HEADS, max_seq_len=SEQ_LEN)
        x = torch.randn(BATCH, SEQ_LEN, DIM)
        out = attn(x)
        assert out.shape == (BATCH, SEQ_LEN, DIM)


class TestBlock:
    def test_block_forward(self):
        block = CausalTransformerBlock(
            dim=DIM, num_heads=HEADS, mlp_hidden_dim=MLP_DIM,
            max_seq_len=SEQ_LEN,
        )
        x = torch.randn(BATCH, SEQ_LEN, DIM)
        out, log = block(x, mode="dense")
        assert out.shape == (BATCH, SEQ_LEN, DIM)
        assert isinstance(log, dict)

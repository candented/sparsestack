import json
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.summarize_logs import extract_row


def run_experiment(extra_args, need_summary=False):
    with tempfile.TemporaryDirectory() as tmpdir:
        log_dir = Path(tmpdir)
        args = [
            sys.executable,
            "experiments/mve_v4.py",
            "--preset",
            "easy",
            "--epochs",
            "3",
            "--batch-size",
            "16",
            "--num-train",
            "192",
            "--num-val",
            "64",
            "--keep-fraction",
            "0.5",
            "--gate-mode",
            "topk",
            "--neuron-topk-fraction",
            "0.5",
            "--log-dir",
            str(log_dir),
        ] + list(extra_args)
        subprocess.run(args, check=True, cwd=ROOT)
        log_files = list(log_dir.glob("*.json"))
        assert (
            len(log_files) == 1
        ), f"Expected a single log file, found {[p.name for p in log_files]}"
        log_path = log_files[0]
        payload = json.loads(log_path.read_text())
        if need_summary:
            summary_row = extract_row(log_path)
            return payload, summary_row
        return payload


def assert_probability(value):
    assert 0.0 <= value <= 1.0, f"probability out of range: {value}"


def test_dense_easy_smoke():
    data = run_experiment(
        [
            "--dense-only",
            "--run-name-suffix",
            "smoke_dense",
        ]
    )
    metrics = data["metrics"]
    assert "dense" in metrics
    assert "full_sparse" not in metrics
    assert_probability(metrics["dense"]["accuracy"])
    assert "minus_chance_accuracy" in metrics["dense"]


def test_sparse_easy_smoke():
    data = run_experiment(
        [
            "--run-name-suffix",
            "smoke_sparse",
        ]
    )
    metrics = data["metrics"]
    for mode in ("dense", "circuit_masked", "full_sparse"):
        assert mode in metrics, f"missing metrics for {mode}"
        assert_probability(metrics[mode]["accuracy"])
    full_sparse = metrics["full_sparse"]
    assert "gating_l2_diff_fc1" in full_sparse
    assert full_sparse["gating_l2_diff_fc1"] >= 0.0
    assert "active_neurons_fc1" in full_sparse
    assert full_sparse["active_neurons_fc1"] > 0.0


def test_sparse_multiblock_smoke():
    data, summary_row = run_experiment(
        [
            "--run-name-suffix",
            "smoke_multiblock",
            "--num-blocks",
            "2",
            "--epochs",
            "2",
        ],
        need_summary=True,
    )
    full_sparse = data["metrics"]["full_sparse"]
    blocks = full_sparse.get("blocks")
    assert blocks, "per-block logs missing"
    assert len(blocks) == 2
    assert summary_row["num_blocks"] == 2
    assert summary_row["gating_l2_diff_fc1_total"] is not None


def test_last_block_topk_scale():
    data = run_experiment(
        [
            "--run-name-suffix",
            "smoke_last_block_scale",
            "--num-blocks",
            "2",
            "--epochs",
            "2",
            "--last-block-topk-scale",
            "0.5",
        ]
    )
    blocks = data["metrics"]["full_sparse"]["blocks"]
    assert len(blocks) == 2
    first = blocks[0].get("gate_topk_kept_fc1")
    second = blocks[1].get("gate_topk_kept_fc1")
    assert first is not None and second is not None
    assert first > second, "expected stricter gating on last block"

"""
Tests for Phase 10 Track 3: Hybrid Bridge Architecture
"""

import pytest
import torch
import torch.nn.functional as F

from sparse_llm.hybrid import HybridStack, SparseTransformerBlock, DenseTransformerBlock


def _build_hybrid(num_sparse=1, num_dense=2, dim=64):
    """Helper to build hybrid model"""
    return HybridStack(
        vocab_size=32,
        dim=dim,
        num_heads=4,
        mlp_hidden_dim=128,
        num_classes=2,
        seq_len=16,
        num_sparse_blocks=num_sparse,
        num_dense_blocks=num_dense,
        quant_threshold=0.05,
    )


def test_hybrid_architecture_initialization():
    """Test HybridStack initializes with correct block counts"""
    model = _build_hybrid(num_sparse=1, num_dense=2)

    assert len(model.sparse_blocks_start) == 1
    assert len(model.dense_blocks) == 2
    assert len(model.sparse_blocks_end) == 1
    assert model.num_sparse_blocks == 1
    assert model.num_dense_blocks == 2


def test_hybrid_forward_shape():
    """Test forward pass produces correct output shape"""
    model = _build_hybrid()
    x = torch.randint(0, 32, (2, 8))  # batch=2, seq=8

    logits, log = model(x)

    assert logits.shape == (2, 2)  # (batch, num_classes)
    assert "blocks" in log
    # 1 sparse (start) + 2 dense + 1 sparse (end) = 4 blocks
    assert len(log["blocks"]) == 4


def test_hybrid_backward_produces_grads():
    """Test backward pass generates gradients"""
    model = _build_hybrid()
    x = torch.randint(0, 32, (4, 10))
    targets = torch.tensor([0, 1, 0, 1])

    logits, _ = model(x)
    loss = F.cross_entropy(logits, targets)
    loss.backward()

    grads = [p.grad for p in model.parameters() if p.requires_grad]
    assert any(g is not None and torch.isfinite(g).all() and g.abs().sum() > 0 for g in grads)


def test_hybrid_log_aggregation():
    """Test that logs are properly aggregated across sparse+dense blocks"""
    model = _build_hybrid(num_sparse=1, num_dense=2)
    x = torch.randint(0, 32, (2, 8))

    _, log = model(x)

    # Check aggregated fields
    assert "conn_sparsity" in log
    assert "act_sparsity" in log
    assert "prec_sparsity" in log
    assert "num_sparse_blocks" in log
    assert "num_dense_blocks" in log

    # Verify block counts
    assert log["num_sparse_blocks"] == 2.0  # 1 start + 1 end
    assert log["num_dense_blocks"] == 2.0

    # Dense blocks should report 0.0 sparsity
    dense_logs = log["blocks"][1:3]  # Middle 2 blocks are dense
    for block_log in dense_logs:
        assert block_log["conn_sparsity"] == 0.0


def test_hybrid_conservative_config():
    """Test conservative configuration (1+1+1)"""
    model = _build_hybrid(num_sparse=1, num_dense=1)
    x = torch.randint(0, 32, (2, 8))

    logits, log = model(x)

    assert len(log["blocks"]) == 3  # 1 sparse + 1 dense + 1 sparse
    assert log["num_dense_blocks"] == 1.0


def test_hybrid_deep_config():
    """Test deep configuration (1+3+1)"""
    model = _build_hybrid(num_sparse=1, num_dense=3)
    x = torch.randint(0, 32, (2, 8))

    logits, log = model(x)

    assert len(log["blocks"]) == 5  # 1 sparse + 3 dense + 1 sparse
    assert log["num_dense_blocks"] == 3.0


def test_sparse_block_forward():
    """Test SparseTransformerBlock in isolation"""
    block = SparseTransformerBlock(
        dim=64,
        num_heads=4,
        mlp_hidden_dim=128,
        quant_threshold=0.05,
    )
    x = torch.randn(2, 8, 64)  # (batch, seq, dim)

    out, log = block(x, mode="dense", neuron_threshold=0.1)

    assert out.shape == x.shape
    assert "conn_sparsity" in log


def test_dense_block_forward():
    """Test DenseTransformerBlock in isolation"""
    block = DenseTransformerBlock(
        dim=64,
        num_heads=4,
        mlp_hidden_dim=128,
    )
    x = torch.randn(2, 8, 64)

    out, log = block(x)

    assert out.shape == x.shape
    assert log["conn_sparsity"] == 0.0  # Dense = no sparsity
    assert log["act_sparsity"] == 0.0


def test_hybrid_different_variants():
    """Test all 4 variants can be instantiated"""
    variants = [
        (1, 1, 64),   # conservative
        (1, 2, 64),   # standard
        (1, 3, 64),   # deep
        (1, 2, 128),  # scaled (smaller dim for test)
    ]

    for num_sparse, num_dense, dim in variants:
        model = _build_hybrid(num_sparse=num_sparse, num_dense=num_dense, dim=dim)
        x = torch.randint(0, 32, (2, 8))
        logits, log = model(x)
        assert logits.shape == (2, 2)
        assert len(log["blocks"]) == num_sparse * 2 + num_dense


def test_hybrid_parameter_count():
    """Test that parameter count increases with more dense blocks"""
    model_conservative = _build_hybrid(num_sparse=1, num_dense=1)
    model_standard = _build_hybrid(num_sparse=1, num_dense=2)
    model_deep = _build_hybrid(num_sparse=1, num_dense=3)

    params_conservative = sum(p.numel() for p in model_conservative.parameters())
    params_standard = sum(p.numel() for p in model_standard.parameters())
    params_deep = sum(p.numel() for p in model_deep.parameters())

    # More dense blocks = more parameters
    assert params_standard > params_conservative
    assert params_deep > params_standard

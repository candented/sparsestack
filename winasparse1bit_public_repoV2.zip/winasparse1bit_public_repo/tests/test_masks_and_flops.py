import torch

from rl.config_applier import _apply_tau_to_lowbitlinear
from sparse_llm.layers import LowBitLinear


def test_tau_runtime_mask_counts():
    layer = LowBitLinear(5, 5, bias=False, delta=0.05)
    with torch.no_grad():
        layer.weight.copy_(torch.arange(25, dtype=torch.float32).view(5, 5))
    _apply_tau_to_lowbitlinear(layer, tau=0.2)  # keep ~20% = 5 weights
    assert layer.runtime_mask.sum().item() == 5
    _apply_tau_to_lowbitlinear(layer, tau=0.4)  # keep ~10 weights
    assert layer.runtime_mask.sum().item() == 10


def test_flops_ratio_scales_with_activation():
    layer = LowBitLinear(4, 4, bias=False, delta=0.05)
    with torch.no_grad():
        layer.weight.fill_(1.0)
    layer.runtime_mask = torch.ones_like(layer.weight)
    # density is 1.0; flops_ratio should scale with activation fraction
    base_density = (layer.get_effective_weight() != 0).float().mean().item()
    max_k_act = 0.75
    flops_values = []
    for k_act in (0.25, 0.50, 0.75):
        activation_scale = k_act / max_k_act
        flops_ratio = base_density * activation_scale
        flops_values.append(flops_ratio)
    assert flops_values[0] < flops_values[1] < flops_values[2]


def test_flops_proxy_combines_tau_and_k_act():
    layer = LowBitLinear(4, 4, bias=False, delta=0.05)
    with torch.no_grad():
        layer.weight.fill_(1.0)
    max_k_act = 0.75
    def flops_for(tau, k_act):
        _apply_tau_to_lowbitlinear(layer, tau)
        w_eff = layer.get_effective_weight()
        density = (w_eff != 0).float().mean().item()
        activation_scale = k_act / max_k_act
        return density * activation_scale

    # Increasing k_act at fixed tau should increase flops
    flops_tau01_low = flops_for(0.1, 0.25)
    flops_tau01_high = flops_for(0.1, 0.75)
    assert flops_tau01_low < flops_tau01_high

    flops_tau02_low = flops_for(0.2, 0.25)
    flops_tau02_high = flops_for(0.2, 0.75)
    assert flops_tau02_low < flops_tau02_high

    # Increasing tau at fixed k_act should not reduce flops
    assert flops_tau01_high <= flops_tau02_high

import ast
import random

import torch

from verifiers.symbolic_checker import SymbolicChecker
from utils import EGMHandler


def test_hard_mode_increases_length_and_range():
    random.seed(0)
    checker = SymbolicChecker(vocab_size=64, seq_len=32)
    task_spec = {
        "prompt_template": "{values}",
        "input_spec": {"variables": {"values": {"min_len": 3, "max_len": 3, "min_val": 0, "max_val": 1}}},
        "verifier_spec": {"checker": "ParityChecker", "mode": "ADD"},
    }
    prompt_med, _ = checker._sample_instance(task_spec, difficulty="medium")
    prompt_hard, _ = checker._sample_instance(task_spec, difficulty="hard")
    values_med = ast.literal_eval(prompt_med)
    values_hard = ast.literal_eval(prompt_hard)
    assert len(values_hard) >= len(values_med) + 1
    assert max(values_hard) >= max(values_med)


def test_local_variant_hard_mode_increases_task_params():
    random.seed(1)
    handler = EGMHandler(endpoint="")
    med = handler._generate_local_variants("medium")["variant_tasks"][0]
    hard = handler._generate_local_variants("hard")["variant_tasks"][0]
    med_vals = med["input_spec"]["variables"]["values"]
    hard_vals = hard["input_spec"]["variables"]["values"]
    assert hard_vals["min_len"] >= med_vals["min_len"]
    assert hard_vals["max_len"] > med_vals["max_len"]
    assert hard_vals["max_val"] > med_vals["max_val"]
    assert hard["difficulty"] == "hard"

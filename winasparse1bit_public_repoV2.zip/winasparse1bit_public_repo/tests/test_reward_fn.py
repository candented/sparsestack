import math

from rl.reward_fn import compute_reward


def test_penalty_when_accuracy_below_ref():
    lambdas = {"lambda_conn": 0.5, "lambda_act": 0.3, "lambda_prec": 0.2}
    reward = compute_reward(
        acc=0.7,
        ref_acc=0.9,
        flops=0.1,
        flops_ref=0.1,
        conn_sparsity=0.8,
        prec_sparsity=0.0,
        lambdas=lambdas,
    )
    # At least the accuracy gap should be directly subtracted.
    assert reward <= 0.5


def test_flops_penalty_when_more_expensive_than_ref():
    lambdas = {"lambda_conn": 0.5, "lambda_act": 0.3, "lambda_prec": 0.2}
    reward_dense = compute_reward(
        acc=0.9,
        ref_acc=0.9,
        flops=0.3,
        flops_ref=0.1,
        conn_sparsity=0.7,
        prec_sparsity=0.0,
        lambdas=lambdas,
    )
    reward_sparse = compute_reward(
        acc=0.9,
        ref_acc=0.9,
        flops=0.05,
        flops_ref=0.1,
        conn_sparsity=0.9,
        prec_sparsity=0.0,
        lambdas=lambdas,
    )
    assert reward_sparse > reward_dense


def test_conn_density_penalty():
    lambdas = {"lambda_conn": 0.0, "lambda_act": 0.5, "lambda_prec": 0.0}
    reward_dense = compute_reward(
        acc=0.9,
        ref_acc=0.9,
        flops=0.1,
        flops_ref=0.1,
        conn_sparsity=0.5,  # 50% sparsity
        prec_sparsity=0.0,
        lambdas=lambdas,
        config={"conn_sparsity_ref": 0.8},
    )
    reward_sparse = compute_reward(
        acc=0.9,
        ref_acc=0.9,
        flops=0.1,
        flops_ref=0.1,
        conn_sparsity=0.8,  # 80% sparsity
        prec_sparsity=0.0,
        lambdas=lambdas,
        config={"conn_sparsity_ref": 0.8},
    )
    assert reward_sparse > reward_dense


def test_flops_override_and_acc_penalty_scale():
    lambdas = {"lambda_conn": 0.5, "lambda_act": 0.0, "lambda_prec": 0.0}
    reward_override = compute_reward(
        acc=0.85,
        ref_acc=0.9,
        flops=0.15,
        flops_ref=0.2,
        conn_sparsity=0.8,
        prec_sparsity=0.0,
        lambdas=lambdas,
        config={"flops_ref_override": 0.05, "acc_penalty_scale": 2.0},
    )
    reward_no_override = compute_reward(
        acc=0.85,
        ref_acc=0.9,
        flops=0.15,
        flops_ref=0.2,
        conn_sparsity=0.8,
        prec_sparsity=0.0,
        lambdas=lambdas,
        config={"acc_penalty_scale": 1.0},
    )
    assert reward_override < reward_no_override


def test_precision_penalty():
    lambdas = {"lambda_conn": 0.0, "lambda_act": 0.0, "lambda_prec": 0.5}
    reward_prec_heavy = compute_reward(
        acc=0.9,
        ref_acc=0.9,
        flops=0.1,
        flops_ref=0.1,
        conn_sparsity=0.8,
        prec_sparsity=0.5,
        lambdas=lambdas,
    )
    reward_prec_light = compute_reward(
        acc=0.9,
        ref_acc=0.9,
        flops=0.1,
        flops_ref=0.1,
        conn_sparsity=0.8,
        prec_sparsity=0.1,
        lambdas=lambdas,
    )
    assert reward_prec_light > reward_prec_heavy


def test_flops_penalty_grows_beyond_override():
    lambdas = {"lambda_conn": 1.0, "lambda_act": 0.0, "lambda_prec": 0.0}
    cfg = {"flops_ref_override": 0.08, "acc_penalty_scale": 1.0}
    acc = 1.0
    conn = 0.8
    prec = 0.2

    reward_below = compute_reward(
        acc=acc,
        ref_acc=acc,
        flops=0.04,
        flops_ref=0.10,
        conn_sparsity=conn,
        prec_sparsity=prec,
        lambdas=lambdas,
        config=cfg,
    )
    reward_at = compute_reward(
        acc=acc,
        ref_acc=acc,
        flops=0.08,
        flops_ref=0.10,
        conn_sparsity=conn,
        prec_sparsity=prec,
        lambdas=lambdas,
        config=cfg,
    )
    reward_above = compute_reward(
        acc=acc,
        ref_acc=acc,
        flops=0.12,
        flops_ref=0.10,
        conn_sparsity=conn,
        prec_sparsity=prec,
        lambdas=lambdas,
        config=cfg,
    )
    reward_high = compute_reward(
        acc=acc,
        ref_acc=acc,
        flops=0.20,
        flops_ref=0.10,
        conn_sparsity=conn,
        prec_sparsity=prec,
        lambdas=lambdas,
        config=cfg,
    )

    assert reward_below >= reward_at
    assert reward_at > reward_above
    assert reward_above > reward_high


def test_flops_penalty_stronger_beyond_override_0075():
    lambdas = {"lambda_conn": 1.0, "lambda_act": 0.0, "lambda_prec": 0.0}
    cfg = {"flops_ref_override": 0.075, "acc_penalty_scale": 1.0, "conn_sparsity_ref": 0.8}
    acc = 1.0
    conn = 0.8  # match target to avoid conn penalty
    prec = 0.0

    reward_at = compute_reward(
        acc=acc,
        ref_acc=acc,
        flops=0.075,
        flops_ref=0.10,
        conn_sparsity=conn,
        prec_sparsity=prec,
        lambdas=lambdas,
        config=cfg,
    )
    reward_mid = compute_reward(
        acc=acc,
        ref_acc=acc,
        flops=0.10,
        flops_ref=0.10,
        conn_sparsity=conn,
        prec_sparsity=prec,
        lambdas=lambdas,
        config=cfg,
    )
    reward_high = compute_reward(
        acc=acc,
        ref_acc=acc,
        flops=0.20,
        flops_ref=0.10,
        conn_sparsity=conn,
        prec_sparsity=prec,
        lambdas=lambdas,
        config=cfg,
    )

    assert reward_at >= reward_mid
    assert reward_mid >= reward_high
    assert reward_high < reward_at - 0.01

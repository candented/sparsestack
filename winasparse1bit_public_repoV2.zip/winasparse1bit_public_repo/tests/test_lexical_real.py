
import pytest
import torch
import os
import json
from sparse_llm.datasets.lexical_real import LexicalRealDataset

@pytest.fixture
def sample_data_path(tmp_path):
    data = [
      {
        "word": "happy",
        "synonyms": ["joyful", "content"],
        "antonyms": ["sad", "unhappy"]
      },
      {
        "word": "fast",
        "synonyms": ["quick", "rapid"],
        "antonyms": ["slow", "sluggish"]
      },
      {
        "word": "cold",
        "synonyms": ["chilly", "freezing"],
        "antonyms": ["hot", "warm"]
      }
    ]
    p = tmp_path / "lexical_real_test.json"
    with open(p, "w") as f:
        json.dump(data, f)
    return str(p)

def test_dataset_initialization(sample_data_path):
    ds = LexicalRealDataset(sample_data_path, vocab_size=64, seq_len=16)
    assert len(ds.data) == 3
    assert ds.vocab_size == 64

def test_synonym_batch_shape(sample_data_path):
    ds = LexicalRealDataset(sample_data_path, vocab_size=64, seq_len=16)
    device = torch.device("cpu")
    batch_size = 4
    x, y = ds.build_synonym_batch(batch_size, device)
    
    assert x.shape == (batch_size, 16)
    assert y.shape == (batch_size,)
    assert x.dtype == torch.long
    assert y.dtype == torch.long
    
    # Check BOS/EOS/SEP
    # Our simple encoding: BOS=1, SEP=2, EOS=3
    # First token should be BOS
    assert (x[:, 0] == 1).all()
    # Should contain SEP
    assert (x == 2).any()

def test_antonym_batch_logic(sample_data_path):
    ds = LexicalRealDataset(sample_data_path, vocab_size=64, seq_len=16)
    device = torch.device("cpu")
    batch_size = 10
    x, y = ds.build_antonym_batch(batch_size, device)
    
    assert x.shape == (batch_size, 16)
    # Check that we have both positive and negative labels
    # (probabilistic, but with 10 samples it's highly likely)
    # If not, it's not a hard failure for a unit test, but good to inspect
    assert y.min() >= 0
    assert y.max() <= 1

def test_vocab_constraints(sample_data_path):
    # Ensure encoded tokens correspond to vocab_size
    vocab_size = 20 # small vocab
    ds = LexicalRealDataset(sample_data_path, vocab_size=vocab_size, seq_len=16)
    device = torch.device("cpu")
    x, _ = ds.build_synonym_batch(5, device)
    
    assert x.max() < vocab_size
    assert x.min() >= 0

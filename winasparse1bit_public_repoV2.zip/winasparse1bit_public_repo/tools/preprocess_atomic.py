"""
Preprocess ATOMIC 2020 dataset for Model Zero training.

Extracts causal and social reasoning knowledge from ATOMIC and converts
to JSONL format compatible with LexicalRealDataset.

Target relations:
- xIntent: Intentions behind actions
- xEffect: Effects of actions  
- xReact: Emotional reactions
- xWant: Desires after actions
- xNeed: Prerequisites for actions
"""

import csv
import json
import random
from pathlib import Path
from typing import List, Dict
from collections import defaultdict

# Configuration
INPUT_FILE = "data/raw/v4_atomic_trn.csv"
OUTPUT_FILE = "data/processed/atomic_causal_v1.jsonl"
TARGET_EXAMPLES = 50000
TRAIN_SPLIT = 0.8
VAL_SPLIT = 0.1

# Target relations
TARGET_RELATIONS = {
    'xIntent', 'xEffect', 'xReact', 'xWant', 'xNeed',
    'oEffect', 'oReact', 'oWant'  # Other-person relations
}

def load_atomic(input_file: str, max_examples: int = TARGET_EXAMPLES) -> List[Dict]:
    """Load and filter ATOMIC assertions"""
    print(f"Loading ATOMIC from {input_file}...")
    
    examples = []
    relation_counts = defaultdict(int)
    
    with open(input_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter='\t')
        
        for i, row in enumerate(reader):
            if i % 10000 == 0:
                print(f"  Processed {i:,} lines, found {len(examples):,} examples")
            
            head = row.get('head', '').strip()
            relation = row.get('relation', '').strip()
            tail = row.get('tail', '').strip()
            
            # Filter for target relations
            if relation not in TARGET_RELATIONS:
                continue
            
            # Skip empty or placeholder tails
            if not tail or tail == 'none' or tail == '___':
                continue
            
            # Create example
            example = create_example(head, tail, relation)
            if example:
                examples.append(example)
                relation_counts[relation] += 1
            
            # Stop if we have enough
            if len(examples) >= max_examples:
                break
    
    print(f"\n✅ Loaded {len(examples):,} examples")
    print("\nRelation distribution:")
    for rel, count in sorted(relation_counts.items(), key=lambda x: -x[1]):
        print(f"  {rel}: {count:,}")
    
    return examples

def create_example(head: str, tail: str, relation: str) -> Dict:
    """Convert ATOMIC triple to training example"""
    
    # Generate natural language question
    templates = {
        'xIntent': [
            f"If someone {head}, what is their intent?",
            f"Why would someone {head}?",
            f"What is the intention behind {head}?",
        ],
        'xEffect': [
            f"If someone {head}, what happens to them?",
            f"What is the effect of {head}?",
            f"After {head}, what happens?",
        ],
        'xReact': [
            f"If someone {head}, how do they feel?",
            f"What emotion does someone feel after {head}?",
            f"How would you react to {head}?",
        ],
        'xWant': [
            f"If someone {head}, what do they want next?",
            f"After {head}, what would someone want?",
            f"What desire follows {head}?",
        ],
        'xNeed': [
            f"To {head}, what do you need first?",
            f"What is required before {head}?",
            f"What prerequisite is needed for {head}?",
        ],
        'oEffect': [
            f"If someone {head}, what happens to others?",
            f"What effect does {head} have on others?",
            f"How does {head} affect other people?",
        ],
        'oReact': [
            f"If someone {head}, how do others feel?",
            f"What emotion do others feel when someone {head}?",
            f"How would others react to {head}?",
        ],
        'oWant': [
            f"If someone {head}, what do others want?",
            f"After someone {head}, what would others want?",
            f"What do others desire when someone {head}?",
        ],
    }
    
    if relation not in templates:
        return None
    
    # Randomly select template
    input_text = random.choice(templates[relation])
    
    return {
        'input': input_text,
        'target': tail,
        'category': 'atomic_causal',
        'relation': relation,
        'head': head,
        'tail': tail,
    }

def save_jsonl(examples: List[Dict], output_file: str):
    """Save examples to JSONL file"""
    print(f"\nSaving to {output_file}...")
    
    # Shuffle
    random.shuffle(examples)
    
    # Split
    n = len(examples)
    train_end = int(n * TRAIN_SPLIT)
    val_end = int(n * (TRAIN_SPLIT + VAL_SPLIT))
    
    train = examples[:train_end]
    val = examples[train_end:val_end]
    test = examples[val_end:]
    
    # Save
    base = Path(output_file).stem
    parent = Path(output_file).parent
    
    for split, data in [('train', train), ('val', val), ('test', test)]:
        path = parent / f"{base}_{split}.jsonl"
        with open(path, 'w', encoding='utf-8') as f:
            for ex in data:
                f.write(json.dumps(ex) + '\n')
        print(f"  ✅ {split}: {len(data):,} examples -> {path}")
    
    # Also save combined
    with open(output_file, 'w', encoding='utf-8') as f:
        for ex in examples:
            f.write(json.dumps(ex) + '\n')
    print(f"  ✅ combined: {len(examples):,} examples -> {output_file}")

def main():
    print("=" * 70)
    print("ATOMIC Preprocessing")
    print("=" * 70)
    
    # Load examples
    examples = load_atomic(INPUT_FILE, TARGET_EXAMPLES)
    
    # Save
    save_jsonl(examples, OUTPUT_FILE)
    
    print("\n" + "=" * 70)
    print("✅ Preprocessing complete!")
    print("=" * 70)

if __name__ == "__main__":
    random.seed(42)
    main()

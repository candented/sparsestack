import json
import nltk
from nltk.corpus import wordnet as wn
import random
import os

def download_wordnet():
    try:
        wn.ensure_loaded()
    except LookupError:
        print("Downloading WordNet...")
        nltk.download('wordnet')
        nltk.download('omw-1.4')

def get_synonyms_antonyms(word):
    synonyms = set()
    antonyms = set()
    
    for syn in wn.synsets(word):
        for lemma in syn.lemmas():
            # Synonyms
            lemma_name = lemma.name().replace('_', ' ').lower()
            if lemma_name != word:
                synonyms.add(lemma_name)
            
            # Antonyms
            if lemma.antonyms():
                for ant in lemma.antonyms():
                    ant_name = ant.name().replace('_', ' ').lower()
                    antonyms.add(ant_name)
                    
    return list(synonyms), list(antonyms)

def generate_dataset(output_path, num_words=1000):
    # A small list of seed words to start with - common English words
    # In a real heavy production run, we might use a frequency list
    seed_words = [
        "good", "bad", "happy", "sad", "fast", "slow", "big", "small", "hot", "cold",
        "light", "dark", "hard", "soft", "loud", "quiet", "love", "hate", "true", "false",
        "up", "down", "left", "right", "in", "out", "start", "stop", "win", "lose",
        "clean", "dirty", "empty", "full", "wet", "dry", "rich", "poor", "strong", "weak",
        "young", "old", "new", "antique", "brave", "cowardly", "calm", "angry",
        "clever", "stupid", "cheap", "expensive", "deep", "shallow", "heavy", "light"
    ]
    
    # Expand seed words by looking at their synonyms/antonyms recursively one level could be cool
    # But for v0, let's just stick to a robust list.
    # We can also iterate over all synsets? That might be too big.
    # Let's use common adjectives and verbs from WordNet?
    
    # Better strategy: Iterate over some common synsets
    dataset = []
    seen_words = set()
    
    # Collect words from seed
    corpus = set(seed_words)
    
    # Naive expansion: add synonyms of seeds to corpus
    for w in seed_words:
        syns, ants = get_synonyms_antonyms(w)
        corpus.update(syns)
        corpus.update(ants)
        
    print(f"Candidate corpus size: {len(corpus)}")
    
    for word in corpus:
        if word in seen_words:
            continue
            
        syns, ants = get_synonyms_antonyms(word)
        
        # Filter: we want words that actually have relations
        if not syns and not ants:
            continue
            
        entry = {
            "word": word,
            "synonyms": syns,
            "antonyms": ants
        }
        dataset.append(entry)
        seen_words.add(word)
        
    # Validation/stats
    with_syn = len([d for d in dataset if d['synonyms']])
    with_ant = len([d for d in dataset if d['antonyms']])
    print(f"Generated {len(dataset)} entries.")
    print(f"Entries with synonyms: {with_syn}")
    print(f"Entries with antonyms: {with_ant}")
    
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w') as f:
        json.dump(dataset, f, indent=2)
    print(f"Saved to {output_path}")

if __name__ == "__main__":
    download_wordnet()
    generate_dataset("data/lexical_real_v0.json")

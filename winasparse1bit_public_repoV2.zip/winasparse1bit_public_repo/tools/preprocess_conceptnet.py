"""
Preprocess ConceptNet 5.7 dataset for Model Zero training.

Extracts functional and relational knowledge from ConceptNet and converts
to JSONL format compatible with LexicalRealDataset.

Target relations:
- UsedFor: Functional relations
- CapableOf: Capability relations
- HasProperty: Attribute relations
- IsA: Taxonomic relations
- PartOf: Compositional relations
"""

import csv
import json
import random
from pathlib import Path
from typing import List, Dict
from collections import defaultdict

# Configuration
INPUT_FILE = "data/raw/conceptnet-assertions-5.7.0.csv"
OUTPUT_FILE = "data/processed/conceptnet_relations_v1.jsonl"
MIN_WEIGHT = 1.0  # Minimum edge confidence
TARGET_EXAMPLES = 50000
TRAIN_SPLIT = 0.8
VAL_SPLIT = 0.1

# Target relations
TARGET_RELATIONS = {
    'UsedFor', 'CapableOf', 'HasProperty', 
    'IsA', 'PartOf', 'AtLocation', 'Causes'
}

def parse_conceptnet_uri(uri: str) -> str:
    """Extract concept from ConceptNet URI"""
    # /c/en/knife/n -> knife
    parts = uri.split('/')
    if len(parts) >= 4 and parts[2] == 'en':
        return parts[3].replace('_', ' ')
    return None

def load_conceptnet(input_file: str, max_examples: int = TARGET_EXAMPLES) -> List[Dict]:
    """Load and filter ConceptNet assertions"""
    print(f"Loading ConceptNet from {input_file}...")
    
    examples = []
    relation_counts = defaultdict(int)
    
    with open(input_file, 'r', encoding='utf-8') as f:
        reader = csv.reader(f, delimiter='\t')
        
        for i, row in enumerate(reader):
            if i % 100000 == 0:
                print(f"  Processed {i:,} lines, found {len(examples):,} examples")
            
            if len(row) < 5:
                continue
            
            uri, relation, start, end, metadata = row[:5]
            
            # Parse relation
            rel_parts = relation.split('/')
            if len(rel_parts) < 3:
                continue
            rel_name = rel_parts[2]
            
            # Filter for target relations
            if rel_name not in TARGET_RELATIONS:
                continue
            
            # Parse metadata for weight
            try:
                meta_dict = json.loads(metadata)
                weight = meta_dict.get('weight', 0.0)
            except:
                weight = 0.0
            
            # Filter by weight
            if weight < MIN_WEIGHT:
                continue
            
            # Extract concepts
            head = parse_conceptnet_uri(start)
            tail = parse_conceptnet_uri(end)
            
            if not head or not tail:
                continue
            
            # Create example
            example = create_example(head, tail, rel_name)
            if example:
                examples.append(example)
                relation_counts[rel_name] += 1
            
            # Stop if we have enough
            if len(examples) >= max_examples:
                break
    
    print(f"\n✅ Loaded {len(examples):,} examples")
    print("\nRelation distribution:")
    for rel, count in sorted(relation_counts.items(), key=lambda x: -x[1]):
        print(f"  {rel}: {count:,}")
    
    return examples

def create_example(head: str, tail: str, relation: str) -> Dict:
    """Convert ConceptNet triple to training example"""
    
    # Generate natural language question
    templates = {
        'UsedFor': [
            f"Is {head} used for {tail}?",
            f"Can you use {head} for {tail}?",
            f"{head} is used for {tail}",
        ],
        'CapableOf': [
            f"Can {head} {tail}?",
            f"Is {head} capable of {tail}?",
            f"{head} can {tail}",
        ],
        'HasProperty': [
            f"Is {head} {tail}?",
            f"Does {head} have the property {tail}?",
            f"{head} is {tail}",
        ],
        'IsA': [
            f"Is {head} a type of {tail}?",
            f"Is {head} a {tail}?",
            f"{head} is a {tail}",
        ],
        'PartOf': [
            f"Is {head} part of {tail}?",
            f"Does {tail} contain {head}?",
            f"{head} is part of {tail}",
        ],
        'AtLocation': [
            f"Can you find {head} at {tail}?",
            f"Is {head} located at {tail}?",
            f"{head} is at {tail}",
        ],
        'Causes': [
            f"Does {head} cause {tail}?",
            f"Can {head} lead to {tail}?",
            f"{head} causes {tail}",
        ],
    }
    
    if relation not in templates:
        return None
    
    # Randomly select template
    input_text = random.choice(templates[relation])
    
    return {
        'input': input_text,
        'target': 'True',  # All extracted relations are positive examples
        'category': 'conceptnet_relation',
        'relation': relation,
        'head': head,
        'tail': tail,
    }

def create_negative_examples(positive_examples: List[Dict], ratio: float = 0.3) -> List[Dict]:
    """Create negative examples by shuffling tails"""
    print(f"\nCreating negative examples (ratio={ratio})...")
    
    num_negatives = int(len(positive_examples) * ratio)
    negatives = []
    
    # Group by relation
    by_relation = defaultdict(list)
    for ex in positive_examples:
        by_relation[ex['relation']].append(ex)
    
    for relation, examples in by_relation.items():
        n_neg = int(len(examples) * ratio)
        
        for _ in range(n_neg):
            # Pick random example
            ex1 = random.choice(examples)
            ex2 = random.choice(examples)
            
            # Create negative by swapping tail
            head = ex1['head']
            tail = ex2['tail']  # Wrong tail
            
            # Generate question (use first template for consistency)
            templates = {
                'UsedFor': f"Is {head} used for {tail}?",
                'CapableOf': f"Can {head} {tail}?",
                'HasProperty': f"Is {head} {tail}?",
                'IsA': f"Is {head} a {tail}?",
                'PartOf': f"Is {head} part of {tail}?",
                'AtLocation': f"Can you find {head} at {tail}?",
                'Causes': f"Does {head} cause {tail}?",
            }
            
            negatives.append({
                'input': templates.get(relation, f"{head} {relation} {tail}?"),
                'target': 'False',
                'category': 'conceptnet_relation_negative',
                'relation': relation,
                'head': head,
                'tail': tail,
            })
    
    print(f"✅ Created {len(negatives):,} negative examples")
    return negatives

def save_jsonl(examples: List[Dict], output_file: str):
    """Save examples to JSONL file"""
    print(f"\nSaving to {output_file}...")
    
    # Shuffle
    random.shuffle(examples)
    
    # Split
    n = len(examples)
    train_end = int(n * TRAIN_SPLIT)
    val_end = int(n * (TRAIN_SPLIT + VAL_SPLIT))
    
    train = examples[:train_end]
    val = examples[train_end:val_end]
    test = examples[val_end:]
    
    # Save
    base = Path(output_file).stem
    parent = Path(output_file).parent
    
    for split, data in [('train', train), ('val', val), ('test', test)]:
        path = parent / f"{base}_{split}.jsonl"
        with open(path, 'w', encoding='utf-8') as f:
            for ex in data:
                f.write(json.dumps(ex) + '\n')
        print(f"  ✅ {split}: {len(data):,} examples -> {path}")
    
    # Also save combined
    with open(output_file, 'w', encoding='utf-8') as f:
        for ex in examples:
            f.write(json.dumps(ex) + '\n')
    print(f"  ✅ combined: {len(examples):,} examples -> {output_file}")

def main():
    print("=" * 70)
    print("ConceptNet Preprocessing")
    print("=" * 70)
    
    # Load positive examples
    positive = load_conceptnet(INPUT_FILE, TARGET_EXAMPLES)
    
    # Create negative examples
    negative = create_negative_examples(positive, ratio=0.3)
    
    # Combine
    all_examples = positive + negative
    print(f"\n✅ Total: {len(all_examples):,} examples")
    print(f"   Positive: {len(positive):,} ({len(positive)/len(all_examples)*100:.1f}%)")
    print(f"   Negative: {len(negative):,} ({len(negative)/len(all_examples)*100:.1f}%)")
    
    # Save
    save_jsonl(all_examples, OUTPUT_FILE)
    
    print("\n" + "=" * 70)
    print("✅ Preprocessing complete!")
    print("=" * 70)

if __name__ == "__main__":
    random.seed(42)
    main()

"""
Merge ConceptNet and ATOMIC datasets into hybrid relational dataset.

Creates combined dataset with both functional relations (ConceptNet)
and causal reasoning (ATOMIC) for comprehensive relational training.
"""

import json
import random
from pathlib import Path
from typing import List, Dict

# Configuration
CONCEPTNET_FILE = "data/processed/conceptnet_relations_v1.jsonl"
ATOMIC_FILE = "data/processed/atomic_causal_v1.jsonl"
OUTPUT_FILE = "data/processed/hybrid_relational_v1.jsonl"
TRAIN_SPLIT = 0.8
VAL_SPLIT = 0.1

def load_jsonl(file_path: str) -> List[Dict]:
    """Load JSONL file"""
    examples = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            examples.append(json.loads(line))
    return examples

def save_jsonl(examples: List[Dict], output_file: str):
    """Save examples to JSONL file with train/val/test splits"""
    print(f"\nSaving to {output_file}...")
    
    # Shuffle
    random.shuffle(examples)
    
    # Split
    n = len(examples)
    train_end = int(n * TRAIN_SPLIT)
    val_end = int(n * (TRAIN_SPLIT + VAL_SPLIT))
    
    train = examples[:train_end]
    val = examples[train_end:val_end]
    test = examples[val_end:]
    
    # Save
    base = Path(output_file).stem
    parent = Path(output_file).parent
    
    for split, data in [('train', train), ('val', val), ('test', test)]:
        path = parent / f"{base}_{split}.jsonl"
        with open(path, 'w', encoding='utf-8') as f:
            for ex in data:
                f.write(json.dumps(ex) + '\n')
        print(f"  ✅ {split}: {len(data):,} examples -> {path}")
    
    # Also save combined
    with open(output_file, 'w', encoding='utf-8') as f:
        for ex in examples:
            f.write(json.dumps(ex) + '\n')
    print(f"  ✅ combined: {len(examples):,} examples -> {output_file}")

def main():
    print("=" * 70)
    print("Merging ConceptNet + ATOMIC")
    print("=" * 70)
    
    # Load datasets
    print(f"\nLoading ConceptNet from {CONCEPTNET_FILE}...")
    conceptnet = load_jsonl(CONCEPTNET_FILE)
    print(f"  ✅ Loaded {len(conceptnet):,} examples")
    
    print(f"\nLoading ATOMIC from {ATOMIC_FILE}...")
    atomic = load_jsonl(ATOMIC_FILE)
    print(f"  ✅ Loaded {len(atomic):,} examples")
    
    # Merge
    all_examples = conceptnet + atomic
    print(f"\n✅ Total: {len(all_examples):,} examples")
    print(f"   ConceptNet: {len(conceptnet):,} ({len(conceptnet)/len(all_examples)*100:.1f}%)")
    print(f"   ATOMIC: {len(atomic):,} ({len(atomic)/len(all_examples)*100:.1f}%)")
    
    # Save
    save_jsonl(all_examples, OUTPUT_FILE)
    
    print("\n" + "=" * 70)
    print("✅ Merge complete!")
    print("=" * 70)

if __name__ == "__main__":
    random.seed(42)
    main()

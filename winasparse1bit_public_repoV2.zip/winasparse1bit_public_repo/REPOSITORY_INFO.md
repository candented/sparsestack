# Repository Info — WINASPARSE1BIT

This repository accompanies the preprint
**"WINASPARSE1BIT: Weight-Informed Neuron Activation with Stacked 1.58-Bit
Sparsity for Efficient Sparse Transformers"** (v2, June 2026).

The preprint PDF is included at
[`docs/WINASPARSE1BIT_arxiv_v2.pdf`](docs/WINASPARSE1BIT_arxiv_v2.pdf).

Author: J B Swann · Independent Research · Project Kingstun · Charleston, SC.

---

## Scope

This is the **clean, sanitised public release** of the WINASPARSE1BIT
research codebase. It contains exactly the files needed to:

- Read the preprint and follow its claims
- Reproduce the headline classification results
  (Phases 7 / 8 / 9a / 12 / 13 / iter7_hifi)
- Exercise the cross-task circuit-transfer protocol
- Run the mechanistic interpretability analysis
- Train the causal LM track and verify the sparse-mode bypass fix

It does **not** contain training logs, checkpoints, generated datasets,
or internal planning documents. See [FILE_MANIFEST.md](FILE_MANIFEST.md)
for the full file inventory and the explicit exclusion list.

---

## Versioning

| Tag | Date | Paper version | Key additions |
|---|---|---|---|
| `v1-paper-2026-01` | 2026-01-29 | v1 (Jan 2026) | Initial release |
| **`v2-preprint-2026-06`** | **2026-06-08** | **v2 (Jun 2026)** | **LM track, iter7_hifi, transfer, mech-interp, Zenodo metadata** |

See [CHANGELOG.md](CHANGELOG.md) for the v1 → v2 file delta.

---

## Zenodo deposit

This repository is configured for automatic Zenodo archival on GitHub
release.

### One-time setup (author task)

1. Sign in at https://zenodo.org/ with the same identity used on GitHub.
2. Visit https://zenodo.org/account/settings/github/ and toggle the
   `jbswann/winasparse1bit` repository **on**.
3. The next GitHub release will trigger automatic Zenodo archival.

### Per-release workflow

1. Update `version:` and `date-released:` in
   [`CITATION.cff`](CITATION.cff).
2. Update the changelog in [`CHANGELOG.md`](CHANGELOG.md).
3. (If applicable) update the preprint and rebuild
   [`docs/WINASPARSE1BIT_arxiv_v2.pdf`](docs/WINASPARSE1BIT_arxiv_v2.pdf)
   via `bash docs/compile_preprint.sh`.
4. Commit, push, and create a GitHub release with tag matching
   `version:` (e.g. `v2-preprint-2026-06`). Use the changelog entry as
   the release notes.
5. Zenodo picks up the release automatically and assigns a DOI within
   a few minutes.
6. Once the DOI is assigned:
   - Uncomment and fill in the `doi:` field in
     [`CITATION.cff`](CITATION.cff)
   - Update the DOI badge URL in [`README.md`](README.md) (replace
     `pending`)
   - Update the BibTeX `@software` entry in
     [`README.md`](README.md) (replace `10.5281/zenodo.PENDING`)
   - Reciprocally add the Zenodo DOI to the preprint's Code
     Availability section
7. Commit those changes as a small follow-up to make all citations
   resolve forwards and backwards.

### Metadata source-of-truth

Zenodo reads metadata in the following priority order:

1. [`.zenodo.json`](.zenodo.json) — explicit deposit metadata, has
   precedence over everything else
2. [`CITATION.cff`](CITATION.cff) — fallback for authors and title
3. GitHub repository description and topics

We populate `.zenodo.json` exhaustively so the Zenodo listing matches
the preprint's metadata exactly, including:

- Title (matches preprint exactly)
- Authors (currently J B Swann, single author)
- Keywords (matches preprint keywords list)
- License (MIT)
- Description (~250-word HTML summary)
- Related identifiers (points back to the GitHub repo as preprint
  supplement)

When the arXiv ID is assigned, add a second `related_identifiers`
entry to `.zenodo.json` linking the Zenodo deposit to the arXiv paper
via `relation: isSupplementTo`. This creates the reciprocal pairing
that arXiv and Zenodo can both display.

---

## Quick verification

```bash
# Confirm the preprint compiles
bash docs/compile_preprint.sh

# Confirm tests pass
pip install -r requirements.txt
pytest tests/ -v

# Generate the lexical dataset (~5 min)
python tools/generate_lexical_deep.py

# Reproduce Phase 8 single-seed (~2 hr on RTX 4090)
python main.py preset=model_zero_scaled_v1 training.seed=42
```

The Phase 8 multi-seed protocol uses seeds {42, 101, 777, 999} and is
documented in the preprint's Reproducibility section (§10).

---

## License

[MIT](LICENSE). Permissive academic and commercial use; please cite
both the software (Zenodo DOI) and the preprint if you build on this
work.

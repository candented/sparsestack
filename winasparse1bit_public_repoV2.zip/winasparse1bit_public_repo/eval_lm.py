"""
Phase 15: Perplexity Evaluation for CausalSparseTransformer.

Usage:
    python eval_lm.py --checkpoint checkpoints/phase15/.../best --dataset roneneldan/TinyStories --split validation
    python eval_lm.py --checkpoint checkpoints/phase15/.../final --mode full_sparse
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import torch
import torch.nn.functional as F

from sparse_llm.causal_transformer import CausalSparseTransformer
from sparse_llm.datasets.lm_dataset import build_lm_dataloader
from train_lm import load_checkpoint


@torch.no_grad()
def evaluate_perplexity(
    model: CausalSparseTransformer,
    dataloader,
    device: torch.device,
    mode: str = "dense",
    max_batches: int = 200,
    **sparse_kwargs,
) -> dict:
    """Compute perplexity and per-token accuracy on a dataset."""
    model.eval()
    total_loss = 0.0
    total_correct = 0
    total_tokens = 0
    num_batches = 0

    for batch in dataloader:
        input_ids = batch["input_ids"].to(device)
        labels = batch["labels"].to(device)

        with torch.amp.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=device.type == "cuda"):
            logits, log = model(input_ids, mode=mode, **sparse_kwargs)

        loss = F.cross_entropy(
            logits.view(-1, model.vocab_size),
            labels.view(-1),
            ignore_index=-100,
            reduction="sum",
        )

        # Per-token accuracy
        preds = logits.argmax(dim=-1)
        mask = labels != -100
        correct = ((preds == labels) & mask).sum().item()

        total_loss += loss.item()
        total_correct += correct
        total_tokens += mask.sum().item()
        num_batches += 1

        if num_batches >= max_batches:
            break

    avg_loss = total_loss / max(1, total_tokens)
    perplexity = math.exp(min(avg_loss, 20))
    accuracy = total_correct / max(1, total_tokens)

    # Sparsity stats from last batch log
    sparsity_info = {}
    if mode != "dense" and log:
        sparsity_info = {
            "active_neurons": log.get("active_neurons", 0),
            "total_neurons": log.get("total_neurons", 0),
        }

    return {
        "loss": avg_loss,
        "perplexity": perplexity,
        "accuracy": accuracy,
        "total_tokens": total_tokens,
        "num_batches": num_batches,
        "mode": mode,
        **sparsity_info,
    }


def main():
    parser = argparse.ArgumentParser(description="Evaluate CausalSparseTransformer perplexity")
    parser.add_argument("--checkpoint", type=str, required=True)
    parser.add_argument("--dataset", type=str, default="roneneldan/TinyStories")
    parser.add_argument("--split", type=str, default="validation")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--max-batches", type=int, default=200)
    parser.add_argument("--seq-len", type=int, default=512)
    parser.add_argument("--mode", type=str, default="dense", help="dense, circuit_masked, full_sparse")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()

    device = torch.device(args.device)

    # Load model
    print(f"Loading checkpoint: {args.checkpoint}")
    model, _, step = load_checkpoint(Path(args.checkpoint), device)
    param_info = model.count_parameters()
    print(f"Model: {param_info['unique']/1e6:.1f}M params, step {step}")

    # Build eval dataloader
    cfg = {
        "lm": {
            "dataset": args.dataset,
            "seq_len": args.seq_len,
            "tokenizer": "gpt2",
            "streaming": False,
        },
        "training": {"batch_size": args.batch_size},
    }

    print(f"Loading {args.dataset} ({args.split})...")
    dataloader = build_lm_dataloader(cfg, split=args.split, batch_size=args.batch_size)

    # Evaluate
    print(f"Evaluating (mode={args.mode}, max_batches={args.max_batches})...")
    results = evaluate_perplexity(model, dataloader, device, mode=args.mode, max_batches=args.max_batches)

    print("\n" + "=" * 50)
    print(f"RESULTS ({args.mode} mode)")
    print("=" * 50)
    print(f"  Loss:       {results['loss']:.4f}")
    print(f"  Perplexity: {results['perplexity']:.2f}")
    print(f"  Accuracy:   {results['accuracy']:.4f} ({results['accuracy']*100:.2f}%)")
    print(f"  Tokens:     {results['total_tokens']:,}")
    print(f"  Batches:    {results['num_batches']}")

    if results.get("active_neurons"):
        ratio = results["active_neurons"] / max(1, results["total_neurons"])
        print(f"  Neuron activity: {results['active_neurons']:.0f}/{results['total_neurons']:.0f} ({ratio:.2%})")
    print("=" * 50)


if __name__ == "__main__":
    main()

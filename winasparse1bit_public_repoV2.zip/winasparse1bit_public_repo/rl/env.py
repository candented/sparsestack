from __future__ import annotations

from typing import Dict, List, Tuple
from datetime import datetime
import json
import math

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import deque

from rl.config_applier import apply_config_to_model
from rl.config_space import ConfigAction, build_action_grids, decode_action
from rl.reward_fn import compute_reward, compute_geometric_reward
from sparse_llm.layers import LowBitLinear
from sparse_llm.utils import ensure_dir
from verifiers.oct_manifold import build_oct_batch
from verifiers.symbolic_checker import SymbolicChecker
from sparse_llm.datasets.lexical_real import LexicalRealDataset
from sparse_llm.datasets.logical import LogicalDataset
from sparse_llm.datasets.fld_loader import FLDDataset
from sparse_llm.datasets.math_cot_loader import MathCoTDataset
import os


class ConfigEnv:
    def __init__(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        cfg: Dict[str, object],
        egm_handler,
        lambda_scheduler,
        device: torch.device,
    ) -> None:
        self.model = model.to(device)
        self.optimizer = optimizer
        self.cfg = cfg
        self.egm_handler = egm_handler
        self.lambda_scheduler = lambda_scheduler
        self.device = device

        self.grids = build_action_grids(cfg)
        training_cfg = cfg.get("training", {})
        self.reward_cfg = cfg.get("reward", {})
        self.pd_cfg = cfg.get("prediction_delta", {})
        self.task_family = training_cfg.get("task_family", "symbolic")
        self.difficulty = training_cfg.get("difficulty", "medium")
        self.curriculum_cfg = training_cfg.get("curriculum", {}) or {}
        num_tau = len(self.grids["tau_values"])
        num_delta = len(self.grids["delta_values"])
        num_kact = len(self.grids["kact_values"])
        num_mode = len(self.grids["mode_values"])
        mode_mid = num_mode // 2 if num_mode > 0 else 0
        self.ref_action = ConfigAction(
            tau_idx=num_tau // 2,
            delta_idx=num_delta // 2,
            kact_idx=num_kact // 2,
            mode_idx=min(mode_mid, max(0, num_mode - 1)),
        )
        self.ref_config_values = decode_action(self.ref_action, self.grids)
        print(
            "[DEBUG] ref_config "
            f"tau={self.ref_config_values['tau']:.2f} delta={self.ref_config_values['delta']:.3f} "
            f"k_act={self.ref_config_values['k_act']:.2f} mode={self.ref_config_values['mode']}"
        )
        self.global_step = 0
        self.recent_performance: List[Dict[str, float]] = []
        self.batch_size = int(training_cfg.get("batch_size", 32))
        self.debug_weights_every = int(training_cfg.get("debug_weights_every", 0))
        self.use_harder_eval_slice = bool(self.pd_cfg.get("use_harder_eval_slice", False))
        self.hard_pool: deque = deque(maxlen=32)

        self.current_config_values = dict(self.ref_config_values)

        vocab_size = getattr(getattr(model, "token_emb", None), "num_embeddings", 128)
        seq_len = getattr(model, "seq_len", 32)
        self.symbolic_checker = SymbolicChecker(vocab_size=vocab_size, seq_len=seq_len)
        self.prev_metrics = {"acc": 0.0, "loss": 0.0}
        self.last_delta_ratio = None
        
        self.lexical_real_ds = None
        if self.task_family == "lexical_real":
             data_path = training_cfg.get("lexical_real_path", "data/lexical_real_v0.json")
             if not os.path.exists(data_path):
                 print(f"[WARN] Lexical real data not found at {data_path}, integration will fail if batch requested.")
             else:
                 self.lexical_real_ds = LexicalRealDataset(data_path, vocab_size=vocab_size, seq_len=seq_len)

        # Phase 11: Logical dataset for multi-step reasoning tasks
        self.logical_ds = None
        if self.task_family == "logical":
            logical_cfg = training_cfg.get("logical", {}) or {}
            self.logical_ds = LogicalDataset(
                vocab_size=vocab_size,
                seq_len=seq_len,
                task_type=logical_cfg.get("task_type", "implication"),
                chain_depth=int(logical_cfg.get("chain_depth", 3)),
                recursive_steps=int(logical_cfg.get("recursive_steps", 2)),
                num_clauses=int(logical_cfg.get("num_clauses", 3)),
                num_vars=int(logical_cfg.get("num_vars", 4)),
            )

        # Phase 13: FLD (Formal Logic Deduction) dataset
        self.fld_ds = None
        if self.task_family == "fld":
            fld_cfg = training_cfg.get("fld", {}) or {}
            self.fld_ds = FLDDataset(
                vocab_size=vocab_size,
                seq_len=seq_len,
                task_type=fld_cfg.get("task_type", "mixed"),
                include_trace=fld_cfg.get("include_trace", True),
            )

        # Phase 13/14: Math CoT dataset (OpenMathInstruct-2 / GSM8K / Synthetic)
        self.math_cot_ds = None
        if self.task_family == "math_cot":
            math_cfg = training_cfg.get("math_cot", {}) or {}
            self.math_cot_ds = MathCoTDataset(
                vocab_size=vocab_size,
                seq_len=seq_len,
                task_type=math_cfg.get("task_type", "word_problem"),
                difficulty=self.difficulty,
                max_samples=math_cfg.get("max_samples", 10000),
                use_hf=math_cfg.get("use_hf", False),  # Default to synthetic for speed
            )

    def reset(self) -> torch.Tensor:
        self.global_step = 0
        apply_config_to_model(self.model, self.ref_config_values)
        self.current_config_values = dict(self.ref_config_values)
        self.prev_metrics = {"acc": 0.0, "loss": 0.0}
        flops_ratio, conn_sparsity, prec_sparsity = self._gather_model_stats()
        return self._build_state(
            acc_prev=0.0,
            loss_prev=0.0,
            ref_acc=0.0,
            flops_ratio=flops_ratio,
            conn_sparsity=conn_sparsity,
            prec_sparsity=prec_sparsity,
            tau_prev=self.ref_config_values.get("tau", 0.0),
            k_act_prev=self.ref_config_values.get("k_act", 0.0),
        )

    def step(self, action: ConfigAction):
        self.global_step += 1
        config_values = decode_action(action, self.grids)
        apply_config_to_model(self.model, config_values)
        self.current_config_values = dict(config_values)

        variants = self.egm_handler.fetch_variants(self.recent_performance)
        tasks = variants.get("variant_tasks", [])
        if not tasks:
            raise RuntimeError("EGM handler returned no variant tasks")
        task_spec = tasks[0]

        if self.task_family == "oct":
            x_batch, y_batch, meta = self._build_task_batch(
                task_spec,
                task_family=self.task_family,
                difficulty=self.difficulty,
                use_harder_eval_slice=False,
                batch_size=self.batch_size,
            )
            train_loss, geo_score, norm_drift = self._train_step_oct(x_batch, y_batch)
            geo_eval = self._eval_metrics_oct(x_batch, y_batch)
            eval_loss = float((1 - geo_eval["cos"]).mean().item())
            flops_ratio, conn_sparsity, prec_sparsity = self._gather_model_stats()
            lambdas = self.lambda_scheduler(self.global_step)
            geo_reward = compute_geometric_reward(
                geo_eval["pred"], geo_eval["target"], geo_eval["input"], lambda_mag=float(self.reward_cfg.get("geo_lambda_mag", 0.0))
            )
            geo_reward_mean = float(geo_reward.mean().item())
            reward = float(self.reward_cfg.get("geo_weight", 1.0)) * geo_reward_mean - lambdas.get("lambda_prec", 0.0) * flops_ratio
            acc = float(geo_eval["cos"].mean().item())
            ref_acc = acc
            flops_ref = flops_ratio
            conn_sparsity_ref = conn_sparsity
            prec_sparsity_ref = prec_sparsity
            if self.global_step % 500 == 0:
                print(
                    f"[DEBUG] step={self.global_step} geo_cos={acc:.3f} norm_drift={float(norm_drift):.3f} "
                    f"flops={flops_ratio:.3f} active_rot={getattr(self.model, 'rot', None).active_fraction() if hasattr(self.model, 'rot') else 0.0}"
                )
        else:
            x_batch, y_batch, meta = self._build_task_batch(
                task_spec,
                task_family=self.task_family,
                difficulty=self.difficulty,
                use_harder_eval_slice=False,
                batch_size=self.batch_size,
            )
            train_loss = self._train_step(x_batch, y_batch)
            eval_loss, _ = self._eval_metrics(x_batch, y_batch)
            acc, flops_ratio, conn_sparsity, prec_sparsity = self._eval_accuracy_for_action(
                x_batch, y_batch, action, tag="pi"
            )
            ref_acc, flops_ref, conn_sparsity_ref, prec_sparsity_ref = self._eval_accuracy_for_action(
                x_batch, y_batch, self.ref_action, tag="ref"
            )
            if self.use_harder_eval_slice and ref_acc < 1.0:
                self.hard_pool.append((x_batch.detach().cpu(), y_batch.detach().cpu()))
            apply_config_to_model(self.model, config_values)
            if self.global_step % 500 == 0:
                print(
                    f"[DEBUG] step={self.global_step} tau={config_values['tau']:.2f} "
                    f"delta={config_values['delta']:.3f} k_act={config_values['k_act']:.2f}"
                )
                print(
                    f"[DEBUG] step={self.global_step} flops_ratio={flops_ratio:.3f} "
                    f"conn_sparsity={conn_sparsity:.3f} prec_sparsity={prec_sparsity:.3f}"
                )

            lambdas = self.lambda_scheduler(self.global_step)
            reward = compute_reward(
                acc=acc,
                ref_acc=ref_acc,
                flops=flops_ratio,
                flops_ref=flops_ref,
                conn_sparsity=conn_sparsity,
                prec_sparsity=prec_sparsity,
                lambdas=lambdas,
                config={
                    "conn_sparsity_ref": self.reward_cfg.get("conn_sparsity_ref", conn_sparsity_ref),
                    "flops_ref_override": self.reward_cfg.get("flops_ref_override"),
                    "acc_penalty_scale": self.reward_cfg.get("acc_penalty_scale", 1.0),
                },
            )

        self.prev_metrics = {"acc": acc, "loss": eval_loss}
        self._update_recent_performance(task_spec.get("task_id", "unknown"), acc, config_values)

        state = self._build_state(
            acc_prev=acc,
            loss_prev=eval_loss,
            ref_acc=ref_acc,
            flops_ratio=flops_ratio,
            conn_sparsity=conn_sparsity,
            prec_sparsity=prec_sparsity,
            tau_prev=config_values.get("tau", 0.0),
            k_act_prev=config_values.get("k_act", 0.0),
        )
        done = False
        info = {
            "acc": acc,
            "ref_acc": ref_acc,
            "flops_ratio": flops_ratio,
            "flops_ratio_ref": flops_ref,
            "conn_sparsity": conn_sparsity,
            "prec_sparsity": prec_sparsity,
            "train_loss": train_loss,
            "lambdas": lambdas,
            "tau": config_values["tau"],
            "delta": config_values["delta"],
            "k_act": config_values["k_act"],
        }
        return state, reward, done, info

    def _build_task_batch(
        self,
        task_spec: Dict[str, object],
        *,
        task_family: str,
        difficulty: str,
        use_harder_eval_slice: bool,
        batch_size: int | None = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, Dict[str, float]]:
        effective_batch = batch_size or self.batch_size
        effective_difficulty = "hard" if use_harder_eval_slice else difficulty
        family = task_family
        # Curriculum routing
        cur = self.curriculum_cfg or {}
        if cur.get("enabled", False):
            mode = cur.get("mode", "off")
            if mode == "symbolic_only":
                family = "symbolic"
            elif mode == "oct_only":
                family = "oct"
            elif mode == "mixed_static":
                mixed_cfg = cur.get("mixed", {}) or {}
                sym_frac = float(mixed_cfg.get("symbolic_fraction", 0.5))
                oct_frac = float(mixed_cfg.get("oct_fraction", 0.5))
                total = sym_frac + oct_frac
                if total <= 0:
                    raise ValueError("Curriculum mixed fractions must sum to > 0")
                sym_prob = sym_frac / total
                if torch.rand(1).item() < sym_prob:
                    family = "symbolic"
                else:
                    family = "oct"
            elif mode == "off":
                pass
            else:
                raise ValueError(f"Unknown curriculum mode: {mode}")

        if family == "oct" and not hasattr(self.model, "oct_dim"):
            family = "symbolic"
        if family == "symbolic":
            x, y = self.symbolic_checker.build_batch(
                task_spec,
                effective_batch,
                self.device,
                hard_mode=use_harder_eval_slice,
                difficulty=effective_difficulty,
            )
            return x, y, {}
        if family == "oct":
            x, y, meta = build_oct_batch(
                batch_size=effective_batch, dim=getattr(self.model, "oct_dim", 128), difficulty=effective_difficulty, device=self.device
            )
            return x, y, meta
        if family == "lexical":
            if effective_difficulty == "anagram":
                return self._build_lexical_anagram_batch(batch_size=effective_batch)
            if effective_difficulty == "synonym":
                return self._build_lexical_synonym_batch(batch_size=effective_batch)
            if effective_difficulty == "antonym":
                return self._build_lexical_antonym_batch(batch_size=effective_batch)
            raise ValueError(f"Unknown lexical difficulty: {effective_difficulty}")
        if family == "lexical_real":
            if self.lexical_real_ds is None:
                raise ValueError("LexicalRealDataset not initialized (check path or task_family)")
            if effective_difficulty == "synonym":
                x, y = self.lexical_real_ds.build_synonym_batch(effective_batch, self.device)
                return x, y, {}
            elif effective_difficulty == "antonym" or effective_difficulty == "hard":
                # 'hard' fallback for debug scans or harder_eval_slice
                x, y = self.lexical_real_ds.build_antonym_batch(effective_batch, self.device)
                return x, y, {}
            else:
                 raise ValueError(f"Unknown lexical_real difficulty: {effective_difficulty}")

        # Phase 11: Logical reasoning tasks (implication, parity, sat)
        if family == "logical":
            if self.logical_ds is None:
                raise ValueError("LogicalDataset not initialized (check task_family)")
            if effective_difficulty == "implication":
                x, y = self.logical_ds.build_implication_batch(effective_batch, self.device)
                return x, y, {"task_type": "implication"}
            elif effective_difficulty == "parity":
                x, y = self.logical_ds.build_recursive_parity_batch(effective_batch, self.device)
                return x, y, {"task_type": "parity"}
            elif effective_difficulty == "parity_cot":
                x, y = self.logical_ds.build_parity_batch_with_trace(effective_batch, self.device)
                return x, y, {"task_type": "parity_cot"}
            elif effective_difficulty == "sat":
                x, y = self.logical_ds.build_sat_batch(effective_batch, self.device)
                return x, y, {"task_type": "sat"}
            elif effective_difficulty in ("hard", "medium"):
                # Fallback for debug scans - use configured task type
                x, y = self.logical_ds.build_batch(effective_batch, self.device)
                return x, y, {"task_type": self.logical_ds.task_type}
            else:
                raise ValueError(f"Unknown logical difficulty: {effective_difficulty}. Use: implication, parity, parity_cot, sat")

        # Phase 13: FLD (Formal Logic Deduction) - natural language logic
        if family == "fld":
            if self.fld_ds is None:
                raise ValueError("FLDDataset not initialized (check task_family)")
            # Valid FLD task types: modus_ponens, modus_tollens, syllogism, contraposition, mixed, fld
            fld_valid_types = ("modus_ponens", "modus_tollens", "syllogism", "contraposition", "mixed", "fld")
            if effective_difficulty in fld_valid_types:
                fld_task = effective_difficulty
            elif effective_difficulty in ("hard", "medium"):
                # Fallback for debug scans - use configured task type
                fld_task = self.fld_ds.task_type
            else:
                raise ValueError(f"Unknown FLD difficulty: {effective_difficulty}. Use: {fld_valid_types}")
            x, y = self.fld_ds.build_batch(effective_batch, self.device, task_type=fld_task)
            return x, y, {"task_type": f"fld_{fld_task}"}

        # Phase 13/14: Math CoT (OpenMathInstruct-2 / GSM8K)
        if family == "math_cot":
            if self.math_cot_ds is None:
                raise ValueError("MathCoTDataset not initialized (check task_family)")
            # Valid Math CoT task types (legacy parity + Phase 14 verification)
            math_valid_types = (
                "openmath", "arithmetic", "arithmetic_easy", "arithmetic_hard", "word_problem", "mixed",
                "verify", "verify_arithmetic", "verify_arithmetic_easy", "verify_arithmetic_hard",
                "verify_word_problem", "verify_mixed"
            )
            if effective_difficulty in math_valid_types:
                math_task = effective_difficulty
            elif effective_difficulty in ("hard", "medium"):
                # Fallback for debug scans - use configured task type
                math_task = self.math_cot_ds.task_type
            else:
                raise ValueError(f"Unknown MathCoT difficulty: {effective_difficulty}. Use: {math_valid_types}")
            x, y = self.math_cot_ds.build_batch(effective_batch, self.device, task_type=math_task)
            return x, y, {"task_type": f"math_cot_{math_task}"}

        raise NotImplementedError(f"task_family '{family}' not implemented yet")

    def _build_batch_from_task(
        self, task_spec: Dict[str, object], hard_mode: bool = False, difficulty: str | None = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        effective_difficulty = difficulty or (self.difficulty if not hard_mode else "hard")
        x, y, _ = self._build_task_batch(
            task_spec,
            task_family=self.task_family,
            difficulty=effective_difficulty,
            use_harder_eval_slice=hard_mode,
            batch_size=self.batch_size,
        )
        return x, y

    def _build_lexical_anagram_batch(self, batch_size: int) -> Tuple[torch.Tensor, torch.Tensor, Dict[str, float]]:
        cfg_model = self.cfg.get("model", {}) or {}
        lexical_cfg = (self.cfg.get("training", {}).get("lexical", {}) or {}).get("anagram", {}) or {}
        seq_len = int(cfg_model.get("seq_len", 32))
        vocab_size = int(cfg_model.get("vocab_size", 32))
        if vocab_size < 8:
            raise ValueError("lexical.anagram requires vocab_size >= 8")
        pad_idx, bos_idx, sep_idx, eos_idx = 0, 1, 2, 3
        alpha_start = 4
        alpha_end = vocab_size
        default_max_content = max(2, min(seq_len - 4, 6))
        min_override = lexical_cfg.get("min_length", None)
        max_override = lexical_cfg.get("max_length", None)
        min_content = default_max_content if min_override is None else int(min_override)
        max_content = default_max_content if max_override is None else int(max_override)
        effective_max = max(2, min(seq_len - 4, max_content))
        effective_min = max(2, min(effective_max, min_content))
        default_corruption_rate = 1.0 / float(default_max_content) if default_max_content > 0 else 0.2
        corruption_override = lexical_cfg.get("corruption_rate", None)
        corruption_rate = float(default_corruption_rate if corruption_override is None else corruption_override)
        near_anagram_prob = float(lexical_cfg.get("near_anagram_prob", 0.0))
        x = torch.full((batch_size, seq_len), pad_idx, dtype=torch.long, device=self.device)
        labels = torch.zeros(batch_size, dtype=torch.long, device=self.device)
        for i in range(batch_size):
            content_len = int(torch.randint(effective_min, effective_max + 1, (1,), device=self.device).item())
            x1 = torch.randint(alpha_start, alpha_end, (content_len,), device=self.device)
            is_positive = torch.rand(1).item() < 0.5
            if is_positive:
                perm = torch.randperm(content_len, device=self.device)
                x2 = x1[perm]
                labels[i] = 1
            else:
                x2 = x1.clone()
                corruption_count = max(1, math.ceil(content_len * corruption_rate))
                if torch.rand(1).item() < near_anagram_prob:
                    corruption_count = 1
                corruption_count = min(content_len, corruption_count)
                idxs = torch.randperm(content_len, device=self.device)[:corruption_count]
                for idx in idxs:
                    replacement = torch.randint(alpha_start, alpha_end, (1,), device=self.device).item()
                    if replacement == x2[idx]:
                        replacement = alpha_start if replacement + 1 >= alpha_end else replacement + 1
                    x2[idx] = replacement
                labels[i] = 0
            tokens = torch.cat(
                [torch.tensor([bos_idx], device=self.device), x1, torch.tensor([sep_idx], device=self.device), x2, torch.tensor([eos_idx], device=self.device)]
            )
            tokens = tokens[:seq_len]
            x[i, : tokens.shape[0]] = tokens
        return x, labels, {}

    def _build_lexical_antonym_batch(self, batch_size: int) -> Tuple[torch.Tensor, torch.Tensor, Dict[str, float]]:
        cfg_model = self.cfg.get("model", {}) or {}
        lexical_cfg = (self.cfg.get("training", {}).get("lexical", {}) or {}).get("antonym", {}) or {}
        seq_len = int(cfg_model.get("seq_len", 32))
        vocab_size = int(cfg_model.get("vocab_size", 32))
        num_pairs_override = lexical_cfg.get("num_pairs", None)
        num_pairs = int(5 if num_pairs_override is None else num_pairs_override)
        if vocab_size < 10:
            raise ValueError("lexical.antonym requires vocab_size >= 10")
        base = 4
        if base + 2 * num_pairs > vocab_size:
            raise ValueError("lexical.antonym vocab_size too small for requested num_pairs")
        pad_idx, bos_idx, sep_idx, eos_idx = 0, 1, 2, 3
        antonym_pairs = [(base + 2 * i, base + 2 * i + 1) for i in range(num_pairs)]
        flat_tokens = {t for pair in antonym_pairs for t in pair}
        tokens_list = list(flat_tokens)
        extra_tokens = list(range(base + 2 * num_pairs, vocab_size))
        distractor_ratio = float(lexical_cfg.get("distractor_ratio", 0.0))
        x = torch.full((batch_size, seq_len), pad_idx, dtype=torch.long, device=self.device)
        labels = torch.zeros(batch_size, dtype=torch.long, device=self.device)

        def is_antonym(w1: int, w2: int) -> bool:
            return (w1, w2) in antonym_pairs or (w2, w1) in antonym_pairs

        for i in range(batch_size):
            pos = torch.rand(1).item() < 0.5
            if pos:
                pair = antonym_pairs[torch.randint(0, len(antonym_pairs), (1,), device=self.device).item()]
                w1, w2 = pair
                labels[i] = 1
            else:
                use_distractor = extra_tokens and (torch.rand(1).item() < distractor_ratio)
                w1 = int(torch.tensor(tokens_list, device=self.device)[torch.randint(0, len(tokens_list), (1,), device=self.device)].item())
                if use_distractor:
                    w2 = int(torch.tensor(extra_tokens, device=self.device)[torch.randint(0, len(extra_tokens), (1,), device=self.device)].item())
                    labels[i] = 0
                else:
                    w2 = int(torch.tensor(tokens_list, device=self.device)[torch.randint(0, len(tokens_list), (1,), device=self.device)].item())
                    tries = 0
                    while is_antonym(w1, w2) and tries < 5:
                        w2 = int(torch.tensor(tokens_list, device=self.device)[torch.randint(0, len(tokens_list), (1,), device=self.device)].item())
                        tries += 1
                    labels[i] = 1 if is_antonym(w1, w2) else 0
            tokens = torch.tensor([bos_idx, w1, sep_idx, w2, eos_idx], device=self.device)
            tokens = tokens[:seq_len]
            x[i, : tokens.shape[0]] = tokens
        # guarantee both classes
        if (labels == 1).sum() == 0:
            idx = 0
            pair = antonym_pairs[0]
            x[idx, :5] = torch.tensor([bos_idx, pair[0], sep_idx, pair[1], eos_idx], device=self.device)
            labels[idx] = 1
        if (labels == 0).sum() == 0:
            idx = batch_size - 1
            w1 = tokens_list[0]
            w2 = tokens_list[-1] if len(tokens_list) > 1 else tokens_list[0]
            x[idx, :5] = torch.tensor([bos_idx, w1, sep_idx, w2, eos_idx], device=self.device)
            labels[idx] = 0
        return x, labels, {}

    def _build_lexical_synonym_batch(self, batch_size: int) -> Tuple[torch.Tensor, torch.Tensor, Dict[str, float]]:
        cfg_model = self.cfg.get("model", {}) or {}
        lexical_cfg = (self.cfg.get("training", {}).get("lexical", {}) or {}).get("synonym", {}) or {}
        seq_len = int(cfg_model.get("seq_len", 32))
        vocab_size = int(cfg_model.get("vocab_size", 32))
        if vocab_size < 8:
            raise ValueError("lexical.synonym requires vocab_size >= 8")
        pad_idx, bos_idx, sep_idx, eos_idx = 0, 1, 2, 3
        alpha_start = 4
        alpha_end = vocab_size
        tokens = list(range(alpha_start, alpha_end))
        if not tokens:
            raise ValueError("lexical.synonym requires at least one token beyond specials")
        default_num_groups = max(2, (alpha_end - alpha_start) // 4 or 2)
        num_groups_override = lexical_cfg.get("num_groups", None)
        num_groups = int(default_num_groups if num_groups_override is None else num_groups_override)
        group_size_min_override = lexical_cfg.get("group_size_min", None)
        group_size_min = int(2 if group_size_min_override is None else group_size_min_override)
        group_size_max_override = lexical_cfg.get("group_size_max", None)
        group_size_max = int(len(tokens) if group_size_max_override is None else group_size_max_override)
        near_negative_prob = float(lexical_cfg.get("near_negative_prob", 0.0))
        if group_size_min > group_size_max:
            raise ValueError("lexical.synonym group_size_min cannot exceed group_size_max")
        if num_groups < 1:
            raise ValueError("lexical.synonym requires num_groups >= 1")
        if group_size_min * num_groups > len(tokens):
            raise ValueError("lexical.synonym config requests more tokens than available for groups")
        groups: List[List[int]] = [[] for _ in range(num_groups)]
        for idx, tok in enumerate(tokens):
            groups[idx % num_groups].append(tok)
        if any(len(g) < group_size_min or len(g) > group_size_max for g in groups):
            raise ValueError("lexical.synonym group sizes violate configured min/max")

        def group_id(token: int) -> int:
            for gi, group_tokens in enumerate(groups):
                if token in group_tokens:
                    return gi
            return 0

        x = torch.full((batch_size, seq_len), pad_idx, dtype=torch.long, device=self.device)
        labels = torch.zeros(batch_size, dtype=torch.long, device=self.device)
        for i in range(batch_size):
            pos = torch.rand(1).item() < 0.5
            g1 = torch.randint(0, num_groups, (1,), device=self.device).item()
            w1 = int(torch.tensor(groups[g1], device=self.device)[torch.randint(0, len(groups[g1]), (1,), device=self.device)].item())
            if pos or num_groups == 1:
                w2 = int(torch.tensor(groups[g1], device=self.device)[torch.randint(0, len(groups[g1]), (1,), device=self.device)].item())
                labels[i] = 1
            else:
                if torch.rand(1).item() < near_negative_prob:
                    g2 = (g1 + 1) % num_groups
                else:
                    other_groups = [g for g in range(num_groups) if g != g1]
                    g2 = int(torch.tensor(other_groups, device=self.device)[torch.randint(0, len(other_groups), (1,), device=self.device)].item())
                w2 = int(torch.tensor(groups[g2], device=self.device)[torch.randint(0, len(groups[g2]), (1,), device=self.device)].item())
                labels[i] = 0
            tokens_seq = torch.tensor([bos_idx, w1, sep_idx, w2, eos_idx], device=self.device)
            tokens_seq = tokens_seq[:seq_len]
            x[i, : tokens_seq.shape[0]] = tokens_seq
        meta = {"lexical_groups": groups}
        return x, labels, meta
    def _train_step(self, x_batch: torch.Tensor, y_batch: torch.Tensor) -> float:
        self.model.train()
        logits = self._forward_model(x_batch)
        loss = F.cross_entropy(logits, y_batch)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return float(loss.detach().item())

    def _train_step_oct(self, x_batch: torch.Tensor, y_batch: torch.Tensor) -> Tuple[float, float, float]:
        self.model.train()
        preds = self._forward_model(x_batch)
        cos = F.cosine_similarity(preds, y_batch, dim=-1)
        lambda_mag = float(self.reward_cfg.get("geo_lambda_mag", 0.0))
        pred_norm = preds.norm(dim=-1)
        in_norm = x_batch.norm(dim=-1)
        drift = (pred_norm - in_norm).abs()
        loss = (1 - cos).mean() + lambda_mag * drift.mean()
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return float(loss.detach().item()), float(cos.mean().detach().item()), float(drift.mean().detach().item())

    def _eval_metrics(self, x_batch: torch.Tensor, y_batch: torch.Tensor) -> Tuple[float, float]:
        self.model.eval()
        with torch.no_grad():
            logits = self._forward_model(x_batch)
            loss = F.cross_entropy(logits, y_batch)
            preds = logits.argmax(dim=-1)
            acc = (preds == y_batch).float().mean().item()
        return float(loss.item()), float(acc)

    def _eval_metrics_oct(self, x_batch: torch.Tensor, y_batch: torch.Tensor) -> Dict[str, torch.Tensor]:
        self.model.eval()
        with torch.no_grad():
            preds = self._forward_model(x_batch)
            cos = F.cosine_similarity(preds, y_batch, dim=-1)
            return {
                "pred": preds,
                "target": y_batch,
                "input": x_batch,
                "cos": cos,
            }

    def _forward_model(self, x_batch: torch.Tensor) -> torch.Tensor:
        output = self.model(x_batch)
        if isinstance(output, tuple):
            return output[0]
        return output

    def _debug_first_lowbit_stats(self, tag: str, cfg: Dict[str, float]) -> None:
        with torch.no_grad():
            for module in self.model.modules():
                if isinstance(module, LowBitLinear):
                    w_eff = module.get_effective_weight()
                    nonzero = (w_eff != 0).sum().item()
                    total = w_eff.numel()
                    norm = w_eff.norm().item()
                    print(
                        f"[DEBUG_WEIGHTS] {tag} "
                        f"tau={cfg['tau']:.2f} delta={cfg['delta']:.3f} k_act={cfg['k_act']:.2f} "
                        f"norm={norm:.6f} nonzero={nonzero}/{total}"
                    )
                    break

    def _gather_model_stats(self) -> Tuple[float, float, float]:
        total_params = 0
        total_nonzeros = 0
        conn_values: List[float] = []
        prec_values: List[float] = []
        rot_active: List[float] = []
        activation_scale = 1.0
        if "kact_values" in self.grids and self.grids["kact_values"]:
            max_k = max(self.grids["kact_values"])
            if max_k > 0:
                activation_scale = float(self.current_config_values.get("k_act", max_k)) / float(max_k)
        with torch.no_grad():
            for module in self.model.modules():
                if isinstance(module, LowBitLinear):
                    stats = module.get_sparsity_stats()
                    conn_values.append(stats.get("connectivity_sparsity", 0.0))
                    prec_values.append(stats.get("precision_sparsity", 0.0))
                    w_eff = module.get_effective_weight()
                    total_params += w_eff.numel()
                    total_nonzeros += (w_eff != 0).sum().item()
                if hasattr(module, "active_fraction"):
                    rot_active.append(module.active_fraction())
        density = float(total_nonzeros) / float(total_params) if total_params > 0 else 0.0
        flops_ratio = density * activation_scale
        conn_sparsity = float(np.mean(conn_values)) if conn_values else 0.0
        prec_sparsity = float(np.mean(prec_values)) if prec_values else 0.0
        if rot_active:
            rot_density = float(np.mean(rot_active))
            flops_ratio = rot_density * activation_scale if flops_ratio == 0 else max(flops_ratio, rot_density * activation_scale)
            conn_sparsity = 1.0 - rot_density if not conn_values else conn_sparsity
        return flops_ratio, conn_sparsity, prec_sparsity

    def _eval_accuracy_for_action(
        self, x_batch: torch.Tensor, y_batch: torch.Tensor, action: ConfigAction, tag: str | None = None
    ) -> Tuple[float, float, float, float]:
        if self.task_family == "oct":
            raise NotImplementedError("eval_accuracy_for_action is not used for oct task_family")
        cfg = decode_action(action, self.grids)
        apply_config_to_model(self.model, cfg)
        prev_cfg = dict(self.current_config_values)
        self.current_config_values = dict(cfg)
        if tag is not None and (
            self.debug_weights_every > 0
            and (tag == "scan" or (self.global_step % self.debug_weights_every == 0))
        ):
            self._debug_first_lowbit_stats(tag, cfg)
        self.model.eval()
        with torch.no_grad():
            logits = self._forward_model(x_batch)
            preds = logits.argmax(dim=-1)
            acc = (preds == y_batch).float().mean().item()
        flops_ratio, conn_sparsity, prec_sparsity = self._gather_model_stats()
        self.current_config_values = prev_cfg
        return float(acc), flops_ratio, conn_sparsity, prec_sparsity

    def _collect_preds_for_action(self, batches: List[Tuple[torch.Tensor, torch.Tensor]], action: ConfigAction) -> torch.Tensor:
        cfg = decode_action(action, self.grids)
        apply_config_to_model(self.model, cfg)
        self.model.eval()
        preds_all: List[torch.Tensor] = []
        with torch.no_grad():
            for x_batch, _ in batches:
                x_batch = x_batch.to(self.device)
                logits = self._forward_model(x_batch)
                if self.task_family == "oct":
                    preds_all.append(logits.cpu().reshape(logits.shape[0], -1))
                else:
                    preds = logits.argmax(dim=-1)
                    preds_all.append(preds.cpu())
        if preds_all:
            return torch.cat(preds_all, dim=0)
        dtype = torch.float if self.task_family == "oct" else torch.long
        return torch.empty(0, dtype=dtype)

    def _compute_reward(
        self,
        acc: float,
        flops_ratio: float,
        conn_sparsity: float,
        prec_sparsity: float,
        lambdas: Dict[str, float],
    ) -> float:
        conn_density = 1.0 - conn_sparsity
        prec_density = 1.0 - prec_sparsity
        conn_target = 0.10
        prec_target = 0.10
        penalty_conn = max(0.0, conn_density - conn_target)
        penalty_prec = max(0.0, prec_density - prec_target)
        reward = (
            acc
            - lambdas.get("lambda_conn", 0.0) * penalty_conn
            - lambdas.get("lambda_act", 0.0) * penalty_prec
            - lambdas.get("lambda_prec", 0.0) * flops_ratio
        )
        if acc < 0.1:
            reward -= 1.0
        return float(reward)

    def _build_state(
        self,
        acc_prev: float,
        loss_prev: float,
        ref_acc: float,
        flops_ratio: float,
        conn_sparsity: float,
        prec_sparsity: float,
        tau_prev: float,
        k_act_prev: float,
    ) -> torch.Tensor:
        values = [
            float(acc_prev),
            float(loss_prev),
            float(ref_acc),
            float(flops_ratio),
            float(conn_sparsity),
            float(prec_sparsity),
            float(tau_prev),
            float(k_act_prev),
        ]
        return torch.tensor(values, dtype=torch.float32, device=self.device)

    def decode_config(self, action: ConfigAction) -> Dict[str, float]:
        return decode_action(action, self.grids)

    def debug_scan_action_grid(self) -> None:
        self.debug_scan_action_grid_with_data(return_data=False)

    def debug_scan_action_grid_with_data(self, return_data: bool = False):
        if self.task_family == "oct":
            print("[DEBUG] action scan skipped for oct task_family")
            return [] if return_data else None
        scan_difficulty = "hard" if self.use_harder_eval_slice else self.difficulty
        variants = self.egm_handler.fetch_variants(self.recent_performance, difficulty=scan_difficulty)
        tasks = variants.get("variant_tasks", [])
        if not tasks:
            print("[DEBUG] action scan skipped (no variants)")
            return [] if return_data else None
        task_spec = tasks[0]
        x_batch, y_batch, _ = self._build_task_batch(
            task_spec,
            task_family=self.task_family,
            difficulty=self.difficulty,
            use_harder_eval_slice=self.use_harder_eval_slice,
            batch_size=self.batch_size,
        )
        current_cfg = dict(self.current_config_values)
        print("[DEBUG] action scan start")
        results = []
        for tau_idx in range(len(self.grids["tau_values"])):
            for delta_idx in range(len(self.grids["delta_values"])):
                for kact_idx in range(len(self.grids["kact_values"])):
                    for mode_idx in range(len(self.grids["mode_values"])):
                        action = ConfigAction(tau_idx, delta_idx, kact_idx, mode_idx)
                        acc, flops_ratio, conn_sparsity, prec_sparsity = self._eval_accuracy_for_action(
                            x_batch, y_batch, action, tag="scan"
                        )
                        cfg_vals = decode_action(action, self.grids)
                        print(
                            "[SCAN] "
                            f"tau={cfg_vals['tau']:.2f} delta={cfg_vals['delta']:.3f} "
                            f"k_act={cfg_vals['k_act']:.2f} mode={cfg_vals['mode']} "
                            f"acc={acc:.4f} flops={flops_ratio:.3f} "
                            f"conn={conn_sparsity:.3f} prec={prec_sparsity:.3f}"
                        )
                        if return_data:
                            results.append(
                                {
                                    "tau": cfg_vals["tau"],
                                    "delta": cfg_vals["delta"],
                                    "k_act": cfg_vals["k_act"],
                                    "mode": cfg_vals["mode"],
                                    "acc": acc,
                                    "flops": flops_ratio,
                                    "conn": conn_sparsity,
                                    "prec": prec_sparsity,
                                }
                            )
        apply_config_to_model(self.model, current_cfg)
        if return_data:
            return results

    def debug_prediction_delta(self) -> None:
        pd_cfg = self.cfg.get("prediction_delta", {})
        training_cfg = self.cfg.get("training", {})
        enabled = bool(pd_cfg.get("enabled", training_cfg.get("debug_prediction_delta", False)))
        if not enabled:
            print("[DEBUG] prediction delta skipped (disabled)")
            return
        use_harder = bool(pd_cfg.get("use_harder_eval_slice", False))
        difficulty = "hard" if use_harder else "medium"
        variants = self.egm_handler.fetch_variants(self.recent_performance, difficulty=difficulty)
        tasks = variants.get("variant_tasks", [])
        if not tasks:
            print("[DEBUG] prediction delta skipped (no variants)")
            return
        task_spec = tasks[0]
        num_batches = int(pd_cfg.get("batches", training_cfg.get("prediction_delta_batches", 4)))
        batches = self._get_prediction_delta_batches(use_harder, num_batches, task_spec, difficulty=difficulty)
        # Choose ref/extreme actions from config when provided; otherwise fall back to current defaults.
        ref_action = self.ref_action
        extreme_action = ConfigAction(
            tau_idx=max(len(self.grids["tau_values"]) - 1, 0),
            delta_idx=0,
            kact_idx=max(len(self.grids["kact_values"]) - 1, 0),
            mode_idx=0,
        )

        def _action_from_values(values: Dict[str, float]) -> ConfigAction:
            def _idx(val: float, arr: list[float], name: str) -> int:
                if val not in arr:
                    raise ValueError(f"prediction_delta.{name}={val} not in grid {arr}")
                return arr.index(val)

            return ConfigAction(
                tau_idx=_idx(float(values["tau"]), self.grids["tau_values"], "tau"),
                delta_idx=_idx(float(values["delta"]), self.grids["delta_values"], "delta"),
                kact_idx=_idx(float(values["k_act"]), self.grids["kact_values"], "k_act"),
                mode_idx=_idx(values["mode"], self.grids["mode_values"], "mode"),
            )

        if pd_cfg.get("ref_action"):
            ref_action = _action_from_values(pd_cfg["ref_action"])
        if pd_cfg.get("extreme_action"):
            extreme_action = _action_from_values(pd_cfg["extreme_action"])

        current_cfg = dict(self.current_config_values)
        preds_ref = self._collect_preds_for_action(batches, ref_action)
        preds_extreme = self._collect_preds_for_action(batches, extreme_action)
        if self.task_family == "oct":
            pd_cfg = self.cfg.get("prediction_delta", {})
            eps_cos = float(pd_cfg.get("oct_eps_cos", 1e-3))
            eps_norm = float(pd_cfg.get("oct_eps_norm", 1e-2))
            preds_ref = preds_ref.view(preds_ref.shape[0], -1)
            preds_extreme = preds_extreme.view(preds_extreme.shape[0], -1)
            cos = F.cosine_similarity(preds_ref, preds_extreme, dim=-1)
            diff_norm = (preds_ref - preds_extreme).norm(dim=-1)
            changed_mask = (cos < (1.0 - eps_cos)) | (diff_norm > eps_norm)
            changed = int(changed_mask.sum().item())
            total = preds_ref.shape[0]
            if total > 0:
                print(
                    f"[DELTA_DIAG] cos_mean={cos.mean():.4f} cos_min={cos.min():.4f} "
                    f"diff_norm_mean={diff_norm.mean():.4f} diff_norm_max={diff_norm.max():.4f}"
                )
        else:
            changed = int((preds_ref != preds_extreme).sum().item())
            total = preds_ref.numel()
        cfg_ext = decode_action(extreme_action, self.grids)
        print(
            "[DELTA] "
            f"extreme tau={cfg_ext['tau']:.2f} delta={cfg_ext['delta']:.3f} "
            f"k_act={cfg_ext['k_act']:.2f} mode={cfg_ext['mode']} "
            f"changed={changed}/{total}"
        )
        self.last_delta_ratio = (changed / total) if total > 0 else 0.0
        apply_config_to_model(self.model, current_cfg)

    def _update_recent_performance(self, task_id: str, acc: float, config_values: Dict[str, float]) -> None:
        entry = {
            "task_id": task_id,
            "accuracy": float(acc),
            "config_tau": float(config_values.get("tau", 0.0)),
            "config_delta": float(config_values.get("delta", 0.0)),
            "config_k_act": float(config_values.get("k_act", 0.0)),
        }
        self.recent_performance.append(entry)
        max_history = 32
        if len(self.recent_performance) > max_history:
            self.recent_performance = self.recent_performance[-max_history:]

    def _get_prediction_delta_batches(
        self, use_harder: bool, num_batches: int, task_spec: Dict[str, object], difficulty: str = "medium"
    ):
        batches: List[Tuple[torch.Tensor, torch.Tensor]] = []
        # Use harder pool if available.
        pool_used = False
        if use_harder and self.hard_pool:
            pool_used = True
            while self.hard_pool and len(batches) < num_batches:
                batches.append(self.hard_pool.popleft())
        # Fill the remainder from the standard source.
        while len(batches) < num_batches:
            try:
                batches.append(
                    self._build_batch_from_task(
                        task_spec,
                        hard_mode=use_harder,
                        difficulty=self.difficulty if not use_harder else "hard",
                    )
                )
            except TypeError:
                # Backward-compat for tests that monkeypatch a simpler signature.
                batches.append(self._build_batch_from_task(task_spec, hard_mode=use_harder))
        if use_harder and pool_used and self.task_family != "oct":
            # Replenish pool with fresh harder candidates from these batches if any are misclassified vs ref.
            for x_batch, y_batch in batches:
                acc_ref, _, _, _ = self._eval_accuracy_for_action(
                    x_batch.to(self.device), y_batch.to(self.device), self.ref_action
                )
                if acc_ref < 1.0:
                    self.hard_pool.append((x_batch.detach().cpu(), y_batch.detach().cpu()))
        return batches

    def collect_layer_stats(self) -> list[dict]:
        """
        Gather per-layer sparsity/precision/FLOPs proxy statistics.
        """
        stats: list[dict] = []
        layer_idx = 0
        with torch.no_grad():
            for module in self.model.modules():
                if isinstance(module, LowBitLinear):
                    module_stats = module.get_sparsity_stats()
                    conn_sparsity = module_stats.get("connectivity_sparsity", 0.0)
                    prec_sparsity = module_stats.get("precision_sparsity", 0.0)
                    conn_density = 1.0 - conn_sparsity
                    prec_density = 1.0 - prec_sparsity
                    stats.append(
                        {
                            "layer_index": layer_idx,
                            "class": module.__class__.__name__,
                            "connectivity_sparsity": conn_sparsity,
                            "precision_sparsity": prec_sparsity,
                            "connectivity_density": conn_density,
                            "precision_density": prec_density,
                            "flops_proxy": conn_density * prec_density,
                        }
                    )
                    layer_idx += 1
        return stats

    def write_interpretability_snapshot(self, log_dir: str | None = None, preset_name: str | None = None) -> None:
        stats = self.collect_layer_stats()
        if not stats:
            return
        out_dir = ensure_dir(log_dir or "logs/interpretability")
        ts = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
        name = preset_name or self.cfg.get("preset", "unknown")
        path = out_dir / f"interpretability_{name}_{ts}.json"
        with path.open("w", encoding="utf-8") as fh:
            json.dump(stats, fh, indent=2)
        print(f"[INTERP] wrote per-layer stats to {path}")

    def eval_fld_trace_utilization(self, step: int, batch_size: int = 256) -> None:
        """
        Diagnostic: compare accuracy with vs without trace text, and break down
        accuracy by sequence length bucket. Prints [TRACE_UTIL] lines only.
        Does not affect model weights, reward, or policy.
        """
        if self.fld_ds is None:
            return
        n = min(batch_size, self.batch_size)
        pad = self.fld_ds.pad_idx

        # --- WITH trace ---
        x_t, y_t = self.fld_ds.build_batch(n, self.device, task_type="mixed")
        self.model.eval()
        with torch.no_grad():
            logits_t = self._forward_model(x_t)
            preds_t = logits_t.argmax(dim=-1)
            acc_with = (preds_t == y_t).float().mean().item()

        # --- WITHOUT trace (toggle, restore in finally) ---
        # Capture the original state so eval doesn't accidentally re-enable
        # trace when training config was include_trace=False (transfer experiments).
        original_include_trace = self.fld_ds.include_trace
        self.fld_ds.include_trace = False
        try:
            x_nt, y_nt = self.fld_ds.build_batch(n, self.device, task_type="mixed")
            with torch.no_grad():
                logits_nt = self._forward_model(x_nt)
                acc_without = (logits_nt.argmax(dim=-1) == y_nt).float().mean().item()
        finally:
            self.fld_ds.include_trace = original_include_trace

        delta = acc_with - acc_without
        print(
            f"[TRACE_UTIL] step={step} "
            f"acc_with_trace={acc_with:.4f} acc_without_trace={acc_without:.4f} "
            f"delta={delta:+.4f}"
        )

        # --- per-length-bucket breakdown on with-trace batch ---
        seq_lens = (x_t != pad).sum(dim=1)
        buckets = [(0, 64), (64, 128), (128, 192), (192, 257)]
        bucket_parts = []
        for lo, hi in buckets:
            mask = (seq_lens > lo) & (seq_lens <= hi)
            n_bucket = int(mask.sum().item())
            if n_bucket == 0:
                continue
            b_acc = (preds_t[mask] == y_t[mask]).float().mean().item()
            bucket_parts.append(f"len={lo}-{hi}:n={n_bucket}:acc={b_acc:.3f}")
        if bucket_parts:
            print(f"[TRACE_DEPTH] step={step} " + "  ".join(bucket_parts))

    def eval_math_cot_trace_utilization(self, step: int, batch_size: int = 128) -> None:
        """
        Diagnostic: compare accuracy with vs without CoT trace on verify tasks,
        and break down by sequence length bucket. Prints [TRACE_UTIL] lines only.
        Does not affect model weights, reward, or policy.
        """
        if self.math_cot_ds is None:
            return
        n = min(batch_size, self.batch_size)
        pad = self.math_cot_ds.pad_idx

        # --- WITH trace ---
        x_t, y_t = self.math_cot_ds.build_batch(n, self.device, task_type="verify_mixed")
        self.model.eval()
        with torch.no_grad():
            logits_t = self._forward_model(x_t)
            preds_t = logits_t.argmax(dim=-1)
            acc_with = (preds_t == y_t).float().mean().item()

        # --- WITHOUT trace (toggle, restore in finally) ---
        # Capture the original state so eval doesn't accidentally re-enable
        # trace when training config was include_trace=False.
        original_include_trace = self.math_cot_ds.include_trace
        self.math_cot_ds.include_trace = False
        try:
            x_nt, y_nt = self.math_cot_ds.build_batch(n, self.device, task_type="verify_mixed")
            with torch.no_grad():
                logits_nt = self._forward_model(x_nt)
                acc_without = (logits_nt.argmax(dim=-1) == y_nt).float().mean().item()
        finally:
            self.math_cot_ds.include_trace = original_include_trace

        delta = acc_with - acc_without
        print(
            f"[TRACE_UTIL] step={step} "
            f"acc_with_trace={acc_with:.4f} acc_without_trace={acc_without:.4f} "
            f"delta={delta:+.4f}"
        )

        # --- per-length-bucket breakdown on with-trace batch ---
        seq_lens = (x_t != pad).sum(dim=1)
        buckets = [(0, 128), (128, 256), (256, 384), (384, 513)]
        bucket_parts = []
        for lo, hi in buckets:
            mask = (seq_lens > lo) & (seq_lens <= hi)
            n_bucket = int(mask.sum().item())
            if n_bucket == 0:
                continue
            b_acc = (preds_t[mask] == y_t[mask]).float().mean().item()
            bucket_parts.append(f"len={lo}-{hi}:n={n_bucket}:acc={b_acc:.3f}")
        if bucket_parts:
            print(f"[TRACE_DEPTH] step={step} " + "  ".join(bucket_parts))

    def write_scan_snapshot(self, scan_data: list[dict], log_dir: str | None = None, preset_name: str | None = None) -> None:
        if not scan_data:
            return
        out_dir = ensure_dir(log_dir or "logs/interpretability")
        ts = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
        name = preset_name or self.cfg.get("preset", "unknown")
        path = out_dir / f"scan_{name}_{ts}.json"
        with path.open("w", encoding="utf-8") as fh:
            json.dump(scan_data, fh, indent=2)
        print(f"[INTERP] wrote action scan stats to {path}")

# File Manifest — WINASPARSE1BIT Public Repository

This manifest enumerates every file shipped with the v2-preprint-2026-06
release. It is intended for verification — a reader should be able to
reconcile this list against the on-disk tree.

Generated alongside the v2 preprint (June 2026).
See [CHANGELOG.md](CHANGELOG.md) for the v1 → v2 file delta.

---

## Top-level

| File | Purpose |
|---|---|
| `README.md` | Project overview, headline results, quick start |
| `LICENSE` | MIT |
| `CHANGELOG.md` | v1 → v2 release notes |
| `CITATION.cff` | GitHub / Zenodo citation widget metadata |
| `.zenodo.json` | Zenodo deposit metadata (title, authors, keywords, related identifiers) |
| `FILE_MANIFEST.md` | This file |
| `REPOSITORY_INFO.md` | Scope statement and Zenodo workflow notes |
| `requirements.txt` | Python dependencies |
| `.gitignore` | Git ignore rules (logs, checkpoints, generated data) |
| `main.py` | Classification training entry point (Phases 1–14) |
| `train_lm.py` | Causal LM training (Phase 15+), single-GPU + DDP |
| `eval_lm.py` | LM perplexity and mode-comparison evaluation |
| `generate.py` | LM sampling utility |
| `load_checkpoint.py` | Checkpoint loader (re-instantiates model from model_info.json) |
| `auto_phase.py` | Tier-A auto-hyperparameter sweep |
| `auto_phase_transfer.py` | Transfer-aware variant producing iter7_hifi |
| `cross_task_transfer.py` | Three-arm frozen-circuit ablation |
| `mech_interp.py` | Cross-seed circuit-overlap analysis |
| `utils.py` | Shared utilities (seeding, EGM handler) |

## `sparse_llm/` — architecture

| File | Purpose |
|---|---|
| `__init__.py` | Public API exports |
| `layers.py` | `LowBitLinear` — 1.58-bit ternary + STE + masks |
| `mlp.py` | `WINA_MLP` — Weight-Informed Neuron Activation |
| `transformer.py` | `SparseTransformer` (classification model) |
| `causal_transformer.py` | `CausalSparseTransformer` (LM, with RoPE) — **new in v2** |
| `hybrid.py` | `HybridStack` (Sparse-Dense-Sparse sandwich) — **new in v2** |
| `tiny_transformer.py` | Dense baseline transformer |
| `masks.py` | Boolean mask utilities |
| `oct_layers.py` | `RotationalLinear` for OCT geometry tasks |
| `data.py` | Symbolic/OCT batch builders |
| `utils.py` | Internal helpers |
| `logging_utils.py` | Per-step diagnostic emitters |

## `sparse_llm/datasets/` — dataset loaders (new in v2)

| File | Purpose |
|---|---|
| `__init__.py` | Module init |
| `lexical_real.py` | WordNet-derived lexical reasoning |
| `fld_loader.py` | Formal logic deduction (FLD) |
| `math_cot_loader.py` | Math chain-of-thought verification |
| `lm_dataset.py` | Causal LM loaders (TinyStories, OpenWebText; chunked and streaming) |
| `logical.py` | Logical/parity dataset |

## `rl/` — REINFORCE training framework

| File | Purpose |
|---|---|
| `__init__.py` | Module init |
| `env.py` | `ConfigEnv` — action grid, FLOPs proxy, state vector |
| `trainer.py` | REINFORCE update loop |
| `policy_net.py` | Policy network |
| `reward_fn.py` | Shaped reward with FLOPs / sparsity hinges |
| `config_space.py` | Action grid construction |
| `config_applier.py` | Apply τ, δ, k_act to model modules |
| `lambda_scheduler.py` | λ annealing schedule |
| `ladder.py` | LADDER-lite curriculum controller (opt-in) |
| `summary_logger.py` | Per-step / per-summary log emitters |

## `verifiers/` — task verifiers

| File | Purpose |
|---|---|
| `__init__.py` | Module init |
| `logical_checker.py` | Formal logic verifier |
| `symbolic_checker.py` | Symbolic-task deterministic checker |
| `oct_manifold.py` | OCT geometric verifier |

## `config/`

| File | Purpose |
|---|---|
| `global_params.yaml` | All presets — Phase 7 / 8 / 9a / 10 / 12 / 13 / 14B / 15A-C |
| `loader.py` | Config loader and preset merger |
| `presets/model_zero_relational_v1.yaml` | Phase 10 Track 3 relational data preset |

## `tools/` — dataset generation

| File | Purpose |
|---|---|
| `generate_lexical_deep.py` | WordNet → `lexical_real_deep_v1.jsonl` |
| `generate_lexical_json.py` | Alternative JSON formatter |
| `preprocess_atomic.py` | ATOMIC commonsense graph preprocessing |
| `preprocess_conceptnet.py` | ConceptNet preprocessing |
| `merge_datasets.py` | Cross-corpus merge utility |
| `download_atomic.sh` | ATOMIC fetch script |
| `download_conceptnet.sh` | ConceptNet fetch script |

## `tests/` — regression shields

| File | Purpose |
|---|---|
| `test_baseline_behavior.py` | v0.2 baseline shield (dense / wina-only / bitnet-only / stacked) |
| `test_causal_transformer.py` | `CausalSparseTransformer` shape and mode tests — **new in v2** |
| `test_hybrid_architecture.py` | HybridStack assembly and equivalence to Phase 8 |
| `test_parity_cot.py` | Parity-CoT dataset and trace construction |
| `test_phase13_datasets.py` | FLD generator label balance |
| `test_lexical_real.py` | WordNet lexical dataset sanity |
| `test_masks_and_flops.py` | Mask application and FLOPs proxy correctness |
| `test_reward_fn.py` | Reward shape and lambda annealing |
| `test_smoke_easy.py` | Smoke test on the easy preset |
| `test_symbolic_checker.py` | Symbolic task verifier |

## `data/`

| File | Purpose |
|---|---|
| `sample_data.jsonl` | 4-example format sample (full ~99K-example dataset generated via `tools/generate_lexical_deep.py`) |

## `docs/`

| File | Purpose |
|---|---|
| `WINASPARSE1BIT_arxiv_v2.tex` | v2 preprint LaTeX source (1970 lines) |
| `WINASPARSE1BIT_arxiv_v2.pdf` | v2 preprint PDF (37 pages, 656 KB) |
| `compile_preprint.sh` | Two-pass `pdflatex` compile script |
| `archive/WINASPARSE1BIT_paper_v1.tex` | v1 paper draft (Jan 2026, preserved) |

---

## What is intentionally NOT in this repository

For repository size, privacy, and reproducibility (results should be
generated, not shipped), the following are excluded:

- ❌ Training logs (`logs/`)
- ❌ Model checkpoints (`checkpoints/`, `*.pt`, `*.pth`, `*.ckpt`)
- ❌ Generated datasets larger than `sample_data.jsonl`
- ❌ Per-experiment notebooks and result CSVs
- ❌ Internal handoff and planning documents
- ❌ API keys, credentials, `.env` files
- ❌ Local development tooling configurations

## Verifying the manifest

```bash
# File counts (excluding __pycache__ and .git)
find . -type f -not -path '*/__pycache__/*' -not -path '*/.git/*' | wc -l

# Specifically the Python source
find sparse_llm rl verifiers tools tests -name '*.py' | wc -l
```

Expected at v2 release: 30+ Python source files, 10 test files, 7 docs/data
files, 12 top-level meta + script files.

All files contain no personal information beyond the author name (J B Swann)
and project identifier (Kingstun).

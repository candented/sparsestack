"""
Load and run inference with a trained Model Zero checkpoint.

Usage:
    python load_checkpoint.py --checkpoint checkpoints/model_zero_scaled_v2_dim512/seed42/final
"""

import argparse
import json
from pathlib import Path

import torch
import numpy as np

from sparse_llm.transformer import SparseTransformer
from sparse_llm.datasets.lexical_real import LexicalRealDataset


def load_model_from_checkpoint(checkpoint_dir: str, device: str = "cuda"):
    """Load a trained model from checkpoint directory."""
    
    checkpoint_dir = Path(checkpoint_dir)
    
    # Load model info
    model_info_path = checkpoint_dir / "model_info.json"
    with open(model_info_path, 'r') as f:
        model_info = json.load(f)
    
    # Create model with same architecture
    model = SparseTransformer(
        vocab_size=model_info['vocab_size'],
        dim=model_info['dim'],
        num_heads=model_info['num_heads'],
        mlp_hidden_dim=model_info['mlp_hidden_dim'],
        num_classes=model_info['num_classes'],
        seq_len=model_info['seq_len'],
        quant_threshold=model_info['quant_threshold'],
        gate_fc1=model_info['gate_fc1'],
        gate_fc2=model_info['gate_fc2'],
        gate_score_mode=model_info['gate_score_mode'],
        num_blocks=model_info['num_layers'],
    ).to(device)
    
    # Load checkpoint
    checkpoint_path = checkpoint_dir / "checkpoint.pt"
    checkpoint = torch.load(checkpoint_path, map_location=device)
    
    # Load model weights
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    
    print(f"[INFO] Loaded model from {checkpoint_dir}")
    print(f"[INFO] Training step: {checkpoint['step']}")
    print(f"[INFO] Preset: {checkpoint['preset_name']}")
    print(f"[INFO] Seed: {checkpoint['seed']}")
    print(f"[INFO] Model architecture: {model_info['arch']}")
    print(f"[INFO] Dimension: {model_info['dim']}")
    print(f"[INFO] Parameters: ~{sum(p.numel() for p in model.parameters()):,}")
    
    return model, model_info, checkpoint


def run_inference_example(model, model_info, dataset_path: str, device: str = "cuda", num_samples: int = 10):
    """Run inference on sample data."""
    
    # Load dataset
    dataset = LexicalRealDataset(
        data_path=dataset_path,
        vocab_size=model_info['vocab_size'],
        seq_len=model_info['seq_len']
    )
    
    print(f"\n[INFO] Running inference on {num_samples} samples...")
    print("=" * 80)
    
    correct = 0
    total = 0
    
    with torch.no_grad():
        for i in range(num_samples):
            # Get a batch of size 1
            x, y = dataset.build_synonym_batch(1, device)
            
            # Run inference
            logits = model(x)
            pred = torch.argmax(logits, dim=1)
            
            # Check accuracy
            is_correct = (pred == y).item()
            correct += is_correct
            total += 1
            
            # Print result
            status = "✓" if is_correct else "✗"
            print(f"Sample {i+1}: Pred={pred.item()}, True={y.item()} {status}")
    
    accuracy = correct / total
    print("=" * 80)
    print(f"\n[RESULTS] Accuracy: {accuracy:.2%} ({correct}/{total})")
    
    return accuracy


def main():
    parser = argparse.ArgumentParser(description="Load and run inference with Model Zero checkpoint")
    parser.add_argument("--checkpoint", type=str, required=True, help="Path to checkpoint directory")
    parser.add_argument("--dataset", type=str, default="data/lexical_real_deep_v1.jsonl", help="Path to dataset")
    parser.add_argument("--device", type=str, default="cuda", help="Device to use (cuda/cpu)")
    parser.add_argument("--num_samples", type=int, default=10, help="Number of samples to test")
    
    args = parser.parse_args()
    
    # Load model
    model, model_info, checkpoint = load_model_from_checkpoint(args.checkpoint, args.device)
    
    # Run inference
    accuracy = run_inference_example(model, model_info, args.dataset, args.device, args.num_samples)
    
    print(f"\n[INFO] Inference complete!")


if __name__ == "__main__":
    main()

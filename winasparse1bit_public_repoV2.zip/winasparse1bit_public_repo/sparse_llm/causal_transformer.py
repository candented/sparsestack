"""
Phase 15: Causal Sparse Transformer for Autoregressive Language Modeling.

Reuses WINA_MLP (sparse gated feed-forward) and LowBitLinear (ternary quantization)
from the existing SparseStack architecture. Adds causal attention masking, RoPE
positional embeddings, and per-position LM output head.

The sparsity mechanisms are identical to SparseTransformer — same mode/threshold/gate
interface — but the model outputs (batch, seq_len, vocab_size) instead of
(batch, num_classes).
"""

from __future__ import annotations

import math
from typing import Dict, List, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from .mlp import WINA_MLP


# =============================================================================
# Rotary Position Embeddings (RoPE)
# =============================================================================

class RotaryPositionEmbedding(nn.Module):
    """
    Rotary Position Embedding (Su et al., 2021).

    Encodes position information by rotating query/key vectors in 2D subspaces.
    Unlike learned positional embeddings, RoPE:
    - Extrapolates to longer sequences than seen during training
    - Encodes relative position naturally via dot-product properties
    - Adds zero parameters to the model
    """

    def __init__(self, dim: int, max_seq_len: int = 2048, base: float = 10000.0):
        super().__init__()
        assert dim % 2 == 0, f"RoPE dim must be even, got {dim}"
        self.dim = dim
        self.max_seq_len = max_seq_len
        self.base = base

        # Precompute frequency bands: theta_i = base^(-2i/dim)
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

        # Precompute cos/sin cache for positions [0, max_seq_len)
        self._build_cache(max_seq_len)

    def _build_cache(self, seq_len: int) -> None:
        t = torch.arange(seq_len, dtype=self.inv_freq.dtype, device=self.inv_freq.device)
        freqs = torch.outer(t, self.inv_freq)  # (seq_len, dim/2)
        emb = torch.cat([freqs, freqs], dim=-1)  # (seq_len, dim)
        self.register_buffer("cos_cached", emb.cos(), persistent=False)
        self.register_buffer("sin_cached", emb.sin(), persistent=False)

    def forward(self, x: torch.Tensor, seq_len: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """Return (cos, sin) position tensors for the given sequence length."""
        if seq_len > self.cos_cached.shape[0]:
            self._build_cache(seq_len)
        return (
            self.cos_cached[:seq_len],  # (seq_len, dim)
            self.sin_cached[:seq_len],  # (seq_len, dim)
        )


def _rotate_half(x: torch.Tensor) -> torch.Tensor:
    """Rotate the last dimension: [x1, x2, x3, x4] -> [-x3, -x4, x1, x2]."""
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat([-x2, x1], dim=-1)


def apply_rotary_pos_emb(
    q: torch.Tensor, k: torch.Tensor,
    cos: torch.Tensor, sin: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Apply RoPE to query and key tensors."""
    # cos/sin: (seq_len, head_dim) -> broadcast over (batch, heads, seq_len, head_dim)
    cos = cos.unsqueeze(0).unsqueeze(0)  # (1, 1, seq_len, dim)
    sin = sin.unsqueeze(0).unsqueeze(0)
    q_rotated = q * cos + _rotate_half(q) * sin
    k_rotated = k * cos + _rotate_half(k) * sin
    return q_rotated, k_rotated


# =============================================================================
# Causal Self-Attention
# =============================================================================

class CausalSelfAttention(nn.Module):
    """
    Multi-head self-attention with causal mask and RoPE.

    Uses standard nn.Linear for Q/K/V projections (dense attention weights).
    The sparsity in SparseStack comes from the MLP layers (WINA_MLP), not attention.
    """

    def __init__(self, dim: int, num_heads: int, max_seq_len: int = 2048):
        super().__init__()
        assert dim % num_heads == 0, f"dim {dim} not divisible by num_heads {num_heads}"
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads

        # Q, K, V projections (dense — sparsity is in the MLP)
        self.q_proj = nn.Linear(dim, dim, bias=False)
        self.k_proj = nn.Linear(dim, dim, bias=False)
        self.v_proj = nn.Linear(dim, dim, bias=False)
        self.out_proj = nn.Linear(dim, dim, bias=False)

        # RoPE
        self.rope = RotaryPositionEmbedding(self.head_dim, max_seq_len=max_seq_len)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch, seq_len, _ = x.shape

        # Project to Q, K, V
        q = self.q_proj(x).view(batch, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(batch, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(batch, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        # q, k, v: (batch, heads, seq_len, head_dim)

        # Apply RoPE
        cos, sin = self.rope(x, seq_len)
        q, k = apply_rotary_pos_emb(q, k, cos, sin)

        # Scaled dot-product attention with causal mask
        # Use PyTorch's native SDPA for Flash Attention support on Ampere+
        attn_out = F.scaled_dot_product_attention(
            q, k, v,
            is_causal=True,
            dropout_p=0.0,
        )
        # attn_out: (batch, heads, seq_len, head_dim)

        # Reshape and project output
        attn_out = attn_out.transpose(1, 2).contiguous().view(batch, seq_len, self.dim)
        return self.out_proj(attn_out)


# =============================================================================
# Causal Transformer Block
# =============================================================================

class CausalTransformerBlock(nn.Module):
    """
    Pre-LayerNorm transformer block with causal attention + WINA_MLP.

    Pre-norm: x = x + attn(norm1(x))
              x = x + mlp(norm2(x))

    Pre-norm is more stable than post-norm for training deep models.
    The WINA_MLP is reused directly from the existing SparseStack codebase.
    """

    def __init__(
        self,
        dim: int,
        num_heads: int,
        mlp_hidden_dim: int,
        max_seq_len: int = 2048,
        quant_threshold: float = 0.05,
        gate_fc1: bool = True,
        gate_fc2: bool = False,
        gate_score_mode: str = "heuristic_v0",
    ):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = CausalSelfAttention(dim, num_heads, max_seq_len=max_seq_len)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = WINA_MLP(
            dim, mlp_hidden_dim, dim,
            quant_threshold=quant_threshold,
            gate_fc1=gate_fc1,
            gate_fc2=gate_fc2,
            gate_score_mode=gate_score_mode,
        )

    def forward(
        self,
        x: torch.Tensor,
        mode: str = "dense",
        neuron_threshold: float = 0.1,
        gate_mode: str = "threshold",
        neuron_topk_fraction: float = 0.5,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        # Pre-norm attention (causal)
        x = x + self.attn(self.norm1(x))

        # Pre-norm MLP (sparse via WINA)
        b, s, d = x.shape
        normed = self.norm2(x)
        mlp_in = normed.reshape(b * s, d)
        mlp_out, mlp_log = self.mlp(
            mlp_in,
            mode=mode,
            neuron_threshold=neuron_threshold,
            gate_mode=gate_mode,
            neuron_topk_fraction=neuron_topk_fraction,
        )
        x = x + mlp_out.reshape(b, s, d)

        return x, mlp_log


# =============================================================================
# Causal Sparse Transformer (Full LM Model)
# =============================================================================

class CausalSparseTransformer(nn.Module):
    """
    Autoregressive language model with sparse WINA/LowBit MLP layers.

    Architecture:
        token_emb -> [CausalTransformerBlock x N] -> norm -> lm_head

    Key differences from SparseTransformer (classification):
        - Causal attention mask (no future token visibility)
        - RoPE positional embeddings (not learned)
        - Per-position output: (batch, seq_len, vocab_size)
        - No mean-pooling
        - Optional weight tying (lm_head shares token_emb weights)

    Sparsity interface is identical:
        - mode="dense" / "circuit_masked" / "full_sparse"
        - neuron_threshold, gate_mode, neuron_topk_fraction
    """

    def __init__(
        self,
        vocab_size: int = 50257,
        dim: int = 1024,
        num_heads: int = 16,
        mlp_hidden_dim: int = 4096,
        num_layers: int = 12,
        max_seq_len: int = 1024,
        quant_threshold: float = 0.05,
        gate_fc1: bool = True,
        gate_fc2: bool = False,
        gate_score_mode: str = "heuristic_v0",
        tie_embeddings: bool = True,
    ):
        super().__init__()
        self.vocab_size = vocab_size
        self.dim = dim
        self.max_seq_len = max_seq_len
        self.num_layers = num_layers

        # Token embedding (no positional — RoPE handles position)
        self.token_emb = nn.Embedding(vocab_size, dim)

        # Transformer blocks
        self.blocks = nn.ModuleList([
            CausalTransformerBlock(
                dim=dim,
                num_heads=num_heads,
                mlp_hidden_dim=mlp_hidden_dim,
                max_seq_len=max_seq_len,
                quant_threshold=quant_threshold,
                gate_fc1=gate_fc1,
                gate_fc2=gate_fc2,
                gate_score_mode=gate_score_mode,
            )
            for _ in range(num_layers)
        ])

        # Final layer norm (pre-norm architecture needs this before LM head)
        self.final_norm = nn.LayerNorm(dim)

        # Language modeling head
        self.lm_head = nn.Linear(dim, vocab_size, bias=False)

        # Weight tying: share embedding and output weights
        if tie_embeddings:
            self.lm_head.weight = self.token_emb.weight

        # Initialize weights
        self._init_weights()

    def _init_weights(self) -> None:
        """Initialize weights following GPT-2 conventions."""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
                if module.bias is not None:
                    torch.nn.init.zeros_(module.bias)
            elif isinstance(module, nn.Embedding):
                torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            elif isinstance(module, nn.LayerNorm):
                torch.nn.init.ones_(module.weight)
                torch.nn.init.zeros_(module.bias)

        # Scale residual projections by 1/sqrt(2*num_layers) for stability
        for block in self.blocks:
            nn.init.normal_(
                block.attn.out_proj.weight,
                mean=0.0,
                std=0.02 / math.sqrt(2 * self.num_layers),
            )

    def _expand_topk_fraction(
        self, neuron_topk_fraction: float | Sequence[float] | None
    ) -> List[float] | None:
        if neuron_topk_fraction is None:
            return None
        if isinstance(neuron_topk_fraction, (list, tuple)):
            if len(neuron_topk_fraction) != len(self.blocks):
                raise ValueError("Per-block neuron_topk_fraction length mismatch")
            return [float(val) for val in neuron_topk_fraction]
        return [float(neuron_topk_fraction)] * len(self.blocks)

    def forward(
        self,
        input_ids: torch.Tensor,
        mode: str = "dense",
        neuron_threshold: float = 0.1,
        gate_mode: str = "threshold",
        neuron_topk_fraction: float = 0.5,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Forward pass for language modeling.

        Args:
            input_ids: (batch, seq_len) token indices
            mode: "dense", "circuit_masked", or "full_sparse"
            neuron_threshold: WINA gating threshold
            gate_mode: "threshold" or "topk"
            neuron_topk_fraction: fraction of neurons to keep in topk mode

        Returns:
            logits: (batch, seq_len, vocab_size) — next-token predictions at every position
            log: dict of sparsity statistics
        """
        b, s = input_ids.shape
        if s > self.max_seq_len:
            raise ValueError(f"Sequence length {s} exceeds max {self.max_seq_len}")

        # Embed tokens (no positional embedding — RoPE is applied inside attention)
        x = self.token_emb(input_ids)

        # Run through transformer blocks
        block_logs: List[Dict[str, float]] = []
        topk_schedule = self._expand_topk_fraction(neuron_topk_fraction)

        for idx, block in enumerate(self.blocks):
            current_topk = (
                topk_schedule[idx] if topk_schedule is not None
                else neuron_topk_fraction
            )
            x, block_log = block(
                x,
                mode=mode,
                neuron_threshold=neuron_threshold,
                gate_mode=gate_mode,
                neuron_topk_fraction=current_topk,
            )
            block_logs.append(block_log)

        # Final norm + LM head (no pooling — output at every position)
        x = self.final_norm(x)
        logits = self.lm_head(x)  # (batch, seq_len, vocab_size)

        # Aggregate block logs
        combined_log = self._aggregate_block_logs(block_logs)
        combined_log["blocks"] = block_logs

        return logits, combined_log

    @staticmethod
    def _aggregate_block_logs(block_logs: List[Dict[str, float]]) -> Dict[str, float]:
        if not block_logs:
            return {}
        agg = dict(block_logs[-1])
        agg["num_blocks"] = float(len(block_logs))
        for field in ("gating_l2_diff", "gating_l2_diff_fc1", "gating_l2_diff_fc2"):
            agg[field] = sum(log.get(field, 0.0) for log in block_logs)
        return agg

    def count_parameters(self) -> Dict[str, int]:
        """Count total and trainable parameters (handles weight tying)."""
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        # Don't double-count tied weights
        seen = set()
        unique_total = 0
        for p in self.parameters():
            if p.data_ptr() not in seen:
                seen.add(p.data_ptr())
                unique_total += p.numel()
        return {
            "total": total,
            "trainable": trainable,
            "unique": unique_total,
        }

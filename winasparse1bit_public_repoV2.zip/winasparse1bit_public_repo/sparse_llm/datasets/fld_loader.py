"""
FLD Dataset Loader - Formal Logic Deduction for Phase 13.

Loads formal logic deduction tasks from HuggingFace (or generates synthetic equivalents)
for testing SparseStack on natural language reasoning.

Task Types:
1. Modus Ponens: "All A are B. X is A. Therefore X is B." -> True/False
2. Modus Tollens: "All A are B. X is not B. Therefore X is not A." -> True/False
3. Syllogisms: "All A are B. All B are C. Therefore all A are C." -> True/False
4. Contraposition: "If A then B" === "If not B then not A" -> True/False

The pedagogical style focuses on TEACHING reasoning, not just testing it.
Each example includes the reasoning trace showing WHY the answer is correct.
"""

import random
import torch
from typing import List, Dict, Tuple, Optional
from pathlib import Path

# Try to import HuggingFace datasets, fallback to synthetic generation
try:
    from datasets import load_dataset, Dataset
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False


class FLDDataset:
    """
    Formal Logic Deduction dataset for SparseStack training.

    Provides natural language logical reasoning tasks with step-by-step traces.
    Compatible with the LogicalDataset interface (same build_batch API).
    """

    # Named entity pools for natural language generation
    # Entity categories (plural form) with their singular forms
    ENTITIES = {
        "dogs": "dog", "cats": "cat", "birds": "bird", "fish": "fish",
        "mammals": "mammal", "animals": "animal", "reptiles": "reptile",
        "students": "student", "teachers": "teacher", "professors": "professor",
        "scientists": "scientist", "engineers": "engineer",
        "metals": "metal", "liquids": "liquid", "solids": "solid",
        "gases": "gas", "elements": "element",
        "flowers": "flower", "trees": "tree", "plants": "plant",
        "vegetables": "vegetable", "fruits": "fruit",
        "cars": "car", "vehicles": "vehicle", "machines": "machine",
        "computers": "computer", "devices": "device"
    }

    PROPERTIES = [
        "mortal", "alive", "intelligent", "heavy", "light", "fast", "slow",
        "large", "small", "warm", "cold", "organic", "natural",
        "expensive", "valuable", "dangerous", "safe", "useful"
    ]

    INDIVIDUALS = [
        "Socrates", "Plato", "Aristotle", "Einstein", "Newton", "Darwin",
        "Alice", "Bob", "Charlie", "Diana", "Eve", "Frank",
        "Max", "Luna", "Rocky", "Bella", "Duke", "Daisy"
    ]

    def __init__(
        self,
        vocab_size: int,
        seq_len: int,
        task_type: str = "modus_ponens",
        pad_idx: int = 0,
        bos_idx: int = 1,
        sep_idx: int = 2,
        eos_idx: int = 3,
        use_hf: bool = True,
        cache_dir: Optional[str] = None,
        include_trace: bool = True,
    ):
        self.vocab_size = vocab_size
        self.seq_len = seq_len
        self.task_type = task_type
        self.pad_idx = pad_idx
        self.bos_idx = bos_idx
        self.sep_idx = sep_idx
        self.eos_idx = eos_idx
        self.use_hf = use_hf and HF_AVAILABLE
        self.cache_dir = cache_dir or str(Path.home() / ".cache" / "fld")
        self.include_trace = include_trace

        # Build character-level token map for natural language
        self._build_token_map()

        # Try to load HuggingFace dataset
        self._hf_dataset = None
        if self.use_hf:
            self._load_hf_dataset()

    def _article(self, word: str) -> str:
        """Return 'a' or 'an' based on word."""
        return "an" if word[0].lower() in 'aeiou' else "a"

    def _singular(self, plural: str) -> str:
        """Get singular form of entity."""
        return self.ENTITIES.get(plural, plural.rstrip('s'))

    def _entity_list(self) -> List[str]:
        """Get list of plural entity names."""
        return list(self.ENTITIES.keys())

    def _build_token_map(self) -> None:
        """Build character-level token map for natural language encoding."""
        # Special tokens: 0-3 reserved
        self.special_start = 4

        # Character tokens for natural language (covers a-z, A-Z, 0-9, punctuation)
        self.char_to_idx = {}
        idx = self.special_start

        # Lowercase letters
        for c in 'abcdefghijklmnopqrstuvwxyz':
            self.char_to_idx[c] = idx
            idx += 1

        # Uppercase letters
        for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
            self.char_to_idx[c] = idx
            idx += 1

        # Digits
        for c in '0123456789':
            self.char_to_idx[c] = idx
            idx += 1

        # Punctuation and special chars
        for c in ' .,;:!?\'"()-[]{}':
            self.char_to_idx[c] = idx
            idx += 1

        # Special markers for traces
        self.trace_start_idx = idx
        self.trace_end_idx = idx + 1
        self.step_marker_idx = idx + 2
        self.therefore_idx = idx + 3

    def _encode_text(self, text: str) -> List[int]:
        """Encode text to token indices (character-level)."""
        tokens = []
        for char in text:
            if char in self.char_to_idx:
                tokens.append(self.char_to_idx[char])
            else:
                # Unknown char - map to space
                tokens.append(self.char_to_idx.get(' ', self.special_start))
        return tokens

    def _pack_batch(
        self,
        expressions: List[str],
        labels: List[int],
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Pack encoded expressions into tensor batch."""
        batch_size = len(expressions)
        x = torch.full((batch_size, self.seq_len), self.pad_idx, dtype=torch.long, device=device)
        y = torch.tensor(labels, dtype=torch.long, device=device)

        for i, expr in enumerate(expressions):
            tokens = self._encode_text(expr)

            # [BOS] tokens [EOS] [PAD...]
            seq = [self.bos_idx] + tokens + [self.eos_idx]
            seq = seq[:self.seq_len]  # Truncate if needed

            x[i, :len(seq)] = torch.tensor(seq, dtype=torch.long, device=device)

        return x, y

    def _load_hf_dataset(self) -> None:
        """Attempt to load FLD from HuggingFace."""
        try:
            # Try common FLD dataset sources
            # Note: Actual dataset names may vary; this is a best-effort approach
            self._hf_dataset = load_dataset(
                "tasksource/fld",
                split="train",
                cache_dir=self.cache_dir
            )
            print(f"[FLD] Loaded {len(self._hf_dataset)} examples from HuggingFace")
        except Exception as e:
            print(f"[FLD] HuggingFace load failed: {e}")
            print("[FLD] Falling back to synthetic generation")
            self._hf_dataset = None

    # =========================================================================
    # Modus Ponens: If P then Q. P. Therefore Q.
    # =========================================================================

    def _generate_modus_ponens(self) -> Tuple[str, int, str]:
        """
        Generate modus ponens example.

        Form: "All A are B. X is A. Therefore X is B."
        This is ALWAYS valid (label=1).

        To create invalid examples, we flip the conclusion.
        """
        # Pick random categories and individual
        entities = self._entity_list()
        category_a = random.choice(entities)
        category_b = random.choice([e for e in entities if e != category_a])
        property_b = random.choice(self.PROPERTIES)
        individual = random.choice(self.INDIVIDUALS)

        singular_a = self._singular(category_a)
        singular_b = self._singular(category_b)
        article_a = self._article(singular_a)
        article_b = self._article(singular_b)

        # Randomly use property or category for B
        use_property = random.random() < 0.5

        if use_property:
            premise1 = f"All {category_a} are {property_b}."
            premise2 = f"{individual} is {article_a} {singular_a}."
            valid_conclusion = f"Therefore, {individual} is {property_b}."
            invalid_conclusion = f"Therefore, {individual} is not {property_b}."
        else:
            premise1 = f"All {category_a} are {category_b}."
            premise2 = f"{individual} is {article_a} {singular_a}."
            valid_conclusion = f"Therefore, {individual} is {article_b} {singular_b}."
            invalid_conclusion = f"Therefore, {individual} is not {article_b} {singular_b}."

        # Decide if this example is valid or invalid
        is_valid = random.random() < 0.5
        conclusion = valid_conclusion if is_valid else invalid_conclusion
        label = 1 if is_valid else 0

        # Build expression
        base = f"{premise1} {premise2} {conclusion}"

        # Add trace if requested
        if self.include_trace:
            if use_property:
                trace = f" [TRACE: Modus ponens applies. {individual} is {article_a} {singular_a}, and all {category_a} are {property_b}, so {individual} must be {property_b}. Conclusion is {'VALID' if is_valid else 'INVALID'}.]"
            else:
                trace = f" [TRACE: Modus ponens applies. {individual} belongs to {category_a}, which are all {category_b}. Conclusion is {'VALID' if is_valid else 'INVALID'}.]"
            base += trace

        return base, label, "modus_ponens"

    # =========================================================================
    # Modus Tollens: If P then Q. Not Q. Therefore not P.
    # =========================================================================

    def _generate_modus_tollens(self) -> Tuple[str, int, str]:
        """
        Generate modus tollens example.

        Form: "If X is A, then X is B. X is not B. Therefore X is not A."
        """
        entities = self._entity_list()
        category_a = random.choice(entities)
        property_b = random.choice(self.PROPERTIES)
        individual = random.choice(self.INDIVIDUALS)

        singular_a = self._singular(category_a)
        article_a = self._article(singular_a)

        premise1 = f"If {individual} is {article_a} {singular_a}, then {individual} is {property_b}."
        premise2 = f"{individual} is not {property_b}."

        valid_conclusion = f"Therefore, {individual} is not {article_a} {singular_a}."
        invalid_conclusion = f"Therefore, {individual} is {article_a} {singular_a}."

        is_valid = random.random() < 0.5
        conclusion = valid_conclusion if is_valid else invalid_conclusion
        label = 1 if is_valid else 0

        base = f"{premise1} {premise2} {conclusion}"

        if self.include_trace:
            trace = f" [TRACE: Modus tollens. Given 'If A then B' and 'not B', we conclude 'not A'. The negation of the consequent implies negation of the antecedent. Conclusion is {'VALID' if is_valid else 'INVALID'}.]"
            base += trace

        return base, label, "modus_tollens"

    # =========================================================================
    # Syllogism: All A are B. All B are C. Therefore all A are C.
    # =========================================================================

    def _generate_syllogism(self) -> Tuple[str, int, str]:
        """
        Generate categorical syllogism.

        Form: "All A are B. All B are C. Therefore all A are C."
        """
        # Pick three distinct categories
        entities = self._entity_list()
        categories = random.sample(entities, 3)
        cat_a, cat_b, cat_c = categories

        premise1 = f"All {cat_a} are {cat_b}."
        premise2 = f"All {cat_b} are {cat_c}."

        valid_conclusion = f"Therefore, all {cat_a} are {cat_c}."
        # Invalid: affirming the consequent or other fallacy
        invalid_conclusion = f"Therefore, all {cat_c} are {cat_a}."

        is_valid = random.random() < 0.5
        conclusion = valid_conclusion if is_valid else invalid_conclusion
        label = 1 if is_valid else 0

        base = f"{premise1} {premise2} {conclusion}"

        if self.include_trace:
            trace = f" [TRACE: Barbara syllogism (AAA-1). {cat_a} subset of {cat_b}, {cat_b} subset of {cat_c}, so {cat_a} subset of {cat_c}. Reversing does NOT follow. Conclusion is {'VALID' if is_valid else 'INVALID'}.]"
            base += trace

        return base, label, "syllogism"

    # =========================================================================
    # Contraposition: "If A then B" === "If not B then not A"
    # =========================================================================

    def _generate_contraposition(self) -> Tuple[str, int, str]:
        """
        Test contraposition understanding.

        "If A then B" is logically equivalent to "If not B then not A".
        "If A then B" is NOT equivalent to "If B then A" (affirming consequent).
        """
        property_a = random.choice(self.PROPERTIES)
        property_b = random.choice([p for p in self.PROPERTIES if p != property_a])

        original = f"If something is {property_a}, then it is {property_b}."

        # Valid contraposition
        valid_equiv = f"If something is not {property_b}, then it is not {property_a}."
        # Invalid: converse
        invalid_equiv = f"If something is {property_b}, then it is {property_a}."

        is_valid = random.random() < 0.5
        equivalent = valid_equiv if is_valid else invalid_equiv
        label = 1 if is_valid else 0

        base = f"{original} This is equivalent to: {equivalent}"

        if self.include_trace:
            if is_valid:
                trace = " [TRACE: Contraposition is valid. 'If P then Q' === 'If not Q then not P'. This preserves logical equivalence.]"
            else:
                trace = " [TRACE: Converse fallacy. 'If P then Q' does NOT imply 'If Q then P'. This is a logical error.]"
            base += trace

        return base, label, "contraposition"

    # =========================================================================
    # Batch building methods
    # =========================================================================

    def build_modus_ponens_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate batch of modus ponens examples."""
        expressions = []
        labels = []

        for _ in range(batch_size):
            expr, label, _ = self._generate_modus_ponens()
            expressions.append(expr)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_modus_tollens_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate batch of modus tollens examples."""
        expressions = []
        labels = []

        for _ in range(batch_size):
            expr, label, _ = self._generate_modus_tollens()
            expressions.append(expr)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_syllogism_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate batch of syllogism examples."""
        expressions = []
        labels = []

        for _ in range(batch_size):
            expr, label, _ = self._generate_syllogism()
            expressions.append(expr)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_contraposition_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate batch of contraposition examples."""
        expressions = []
        labels = []

        for _ in range(batch_size):
            expr, label, _ = self._generate_contraposition()
            expressions.append(expr)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_mixed_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Generate mixed batch of all task types."""
        generators = [
            self._generate_modus_ponens,
            self._generate_modus_tollens,
            self._generate_syllogism,
            self._generate_contraposition,
        ]

        expressions = []
        labels = []

        for _ in range(batch_size):
            generator = random.choice(generators)
            expr, label, _ = generator()
            expressions.append(expr)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_batch(
        self,
        batch_size: int,
        device: torch.device,
        task_type: Optional[str] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Build batch for the configured or specified task type.

        Args:
            batch_size: Number of samples
            device: Torch device
            task_type: Override task type

        Returns:
            (x, y) tensors of shapes (batch_size, seq_len) and (batch_size,)
        """
        task = task_type or self.task_type

        if task == "modus_ponens":
            return self.build_modus_ponens_batch(batch_size, device)
        elif task == "modus_tollens":
            return self.build_modus_tollens_batch(batch_size, device)
        elif task == "syllogism":
            return self.build_syllogism_batch(batch_size, device)
        elif task == "contraposition":
            return self.build_contraposition_batch(batch_size, device)
        elif task == "mixed" or task == "fld":
            return self.build_mixed_batch(batch_size, device)
        else:
            raise ValueError(
                f"Unknown FLD task type: {task}. "
                f"Use: modus_ponens, modus_tollens, syllogism, contraposition, mixed, fld"
            )


# =============================================================================
# Standalone Functions (for quick testing)
# =============================================================================

def generate_modus_ponens_example(include_trace: bool = True) -> Tuple[str, int, str]:
    """Generate a single modus ponens example."""
    ds = FLDDataset(vocab_size=128, seq_len=256, include_trace=include_trace)
    return ds._generate_modus_ponens()


def generate_syllogism_example(include_trace: bool = True) -> Tuple[str, int, str]:
    """Generate a single syllogism example."""
    ds = FLDDataset(vocab_size=128, seq_len=256, include_trace=include_trace)
    return ds._generate_syllogism()


def test_fld_dataset():
    """Quick test of FLD dataset generation."""
    import torch

    print("=" * 60)
    print("FLD Dataset Test")
    print("=" * 60)

    ds = FLDDataset(
        vocab_size=128,
        seq_len=256,
        task_type="mixed",
        include_trace=True
    )

    device = torch.device("cpu")

    # Generate samples
    print("\n--- Modus Ponens ---")
    for _ in range(2):
        expr, label, _ = ds._generate_modus_ponens()
        print(f"Label={label}: {expr[:150]}...")

    print("\n--- Modus Tollens ---")
    for _ in range(2):
        expr, label, _ = ds._generate_modus_tollens()
        print(f"Label={label}: {expr[:150]}...")

    print("\n--- Syllogism ---")
    for _ in range(2):
        expr, label, _ = ds._generate_syllogism()
        print(f"Label={label}: {expr[:150]}...")

    print("\n--- Contraposition ---")
    for _ in range(2):
        expr, label, _ = ds._generate_contraposition()
        print(f"Label={label}: {expr[:150]}...")

    # Test batch generation
    print("\n--- Batch Test ---")
    x, y = ds.build_batch(4, device, "mixed")
    print(f"Input shape: {x.shape}")
    print(f"Labels shape: {y.shape}")
    print(f"Labels: {y.tolist()}")

    print("\n" + "=" * 60)
    print("FLD Dataset Test Complete")
    print("=" * 60)


if __name__ == "__main__":
    test_fld_dataset()

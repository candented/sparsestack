import json
import random
import torch
from typing import List, Dict, Tuple, Optional

class LexicalRealDataset:
    """
    Handles loading and sampling from real-world lexical datasets.
    
    Supports two formats:
    1. Legacy JSON format (lexical_real_v0.json):
       [{"word": "example", "synonyms": [...], "antonyms": [...]}, ...]
    
    2. New JSONL format (lexical_real_deep_v1.jsonl):
       {"input": "Is a beagle a canine?", "target": "True", "category": "hypernym_entailment_positive"}
       One JSON object per line.
    """
    def __init__(self, data_path: str, vocab_size: int, seq_len: int, pad_idx: int = 0, bos_idx: int = 1, sep_idx: int = 2, eos_idx: int = 3):
        self.vocab_size = vocab_size
        self.seq_len = seq_len
        self.pad_idx = pad_idx
        self.bos_idx = bos_idx
        self.sep_idx = sep_idx
        self.eos_idx = eos_idx
        
        # Load dataset - support both JSON and JSONL formats
        with open(data_path, 'r') as f:
            if data_path.endswith('.jsonl'):
                # JSONL format: one JSON object per line
                self.data = [json.loads(line) for line in f]
                self.format = 'jsonl'
            else:
                # JSON format: single array
                self.data = json.load(f)
                self.format = 'json'
            
        self._validate_data()
        
    def _validate_data(self):
        if not isinstance(self.data, list):
            raise ValueError("Dataset root must be a list")
        if len(self.data) == 0:
            raise ValueError("Dataset is empty")
        
        # Detect format based on first item
        if self.data[0].get('input') is not None:
            self.format = 'jsonl'
        elif self.data[0].get('word') is not None:
            self.format = 'json'
        else:
            raise ValueError(f"Unknown dataset format. First item keys: {list(self.data[0].keys())}")
            
    def _encode_text(self, text: str) -> List[int]:
        # Simple character-level ASCII encoding modulo vocab_size for now
        # In a real pipeline, this would use a proper tokenizer
        # Reserve 4 special tokens, map chars to rest
        return [4 + (ord(c) % (self.vocab_size - 4)) for c in text]

    def _pack_batch(self, pairs: List[Tuple[str, str]], labels: List[int], device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
        batch_size = len(pairs)
        x = torch.full((batch_size, self.seq_len), self.pad_idx, dtype=torch.long, device=device)
        y = torch.tensor(labels, dtype=torch.long, device=device)
        
        for i, (w1, w2) in enumerate(pairs):
            t1 = self._encode_text(w1)
            t2 = self._encode_text(w2)
            
            # [BOS] w1 [SEP] w2 [EOS]
            seq = [self.bos_idx] + t1 + [self.sep_idx] + t2 + [self.eos_idx]
            seq = seq[:self.seq_len] # Truncate if needed
            
            x[i, :len(seq)] = torch.tensor(seq, dtype=torch.long, device=device)
            
        return x, y
    
    def _pack_batch_new_format(self, inputs: List[str], labels: List[int], device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
        """Pack batch for new JSONL format (single input string)."""
        batch_size = len(inputs)
        x = torch.full((batch_size, self.seq_len), self.pad_idx, dtype=torch.long, device=device)
        y = torch.tensor(labels, dtype=torch.long, device=device)
        
        for i, input_text in enumerate(inputs):
            tokens = self._encode_text(input_text)
            
            # [BOS] input [EOS]
            seq = [self.bos_idx] + tokens + [self.eos_idx]
            seq = seq[:self.seq_len]  # Truncate if needed
            
            x[i, :len(seq)] = torch.tensor(seq, dtype=torch.long, device=device)
            
        return x, y

    def build_synonym_batch(self, batch_size: int, device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Builds a batch for synonym detection.
        
        For new JSONL format: samples from the dataset and converts target to binary label
        For old JSON format: uses word/synonym pairs
        """
        if self.format == 'jsonl':
            # New format: sample from dataset
            inputs = []
            labels = []
            
            for _ in range(batch_size):
                item = random.choice(self.data)
                inputs.append(item['input'])
                
                # Convert target to binary label
                target = item['target'].lower().strip()
                if target in ['true', 'yes', '1']:
                    labels.append(1)
                elif target in ['false', 'no', '0']:
                    labels.append(0)
                else:
                    # For non-binary targets, use hash to get consistent label
                    labels.append(hash(target) % 2)
            
            return self._pack_batch_new_format(inputs, labels, device)
        
        else:
            # Old format: word/synonym pairs
            pairs = []
            labels = []
            
            for _ in range(batch_size):
                is_pos = random.random() < 0.5
                item = random.choice(self.data)
                word = item.get("word", "")
                
                if is_pos and item.get("synonyms"):
                    target = random.choice(item["synonyms"])
                    label = 1
                else:
                    # Negative sample: pick a random other word
                    other = random.choice(self.data)
                    while other == item and len(self.data) > 1:
                        other = random.choice(self.data)
                    
                    if other.get("synonyms") and random.random() < 0.5:
                        target = random.choice(other["synonyms"])
                    else:
                        target = other.get("word", "unknown")
                    label = 0
                
                pairs.append((word, target))
                labels.append(label)
                
            return self._pack_batch(pairs, labels, device)

    def build_antonym_batch(self, batch_size: int, device: torch.device) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Builds a batch for antonym detection.
        
        For new JSONL format: same as synonym_batch (uses the dataset as-is)
        For old JSON format: uses word/antonym pairs
        """
        if self.format == 'jsonl':
            # New format: just sample from dataset (same as synonym batch)
            return self.build_synonym_batch(batch_size, device)
        
        else:
            # Old format: word/antonym pairs
            pairs = []
            labels = []
            
            # Filter for items that actually have antonyms
            valid_items = [d for d in self.data if d.get("antonyms")]
            if not valid_items:
                raise ValueError("No items with antonyms found in dataset")

            for _ in range(batch_size):
                is_pos = random.random() < 0.5
                item = random.choice(valid_items)
                word = item.get("word", "")
                
                if is_pos:
                    target = random.choice(item["antonyms"])
                    label = 1
                else:
                    # Negative: try to use synonym if available (hard negative), else random
                    if item.get("synonyms") and random.random() < 0.5:
                         target = random.choice(item["synonyms"])
                    else:
                        other = random.choice(self.data)
                        target = other.get("word", "unknown")
                    label = 0
                    
                pairs.append((word, target))
                labels.append(label)
                
            return self._pack_batch(pairs, labels, device)

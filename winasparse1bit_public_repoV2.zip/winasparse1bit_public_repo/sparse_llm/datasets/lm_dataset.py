"""
Phase 15: Language Modeling Dataset Pipeline.

Provides two dataset modes:
- ChunkedLMDataset: Pre-tokenize and chunk into memory (for TinyStories PoC)
- StreamingLMDataset: Stream from HuggingFace datasets (for large corpora)

Uses tiktoken (GPT-2 encoding) for tokenization. vocab_size = 50257.
"""

from __future__ import annotations

import os
from typing import Dict, Iterator, Optional

import torch
from torch.utils.data import Dataset, IterableDataset, DataLoader


def get_tokenizer(name: str = "gpt2"):
    """Get a tiktoken tokenizer. Falls back to HuggingFace if tiktoken unavailable."""
    try:
        import tiktoken
        enc = tiktoken.get_encoding("gpt2")
        return enc
    except ImportError:
        from transformers import AutoTokenizer
        return AutoTokenizer.from_pretrained(name)


def tokenize_text(tokenizer, text: str) -> list[int]:
    """Tokenize text using either tiktoken or HuggingFace tokenizer."""
    if hasattr(tokenizer, 'encode_ordinary'):
        # tiktoken
        return tokenizer.encode_ordinary(text)
    else:
        # HuggingFace
        return tokenizer.encode(text, add_special_tokens=False)


def get_eot_token(tokenizer) -> int:
    """Get end-of-text token ID."""
    if hasattr(tokenizer, 'eot_token'):
        return tokenizer.eot_token
    elif hasattr(tokenizer, 'eos_token_id'):
        return tokenizer.eos_token_id
    return 50256  # GPT-2 <|endoftext|>


class ChunkedLMDataset(Dataset):
    """
    Pre-tokenized dataset loaded into memory, chunked into fixed-length windows.

    Best for small datasets (TinyStories ~500MB). Tokenizes everything upfront,
    then serves random-access chunks for training.

    Each sample returns:
        input_ids: (seq_len,) — token indices
        labels:    (seq_len,) — next-token targets (input shifted by 1, last = -100)
    """

    def __init__(
        self,
        dataset_name: str = "roneneldan/TinyStories",
        split: str = "train",
        seq_len: int = 512,
        tokenizer_name: str = "gpt2",
        max_tokens: Optional[int] = None,
        text_field: str = "text",
    ):
        super().__init__()
        self.seq_len = seq_len

        print(f"Loading dataset: {dataset_name} ({split})...")
        from datasets import load_dataset

        ds = load_dataset(dataset_name, split=split, trust_remote_code=True)

        tokenizer = get_tokenizer(tokenizer_name)
        eot = get_eot_token(tokenizer)

        # Tokenize all text into one long token stream
        print(f"Tokenizing {len(ds)} documents...")
        all_tokens = []
        for i, example in enumerate(ds):
            text = example.get(text_field, "")
            if not text:
                continue
            tokens = tokenize_text(tokenizer, text)
            all_tokens.extend(tokens)
            all_tokens.append(eot)  # Document separator

            if max_tokens and len(all_tokens) >= max_tokens:
                all_tokens = all_tokens[:max_tokens]
                break

            if (i + 1) % 50000 == 0:
                print(f"  Tokenized {i + 1} docs ({len(all_tokens):,} tokens)...")

        self.tokens = torch.tensor(all_tokens, dtype=torch.long)
        # Number of full chunks we can extract (need seq_len + 1 for input/target shift)
        self.num_chunks = max(0, (len(self.tokens) - 1) // seq_len)

        print(f"Dataset ready: {len(self.tokens):,} tokens, {self.num_chunks:,} chunks of {seq_len}")

    def __len__(self) -> int:
        return self.num_chunks

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        start = idx * self.seq_len
        end = start + self.seq_len + 1  # +1 for target shift
        chunk = self.tokens[start:end]

        input_ids = chunk[:-1]  # (seq_len,)
        labels = chunk[1:]      # (seq_len,) — shifted by 1

        return {"input_ids": input_ids, "labels": labels}


class StreamingLMDataset(IterableDataset):
    """
    Streaming dataset from HuggingFace for large corpora.

    Tokenizes on-the-fly and yields fixed-length chunks. Does not load
    the full dataset into memory.

    Each sample returns:
        input_ids: (seq_len,) — token indices
        labels:    (seq_len,) — next-token targets
    """

    def __init__(
        self,
        dataset_name: str = "Skylion007/openwebtext",
        split: str = "train",
        seq_len: int = 1024,
        tokenizer_name: str = "gpt2",
        text_field: str = "text",
    ):
        super().__init__()
        self.dataset_name = dataset_name
        self.split = split
        self.seq_len = seq_len
        self.tokenizer_name = tokenizer_name
        self.text_field = text_field

    def __iter__(self) -> Iterator[Dict[str, torch.Tensor]]:
        from datasets import load_dataset

        tokenizer = get_tokenizer(self.tokenizer_name)
        eot = get_eot_token(tokenizer)

        ds = load_dataset(
            self.dataset_name, split=self.split,
            streaming=True, trust_remote_code=True,
        )

        buffer = []
        for example in ds:
            text = example.get(self.text_field, "")
            if not text:
                continue
            tokens = tokenize_text(tokenizer, text)
            buffer.extend(tokens)
            buffer.append(eot)

            # Yield complete chunks from buffer
            while len(buffer) >= self.seq_len + 1:
                chunk = buffer[:self.seq_len + 1]
                buffer = buffer[self.seq_len:]

                input_ids = torch.tensor(chunk[:-1], dtype=torch.long)
                labels = torch.tensor(chunk[1:], dtype=torch.long)

                yield {"input_ids": input_ids, "labels": labels}


def build_lm_dataloader(
    cfg: dict,
    split: str = "train",
    batch_size: Optional[int] = None,
) -> DataLoader:
    """
    Factory: build a DataLoader from config.

    Config keys (under cfg["lm"]):
        dataset: str — HuggingFace dataset name
        seq_len: int — sequence length
        tokenizer: str — tokenizer name
        streaming: bool — use streaming mode
        max_tokens: int — max tokens to load (chunked mode only)
        text_field: str — field name in dataset
    """
    lm_cfg = cfg.get("lm", {})
    dataset_name = lm_cfg.get("dataset", "roneneldan/TinyStories")
    seq_len = lm_cfg.get("seq_len", 512)
    tokenizer_name = lm_cfg.get("tokenizer", "gpt2")
    streaming = lm_cfg.get("streaming", False)
    max_tokens = lm_cfg.get("max_tokens", None)
    text_field = lm_cfg.get("text_field", "text")
    bs = batch_size or cfg.get("training", {}).get("batch_size", 16)

    if streaming:
        dataset = StreamingLMDataset(
            dataset_name=dataset_name,
            split=split,
            seq_len=seq_len,
            tokenizer_name=tokenizer_name,
            text_field=text_field,
        )
        return DataLoader(dataset, batch_size=bs, num_workers=0)
    else:
        dataset = ChunkedLMDataset(
            dataset_name=dataset_name,
            split=split,
            seq_len=seq_len,
            tokenizer_name=tokenizer_name,
            max_tokens=max_tokens,
            text_field=text_field,
        )
        return DataLoader(
            dataset, batch_size=bs, shuffle=(split == "train"),
            num_workers=0, pin_memory=True,
        )

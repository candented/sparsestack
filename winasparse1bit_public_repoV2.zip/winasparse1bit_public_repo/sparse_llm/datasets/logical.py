"""
LogicalDataset - Procedural generators for multi-step logical reasoning tasks.

Designed for Phase 11 (Logical Sovereignty) to test "reasoning depth > vocabulary width".

Task Types:
1. Implication Chains: "A:T A->B B->C ? C" -> requires transitive reasoning
2. Recursive Parity: "(0^1)^(1^0) = ?" -> requires nested XOR evaluation
3. SAT-lite: "(A|~B)&(B|C) SAT?" -> requires satisfiability checking
4. Arithmetic Chains: "3 + 2 * 4" -> requires PEMDAS order of operations

Phase 12+ Addition:
Arithmetic chains provide a SMOOTHER difficulty curve than parity:
- Parity: depth=2 (100%) -> depth=3 (53%) = CLIFF DROP
- Arithmetic: ops=1 -> ops=2 -> ops=3 = GRADUAL INCREASE

This makes arithmetic better suited for testing scratchpad/CoT mechanisms
on sparse attention architectures.
"""

import random
import torch
from typing import List, Dict, Tuple, Optional


class LogicalDataset:
    """
    Generates logical reasoning tasks that require multi-step inference.

    Unlike LexicalRealDataset, this generates tasks procedurally rather than
    loading from files. All tasks have deterministic ground truth labels.

    Format: Same (input_tensor, label_tensor) contract as LexicalRealDataset
    """

    def __init__(
        self,
        vocab_size: int,
        seq_len: int,
        task_type: str = "implication",
        pad_idx: int = 0,
        bos_idx: int = 1,
        sep_idx: int = 2,
        eos_idx: int = 3,
        # Task-specific params
        chain_depth: int = 3,        # implication chains
        recursive_steps: int = 2,    # recursive parity (2^steps leaves)
        num_clauses: int = 3,        # SAT-lite
        num_vars: int = 4,           # SAT-lite
    ):
        self.vocab_size = vocab_size
        self.seq_len = seq_len
        self.task_type = task_type
        self.pad_idx = pad_idx
        self.bos_idx = bos_idx
        self.sep_idx = sep_idx
        self.eos_idx = eos_idx

        # Task params
        self.chain_depth = chain_depth
        self.recursive_steps = recursive_steps
        self.num_clauses = num_clauses
        self.num_vars = num_vars

        # Build token map
        self._build_token_map()

    def _build_token_map(self) -> None:
        """Build token indices for logical symbols."""
        # Special tokens: 0-3 reserved (pad, bos, sep, eos)
        self.special_start = 4

        # Variables: A-Z (indices 4-29)
        self.var_tokens = {chr(65 + i): self.special_start + i for i in range(26)}

        # Operators and values (indices 30+)
        self.op_base = 30
        self.token_map = {
            '>': self.op_base,       # implication (use > for -> to avoid multi-char)
            '&': self.op_base + 1,   # AND
            '|': self.op_base + 2,   # OR
            '~': self.op_base + 3,   # NOT
            'T': self.op_base + 4,   # True
            'F': self.op_base + 5,   # False
            ':': self.op_base + 6,   # assignment
            '?': self.op_base + 7,   # query marker
            ' ': self.op_base + 8,   # space
            '^': self.op_base + 9,   # XOR
            '(': self.op_base + 10,  # left paren
            ')': self.op_base + 11,  # right paren
            '0': self.op_base + 12,  # digit 0
            '1': self.op_base + 13,  # digit 1
            '=': self.op_base + 14,  # equals
            'S': self.op_base + 15,  # SAT marker
            '[TRACE]': self.op_base + 16,  # trace start marker
            '[END]': self.op_base + 17,    # trace end marker
            '[STEP]': self.op_base + 18,   # step separator (optional)
            # Arithmetic tokens (Phase 12+)
            '+': self.op_base + 19,  # addition
            '*': self.op_base + 20,  # multiplication
            '-': self.op_base + 21,  # subtraction
            '2': self.op_base + 22,  # digit 2
            '3': self.op_base + 23,  # digit 3
            '4': self.op_base + 24,  # digit 4
            '5': self.op_base + 25,  # digit 5
            '6': self.op_base + 26,  # digit 6
            '7': self.op_base + 27,  # digit 7
            '8': self.op_base + 28,  # digit 8
            '9': self.op_base + 29,  # digit 9
            ',': self.op_base + 30,  # comma for trace steps
            '[ANS]': self.op_base + 31,  # answer marker
        }

    def _encode_text(self, text: str) -> List[int]:
        """Encode logical expression to token indices."""
        tokens = []
        i = 0
        while i < len(text):
            char = text[i]

            # Check for multi-char tokens first
            if text[i:i+7] == '[TRACE]':
                tokens.append(self.token_map['[TRACE]'])
                i += 7
                continue
            if text[i:i+5] == '[END]':
                tokens.append(self.token_map['[END]'])
                i += 5
                continue
            if text[i:i+6] == '[STEP]':
                tokens.append(self.token_map['[STEP]'])
                i += 6
                continue
            if text[i:i+5] == '[ANS]':
                tokens.append(self.token_map['[ANS]'])
                i += 5
                continue

            # Check for two-char operators
            if i < len(text) - 1 and text[i:i+2] == '->':
                tokens.append(self.token_map['>'])  # Use > for implication
                i += 2
                continue

            # Variables A-Z
            if char in self.var_tokens:
                tokens.append(self.var_tokens[char])
            # Operators and special chars
            elif char in self.token_map:
                tokens.append(self.token_map[char])
            else:
                # Unknown char - use hash modulo remaining vocab space
                idx = self.special_start + (ord(char) % (self.vocab_size - self.special_start))
                tokens.append(min(idx, self.vocab_size - 1))

            i += 1

        return tokens

    def _pack_batch(
        self,
        expressions: List[str],
        labels: List[int],
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Pack encoded expressions into tensor batch."""
        batch_size = len(expressions)
        x = torch.full((batch_size, self.seq_len), self.pad_idx, dtype=torch.long, device=device)
        y = torch.tensor(labels, dtype=torch.long, device=device)

        for i, expr in enumerate(expressions):
            tokens = self._encode_text(expr)

            # [BOS] tokens [EOS] [PAD...]
            seq = [self.bos_idx] + tokens + [self.eos_idx]
            seq = seq[:self.seq_len]  # Truncate if needed

            x[i, :len(seq)] = torch.tensor(seq, dtype=torch.long, device=device)

        return x, y

    # =========================================================================
    # Task 1: Implication Chains
    # =========================================================================

    def build_implication_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Generate implication chain reasoning tasks.

        Format: "A:T A->B B->C ? C"
        Label: 1 (True) if query variable follows from chain, 0 (False) otherwise

        Difficulty controlled by self.chain_depth (2-6 recommended).
        """
        expressions = []
        labels = []

        for _ in range(batch_size):
            depth = self.chain_depth
            vars_list = [chr(65 + i) for i in range(depth + 1)]  # A, B, C, ...

            # Build implication chain: A->B B->C ...
            chain_parts = []
            for i in range(depth):
                chain_parts.append(f"{vars_list[i]}->{vars_list[i+1]}")

            # 50% positive: A=T, query last var (should be T)
            # 50% negative: corrupted chain or false premise
            is_positive = random.random() < 0.5

            if is_positive:
                premise = f"{vars_list[0]}:T"
                query_var = vars_list[-1]
                label = 1  # Chain leads to True
            else:
                # Corruption strategies
                corruption = random.choice(['false_premise', 'broken_chain', 'wrong_query'])

                if corruption == 'false_premise':
                    premise = f"{vars_list[0]}:F"
                    query_var = vars_list[-1]
                    label = 0  # Can't derive True from False premise

                elif corruption == 'broken_chain':
                    # Break one link by pointing to a new variable
                    break_idx = random.randint(0, depth - 1)
                    new_var = chr(65 + depth + 1)  # Use variable after the chain
                    chain_parts[break_idx] = f"{vars_list[break_idx]}->{new_var}"
                    premise = f"{vars_list[0]}:T"
                    query_var = vars_list[-1]
                    label = 0  # Chain is broken, can't reach query

                else:  # wrong_query
                    premise = f"{vars_list[0]}:T"
                    # Query a variable not in the chain
                    query_var = chr(65 + random.randint(depth + 2, min(25, depth + 5)))
                    label = 0  # Query var not reachable

            # Assemble expression: "A:T A->B B->C ? C"
            chain_str = " ".join(chain_parts)
            expr = f"{premise} {chain_str} ? {query_var}"

            expressions.append(expr)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    # =========================================================================
    # Task 2: Recursive Parity (Multi-step XOR)
    # =========================================================================

    def build_recursive_parity_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Generate recursive parity (multi-step XOR) tasks.

        Format: "(0^1)^(1^0)=?" with label = correct XOR result
        Tests ability to evaluate nested operations.

        Depth controlled by self.recursive_steps (creates 2^steps leaves).
        """
        expressions = []
        labels = []

        for _ in range(batch_size):
            # Generate base values (0 or 1)
            num_leaves = 2 ** self.recursive_steps
            values = [random.randint(0, 1) for _ in range(num_leaves)]

            # Build nested XOR expression and compute result
            expr, result = self._build_nested_xor(values)

            # The expression asks for the result, label is the correct answer
            full_expr = f"{expr}=?"

            expressions.append(full_expr)
            labels.append(result)

        return self._pack_batch(expressions, labels, device)

    def build_parity_batch_with_trace(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Generate recursive parity tasks WITH embedded reasoning traces.

        Format: "((0^1)^(1^0))=? [TRACE] 0^1=1 1^0=1 1^1=0 [END]"
        Label: correct XOR result (0 or 1)

        The trace shows intermediate XOR steps in evaluation order,
        allowing the model to "read" the reasoning rather than generate it.
        """
        expressions = []
        labels = []

        for _ in range(batch_size):
            num_leaves = 2 ** self.recursive_steps
            values = [random.randint(0, 1) for _ in range(num_leaves)]

            # Build expression with trace
            expr, result, trace_steps = self._build_nested_xor_with_trace(values)

            # Format: expr=? [TRACE] step1 step2 ... [END]
            trace_str = " ".join(trace_steps)
            full_expr = f"{expr}=? [TRACE] {trace_str} [END]"

            expressions.append(full_expr)
            labels.append(result)

        return self._pack_batch(expressions, labels, device)

    def _build_nested_xor(self, values: List[int]) -> Tuple[str, int]:
        """Recursively build XOR expression tree and compute result."""
        if len(values) == 1:
            return str(values[0]), values[0]

        mid = len(values) // 2
        left_expr, left_val = self._build_nested_xor(values[:mid])
        right_expr, right_val = self._build_nested_xor(values[mid:])

        result = left_val ^ right_val
        expr = f"({left_expr}^{right_expr})"
        return expr, result

    def _build_nested_xor_with_trace(self, values: List[int]) -> Tuple[str, int, List[str]]:
        """
        Recursively build XOR tree, compute result, and generate trace steps.

        Returns:
            (expression, result, trace_steps)
            trace_steps contains intermediate XOR computations in evaluation order
        """
        if len(values) == 1:
            return str(values[0]), values[0], []

        mid = len(values) // 2
        left_expr, left_val, left_trace = self._build_nested_xor_with_trace(values[:mid])
        right_expr, right_val, right_trace = self._build_nested_xor_with_trace(values[mid:])

        result = left_val ^ right_val
        expr = f"({left_expr}^{right_expr})"
        step = f"{left_val}^{right_val}={result}"
        trace = left_trace + right_trace + [step]

        return expr, result, trace

    # =========================================================================
    # Task 3: SAT-lite (Simplified Satisfiability)
    # =========================================================================

    def build_sat_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Generate SAT-lite tasks (simplified satisfiability).

        Format: "(A|~B)&(B|C)&(~A|~C) S?"
        Label: 1 if satisfiable, 0 if unsatisfiable

        Complexity controlled by self.num_clauses and self.num_vars.
        """
        expressions = []
        labels = []

        var_names = [chr(65 + i) for i in range(self.num_vars)]

        for _ in range(batch_size):
            clauses = []
            clause_strs = []

            for _ in range(self.num_clauses):
                # Each clause has 2-3 literals
                clause_size = random.randint(2, 3)
                used_vars = random.sample(var_names, min(clause_size, len(var_names)))

                literals = []
                literal_strs = []
                for var in used_vars:
                    negated = random.random() < 0.5
                    if negated:
                        literals.append((var, True))   # (var, is_negated)
                        literal_strs.append(f"~{var}")
                    else:
                        literals.append((var, False))
                        literal_strs.append(var)

                clauses.append(literals)
                clause_strs.append("(" + "|".join(literal_strs) + ")")

            formula_str = "&".join(clause_strs)

            # Check satisfiability via brute force (small formulas)
            is_sat = self._check_sat(clauses, var_names)

            # Format: formula S? (S for SAT query)
            expressions.append(f"{formula_str} S?")
            labels.append(1 if is_sat else 0)

        return self._pack_batch(expressions, labels, device)

    def _check_sat(self, clauses: List[List[Tuple[str, bool]]], var_names: List[str]) -> bool:
        """Brute-force SAT check for small formulas."""
        # Try all 2^n assignments
        for assignment in range(2 ** len(var_names)):
            values = {var: bool((assignment >> i) & 1) for i, var in enumerate(var_names)}

            if self._eval_formula(clauses, values):
                return True
        return False

    def _eval_formula(self, clauses: List[List[Tuple[str, bool]]], values: Dict[str, bool]) -> bool:
        """Evaluate CNF formula under assignment."""
        # All clauses must be satisfied (AND)
        for clause in clauses:
            clause_sat = False
            # At least one literal in clause must be true (OR)
            for var, is_negated in clause:
                val = values.get(var, False)
                if is_negated:
                    val = not val
                if val:
                    clause_sat = True
                    break

            if not clause_sat:
                return False

        return True

    # =========================================================================
    # Task 4: Arithmetic Chains (Multi-step arithmetic with PEMDAS)
    # =========================================================================

    def build_arithmetic_chain_batch(
        self,
        batch_size: int,
        device: torch.device,
        num_ops: int = 2,
        include_trace: bool = True,
        max_value: int = 9,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Generate arithmetic chain tasks with order-of-operations reasoning.

        Format (with trace):
            Input: "3 + 2 * 4 = ? [TRACE] 2 * 4 = 8, 3 + 8 = 11 [END]"
            Label: 11 (as classification bucket)

        Follows PEMDAS: multiplication/division before addition/subtraction.

        Difficulty scales smoothly with num_ops:
            - num_ops=1: "3 + 2" (trivial)
            - num_ops=2: "3 + 2 * 4" (requires PEMDAS)
            - num_ops=3: "3 + 2 * 4 - 1" (multi-step)
            - num_ops=4: "5 + 2 * 3 - 4 + 1" (longer chain)

        Args:
            batch_size: Number of samples
            device: Torch device
            num_ops: Number of operations (controls difficulty)
            include_trace: If True, include reasoning trace in input
            max_value: Maximum operand value (1-9 for single digits)

        Returns:
            (x, y) tensors
            y contains the result value (bucketed into num_classes)
        """
        expressions = []
        labels = []

        for _ in range(batch_size):
            expr, result, trace_steps = self._generate_arithmetic_chain(
                num_ops=num_ops,
                max_value=max_value,
            )

            if include_trace:
                trace_str = ", ".join(trace_steps)
                full_expr = f"{expr} = ? [TRACE] {trace_str} [END]"
            else:
                full_expr = f"{expr} = ?"

            expressions.append(full_expr)
            # Bucket result into classes (handle negative results)
            # Map result to 0-based class index
            labels.append(result)

        return self._pack_arithmetic_batch(expressions, labels, device)

    def _generate_arithmetic_chain(
        self,
        num_ops: int,
        max_value: int = 9,
    ) -> Tuple[str, int, List[str]]:
        """
        Generate an arithmetic expression with proper PEMDAS evaluation trace.

        Returns:
            (expression_string, final_result, trace_steps)

        Example:
            num_ops=2: "3 + 2 * 4" -> 11, ["2 * 4 = 8", "3 + 8 = 11"]
        """
        # Generate operands (single digits for simplicity)
        operands = [random.randint(1, max_value) for _ in range(num_ops + 1)]

        # Generate operators: mix of + - * to require PEMDAS
        # Ensure at least one multiplication if num_ops >= 2
        operators = []
        for i in range(num_ops):
            if num_ops >= 2 and i == 0:
                # Force first op to be + or - so second can be *
                operators.append(random.choice(['+', '-']))
            elif num_ops >= 2 and i == 1:
                # Force at least one * to test PEMDAS
                operators.append('*')
            else:
                operators.append(random.choice(['+', '-', '*']))

        # Shuffle to make it more varied (but keep PEMDAS requirement)
        if num_ops >= 2 and random.random() < 0.5:
            # Sometimes swap positions
            idx = random.randint(0, num_ops - 1)
            operators[idx], operators[(idx + 1) % num_ops] = operators[(idx + 1) % num_ops], operators[idx]

        # Build expression string
        expr_parts = [str(operands[0])]
        for i, op in enumerate(operators):
            expr_parts.append(op)
            expr_parts.append(str(operands[i + 1]))
        expr_str = " ".join(expr_parts)

        # Evaluate with PEMDAS and generate trace
        result, trace_steps = self._eval_arithmetic_with_trace(operands, operators)

        return expr_str, result, trace_steps

    def _eval_arithmetic_with_trace(
        self,
        operands: List[int],
        operators: List[str],
    ) -> Tuple[int, List[str]]:
        """
        Evaluate arithmetic expression following PEMDAS, generating trace steps.

        Returns:
            (result, trace_steps)
        """
        trace_steps = []

        # Copy to avoid modifying originals
        vals = operands.copy()
        ops = operators.copy()

        # Phase 1: Handle all multiplications first (PEMDAS)
        i = 0
        while i < len(ops):
            if ops[i] == '*':
                left = vals[i]
                right = vals[i + 1]
                result = left * right
                trace_steps.append(f"{left} * {right} = {result}")

                # Replace the two operands and operator with the result
                vals = vals[:i] + [result] + vals[i + 2:]
                ops = ops[:i] + ops[i + 1:]
                # Don't increment i - we removed an element
            else:
                i += 1

        # Phase 2: Handle additions and subtractions left-to-right
        while len(ops) > 0:
            op = ops[0]
            left = vals[0]
            right = vals[1]

            if op == '+':
                result = left + right
                trace_steps.append(f"{left} + {right} = {result}")
            else:  # op == '-'
                result = left - right
                trace_steps.append(f"{left} - {right} = {result}")

            # Replace first two operands with result
            vals = [result] + vals[2:]
            ops = ops[1:]

        return vals[0], trace_steps

    def _pack_arithmetic_batch(
        self,
        expressions: List[str],
        labels: List[int],
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Pack arithmetic expressions into tensor batch.

        For arithmetic, we use regression-style labels (actual result value)
        but bucket them into classes for classification.
        """
        batch_size = len(expressions)
        x = torch.full((batch_size, self.seq_len), self.pad_idx, dtype=torch.long, device=device)

        # Bucket results into classes
        # Range for num_ops=2, max_value=9: roughly -72 to 81
        # We'll use 100 classes centered around 0, or map to available num_classes
        # For simplicity, we'll mod by num_classes to get valid class indices
        num_classes = 128  # Reasonable bucket count
        y_raw = torch.tensor(labels, dtype=torch.long, device=device)
        # Shift negative values and mod to get valid class index
        y = ((y_raw + 100) % num_classes).clamp(0, num_classes - 1)

        for i, expr in enumerate(expressions):
            tokens = self._encode_text(expr)
            seq = [self.bos_idx] + tokens + [self.eos_idx]
            seq = seq[:self.seq_len]
            x[i, :len(seq)] = torch.tensor(seq, dtype=torch.long, device=device)

        return x, y

    # =========================================================================
    # Convenience Methods
    # =========================================================================

    def build_batch(
        self,
        batch_size: int,
        device: torch.device,
        task_type: Optional[str] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Build batch for the configured or specified task type.

        Args:
            batch_size: Number of samples
            device: Torch device
            task_type: Override task type (implication, parity, sat)

        Returns:
            (x, y) tensors of shapes (batch_size, seq_len) and (batch_size,)
        """
        task = task_type or self.task_type

        if task == "implication":
            return self.build_implication_batch(batch_size, device)
        elif task == "parity":
            return self.build_recursive_parity_batch(batch_size, device)
        elif task == "parity_cot":
            return self.build_parity_batch_with_trace(batch_size, device)
        elif task == "sat":
            return self.build_sat_batch(batch_size, device)
        elif task == "arithmetic":
            return self.build_arithmetic_chain_batch(batch_size, device, num_ops=2, include_trace=False)
        elif task == "arithmetic_cot":
            return self.build_arithmetic_chain_batch(batch_size, device, num_ops=2, include_trace=True)
        elif task == "arithmetic_easy":
            return self.build_arithmetic_chain_batch(batch_size, device, num_ops=1, include_trace=True)
        elif task == "arithmetic_medium":
            return self.build_arithmetic_chain_batch(batch_size, device, num_ops=2, include_trace=True)
        elif task == "arithmetic_hard":
            return self.build_arithmetic_chain_batch(batch_size, device, num_ops=3, include_trace=True)
        else:
            raise ValueError(
                f"Unknown task type: {task}. "
                f"Use: implication, parity, parity_cot, sat, "
                f"arithmetic, arithmetic_cot, arithmetic_easy, arithmetic_medium, arithmetic_hard"
            )


# =============================================================================
# Standalone Functions (for quick testing / imports)
# =============================================================================

def generate_arithmetic_chain(
    num_ops: int = 2,
    max_value: int = 9,
) -> Tuple[str, int, List[str]]:
    """
    Generate a single arithmetic chain example with PEMDAS trace.

    Args:
        num_ops: Number of operations (1=easy, 2=medium, 3+=hard)
        max_value: Maximum operand value (1-9)

    Returns:
        (expression, result, trace_steps)

    Example:
        >>> expr, result, trace = generate_arithmetic_chain(num_ops=2)
        >>> print(f"Input: {expr}")
        Input: 3 + 2 * 4
        >>> print(f"Trace: {trace}")
        Trace: ['2 * 4 = 8', '3 + 8 = 11']
        >>> print(f"Target: {result}")
        Target: 11
    """
    # Generate operands
    operands = [random.randint(1, max_value) for _ in range(num_ops + 1)]

    # Generate operators with at least one * for PEMDAS testing
    operators = []
    for i in range(num_ops):
        if num_ops >= 2 and i == 0:
            operators.append(random.choice(['+', '-']))
        elif num_ops >= 2 and i == 1:
            operators.append('*')
        else:
            operators.append(random.choice(['+', '-', '*']))

    # Optionally shuffle
    if num_ops >= 2 and random.random() < 0.5:
        idx = random.randint(0, num_ops - 1)
        operators[idx], operators[(idx + 1) % num_ops] = operators[(idx + 1) % num_ops], operators[idx]

    # Build expression string
    expr_parts = [str(operands[0])]
    for i, op in enumerate(operators):
        expr_parts.append(op)
        expr_parts.append(str(operands[i + 1]))
    expr_str = " ".join(expr_parts)

    # Evaluate with trace
    result, trace_steps = _eval_with_trace(operands, operators)

    return expr_str, result, trace_steps


def _eval_with_trace(operands: List[int], operators: List[str]) -> Tuple[int, List[str]]:
    """Evaluate arithmetic with PEMDAS, return (result, trace_steps)."""
    trace_steps = []
    vals = operands.copy()
    ops = operators.copy()

    # Phase 1: Multiplication first
    i = 0
    while i < len(ops):
        if ops[i] == '*':
            left, right = vals[i], vals[i + 1]
            res = left * right
            trace_steps.append(f"{left} * {right} = {res}")
            vals = vals[:i] + [res] + vals[i + 2:]
            ops = ops[:i] + ops[i + 1:]
        else:
            i += 1

    # Phase 2: Addition/subtraction left-to-right
    while ops:
        op, left, right = ops[0], vals[0], vals[1]
        if op == '+':
            res = left + right
            trace_steps.append(f"{left} + {right} = {res}")
        else:
            res = left - right
            trace_steps.append(f"{left} - {right} = {res}")
        vals = [res] + vals[2:]
        ops = ops[1:]

    return vals[0], trace_steps


# Quick test when run directly
if __name__ == "__main__":
    print("=== Arithmetic Chain Generator Test ===\n")

    for difficulty, num_ops in [("Easy", 1), ("Medium", 2), ("Hard", 3)]:
        print(f"--- {difficulty} (num_ops={num_ops}) ---")
        for _ in range(3):
            expr, result, trace = generate_arithmetic_chain(num_ops=num_ops)
            print(f"  Input:  {expr}")
            print(f"  Trace:  {' -> '.join(trace)}")
            print(f"  Target: {result}")
            print()

    print("=== LogicalDataset Batch Test ===\n")
    ds = LogicalDataset(vocab_size=128, seq_len=64, task_type="arithmetic_cot")
    x, y = ds.build_batch(4, torch.device("cpu"))
    print(f"Batch shape: x={x.shape}, y={y.shape}")
    print(f"Labels: {y.tolist()}")

"""
Math CoT Dataset Loader - OpenMathInstruct-2 and similar for Phase 13.

Loads math problems with step-by-step Chain-of-Thought solutions for training
SparseStack on mathematical reasoning.

Sources:
1. OpenMathInstruct-2 (Nvidia) - 14M math samples with CoT traces
2. GSM8K - Grade school math with reasoning steps
3. Synthetic fallback - Generated arithmetic chains when HF unavailable

The pedagogical focus is on TEACHING mathematical reasoning step-by-step,
not just testing final answers.
"""

import random
import re
import torch
from typing import List, Dict, Tuple, Optional, Iterator
from pathlib import Path

# Try to import HuggingFace datasets
try:
    from datasets import load_dataset, Dataset
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False


class MathCoTDataset:
    """
    Math Chain-of-Thought dataset for SparseStack training.

    Provides math problems with step-by-step solutions.
    Compatible with the LogicalDataset interface (same build_batch API).
    """

    def __init__(
        self,
        vocab_size: int,
        seq_len: int,
        task_type: str = "openmath",
        pad_idx: int = 0,
        bos_idx: int = 1,
        sep_idx: int = 2,
        eos_idx: int = 3,
        use_hf: bool = True,
        cache_dir: Optional[str] = None,
        max_samples: int = 10000,
        difficulty: str = "easy",
    ):
        self.vocab_size = vocab_size
        self.seq_len = seq_len
        self.task_type = task_type
        self.pad_idx = pad_idx
        self.bos_idx = bos_idx
        self.sep_idx = sep_idx
        self.eos_idx = eos_idx
        self.use_hf = use_hf and HF_AVAILABLE
        self.cache_dir = cache_dir or str(Path.home() / ".cache" / "math_cot")
        self.max_samples = max_samples
        self.difficulty = difficulty
        self.include_trace = True

        # Build character-level token map
        self._build_token_map()

        # Dataset storage
        self._hf_data: List[Dict] = []
        if self.use_hf:
            self._load_hf_dataset()

    def _build_token_map(self) -> None:
        """Build character-level token map for math expressions."""
        self.special_start = 4

        self.char_to_idx = {}
        idx = self.special_start

        # Lowercase letters
        for c in 'abcdefghijklmnopqrstuvwxyz':
            self.char_to_idx[c] = idx
            idx += 1

        # Uppercase letters
        for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
            self.char_to_idx[c] = idx
            idx += 1

        # Digits
        for c in '0123456789':
            self.char_to_idx[c] = idx
            idx += 1

        # Math operators and punctuation
        for c in ' .,;:!?\'"()-[]{}=+*/<>^%$@#&|\\~`':
            self.char_to_idx[c] = idx
            idx += 1

        # Newline for step separation
        self.char_to_idx['\n'] = idx
        idx += 1

    def _encode_text(self, text: str) -> List[int]:
        """Encode text to token indices."""
        tokens = []
        for char in text:
            if char in self.char_to_idx:
                tokens.append(self.char_to_idx[char])
            else:
                tokens.append(self.char_to_idx.get(' ', self.special_start))
        return tokens

    def _pack_batch(
        self,
        expressions: List[str],
        labels: List[int],
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Pack encoded expressions into tensor batch."""
        batch_size = len(expressions)
        x = torch.full((batch_size, self.seq_len), self.pad_idx, dtype=torch.long, device=device)
        y = torch.tensor(labels, dtype=torch.long, device=device)

        for i, expr in enumerate(expressions):
            tokens = self._encode_text(expr)
            seq = [self.bos_idx] + tokens + [self.eos_idx]
            seq = seq[:self.seq_len]
            x[i, :len(seq)] = torch.tensor(seq, dtype=torch.long, device=device)

        return x, y

    def _load_hf_dataset(self) -> None:
        """Load math dataset from HuggingFace."""
        try:
            # Try OpenMathInstruct-2 first
            print("[MathCoT] Attempting to load nvidia/OpenMathInstruct-2...")
            ds = load_dataset(
                "nvidia/OpenMathInstruct-2",
                split="train",
                cache_dir=self.cache_dir,
                streaming=True  # Use streaming for large dataset
            )

            # Take a subset
            count = 0
            for item in ds:
                if count >= self.max_samples:
                    break
                # Extract problem and solution
                problem = item.get("problem", item.get("question", ""))
                solution = item.get("generated_solution", item.get("solution", ""))
                answer = item.get("expected_answer", "")

                if problem and solution:
                    self._hf_data.append({
                        "problem": problem,
                        "solution": solution,
                        "answer": answer
                    })
                    count += 1

            print(f"[MathCoT] Loaded {len(self._hf_data)} samples from OpenMathInstruct-2")

        except Exception as e1:
            print(f"[MathCoT] OpenMathInstruct-2 failed: {e1}")
            try:
                # Fallback to GSM8K
                print("[MathCoT] Trying gsm8k...")
                ds = load_dataset("gsm8k", "main", split="train", cache_dir=self.cache_dir)

                for i, item in enumerate(ds):
                    if i >= self.max_samples:
                        break
                    self._hf_data.append({
                        "problem": item["question"],
                        "solution": item["answer"],
                        "answer": self._extract_gsm8k_answer(item["answer"])
                    })

                print(f"[MathCoT] Loaded {len(self._hf_data)} samples from GSM8K")

            except Exception as e2:
                print(f"[MathCoT] GSM8K also failed: {e2}")
                print("[MathCoT] Falling back to synthetic generation")

    def _extract_gsm8k_answer(self, answer_text: str) -> str:
        """Extract final numerical answer from GSM8K format."""
        # GSM8K answers end with #### <number>
        match = re.search(r'####\s*(\d+)', answer_text)
        if match:
            return match.group(1)
        return ""

    # =========================================================================
    # Synthetic Generation (fallback when HF unavailable)
    # =========================================================================

    def _generate_arithmetic_problem(self, num_ops: int = 2) -> Tuple[str, str, int]:
        """
        Generate synthetic arithmetic problem with step-by-step solution.

        Returns: (problem_text, solution_text, answer_int)
        """
        # Generate operands
        if self.difficulty == "easy":
            max_val = 10
        elif self.difficulty == "medium":
            max_val = 50
        else:
            max_val = 100

        operands = [random.randint(1, max_val) for _ in range(num_ops + 1)]
        operators = [random.choice(['+', '-', '*']) for _ in range(num_ops)]

        # Build expression string
        expr_parts = [str(operands[0])]
        for i, op in enumerate(operators):
            expr_parts.append(op)
            expr_parts.append(str(operands[i + 1]))
        expression = ' '.join(expr_parts)

        # Build solution steps
        problem = f"Calculate: {expression}"
        steps = []

        # Evaluate with PEMDAS (multiplication first)
        current_ops = list(operands)
        current_opers = list(operators)

        # First pass: handle multiplication
        i = 0
        while i < len(current_opers):
            if current_opers[i] == '*':
                result = current_ops[i] * current_ops[i + 1]
                steps.append(f"Step: {current_ops[i]} * {current_ops[i + 1]} = {result}")
                current_ops[i] = result
                current_ops.pop(i + 1)
                current_opers.pop(i)
            else:
                i += 1

        # Second pass: handle addition/subtraction left to right
        while current_opers:
            op = current_opers.pop(0)
            a = current_ops.pop(0)
            b = current_ops[0]
            if op == '+':
                result = a + b
                steps.append(f"Step: {a} + {b} = {result}")
            else:
                result = a - b
                steps.append(f"Step: {a} - {b} = {result}")
            current_ops[0] = result

        answer = current_ops[0]
        solution = '\n'.join(steps) + f"\nAnswer: {answer}"

        return problem, solution, answer

    def _generate_word_problem(self) -> Tuple[str, str, int]:
        """
        Generate simple word problem with solution.

        Returns: (problem_text, solution_text, answer_int)
        """
        templates = [
            {
                "pattern": "{name} has {a} {items}. {name2} gives {name} {b} more {items}. How many {items} does {name} have now?",
                "solve": lambda a, b: a + b,
                "trace": "{name} started with {a} {items}.\n{name2} gave {b} more.\n{a} + {b} = {result}\nAnswer: {result}"
            },
            {
                "pattern": "{name} has {a} {items}. {name} uses {b} {items}. How many {items} does {name} have left?",
                "solve": lambda a, b: a - b,
                "trace": "{name} started with {a} {items}.\n{name} used {b}.\n{a} - {b} = {result}\nAnswer: {result}"
            },
            {
                "pattern": "{name} buys {a} boxes. Each box has {b} {items}. How many {items} does {name} have in total?",
                "solve": lambda a, b: a * b,
                "trace": "{name} has {a} boxes.\nEach box has {b} {items}.\n{a} * {b} = {result}\nAnswer: {result}"
            },
        ]

        names = ["Alice", "Bob", "Charlie", "Diana", "Eve", "Frank"]
        items = ["apples", "oranges", "books", "pencils", "marbles", "cookies", "cards", "toys"]

        template = random.choice(templates)
        name = random.choice(names)
        name2 = random.choice([n for n in names if n != name])
        item = random.choice(items)

        if self.difficulty == "easy":
            a, b = random.randint(5, 20), random.randint(1, 10)
        elif self.difficulty == "medium":
            a, b = random.randint(10, 50), random.randint(5, 30)
        else:
            a, b = random.randint(20, 100), random.randint(10, 50)

        # Ensure subtraction doesn't go negative
        if "uses" in template["pattern"] or "gives" in template["pattern"]:
            if b > a:
                a, b = b, a

        result = template["solve"](a, b)

        problem = template["pattern"].format(name=name, name2=name2, a=a, b=b, items=item)
        solution = template["trace"].format(name=name, name2=name2, a=a, b=b, items=item, result=result)

        return problem, solution, result

    # =========================================================================
    # Batch Building Methods
    # =========================================================================

    def build_openmath_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Build batch from OpenMathInstruct-2 or fallback to synthetic."""
        expressions = []
        labels = []

        for _ in range(batch_size):
            if self._hf_data:
                # Use HuggingFace data
                item = random.choice(self._hf_data)
                text = f"{item['problem']}\n[SOLUTION]\n{item['solution']}"

                # Extract numerical answer for classification
                # For simplicity, classify by answer parity (even=0, odd=1)
                try:
                    answer = int(re.search(r'-?\d+', item['answer'] or "0").group())
                    label = answer % 2
                except:
                    label = random.randint(0, 1)
            else:
                # Fallback to synthetic
                problem, solution, answer = self._generate_word_problem()
                text = f"{problem}\n[SOLUTION]\n{solution}"
                label = answer % 2  # Parity classification

            expressions.append(text)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_arithmetic_batch(
        self,
        batch_size: int,
        device: torch.device,
        num_ops: int = 2
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Build batch of synthetic arithmetic problems."""
        expressions = []
        labels = []

        for _ in range(batch_size):
            problem, solution, answer = self._generate_arithmetic_problem(num_ops)
            text = f"{problem}\n[SOLUTION]\n{solution}"
            label = answer % 2
            expressions.append(text)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_word_problem_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Build batch of word problems."""
        expressions = []
        labels = []

        for _ in range(batch_size):
            problem, solution, answer = self._generate_word_problem()
            text = f"{problem}\n[SOLUTION]\n{solution}"
            label = answer % 2
            expressions.append(text)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def _format_verify_text(self, problem: str, solution: str, proposed: int) -> str:
        if self.include_trace:
            return f"{problem}\n[TRACE]\n{solution}\n[VERIFY] {proposed}"
        return f"{problem}\n[VERIFY] {proposed}"

    # =========================================================================
    # Phase 14: Answer Verification Methods
    # =========================================================================

    def build_verify_arithmetic_batch(
        self,
        batch_size: int,
        device: torch.device,
        num_ops: int = 2
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Build batch for answer verification task.

        Task: Given (problem, trace, proposed_answer), classify correct/incorrect.
        This tests true mathematical reasoning, not just pattern matching.
        """
        expressions = []
        labels = []

        for _ in range(batch_size):
            problem, solution, correct_answer = self._generate_arithmetic_problem(num_ops)

            # 50% correct, 50% incorrect
            if random.random() < 0.5:
                # Correct answer
                proposed = correct_answer
                label = 1  # Correct
            else:
                # Wrong answer (perturb by small amount)
                perturbation = random.choice([-2, -1, 1, 2, 3, -3])
                proposed = correct_answer + perturbation
                label = 0  # Incorrect

            # Format: problem + trace + proposed answer for verification
            text = self._format_verify_text(problem, solution, proposed)
            expressions.append(text)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_verify_word_problem_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Build batch of word problems for answer verification."""
        expressions = []
        labels = []

        for _ in range(batch_size):
            problem, solution, correct_answer = self._generate_word_problem()

            # 50% correct, 50% incorrect
            if random.random() < 0.5:
                proposed = correct_answer
                label = 1  # Correct
            else:
                perturbation = random.choice([-2, -1, 1, 2, 3, -3])
                proposed = correct_answer + perturbation
                label = 0  # Incorrect

            text = self._format_verify_text(problem, solution, proposed)
            expressions.append(text)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_verify_openmath_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Build batch from OpenMathInstruct-2 for answer verification."""
        expressions = []
        labels = []

        for _ in range(batch_size):
            if self._hf_data:
                item = random.choice(self._hf_data)
                problem = item['problem']
                solution = item['solution']

                try:
                    correct_answer = int(re.search(r'-?\d+', item['answer'] or "0").group())
                except:
                    correct_answer = 0

                # 50% correct, 50% incorrect
                if random.random() < 0.5:
                    proposed = correct_answer
                    label = 1
                else:
                    perturbation = random.choice([-2, -1, 1, 2, 3, -3])
                    proposed = correct_answer + perturbation
                    label = 0

                text = self._format_verify_text(problem, solution, proposed)
            else:
                # Fallback to synthetic word problems
                problem, solution, correct_answer = self._generate_word_problem()

                if random.random() < 0.5:
                    proposed = correct_answer
                    label = 1
                else:
                    perturbation = random.choice([-2, -1, 1, 2, 3, -3])
                    proposed = correct_answer + perturbation
                    label = 0

                text = self._format_verify_text(problem, solution, proposed)

            expressions.append(text)
            labels.append(label)

        return self._pack_batch(expressions, labels, device)

    def build_verify_mixed_batch(
        self,
        batch_size: int,
        device: torch.device
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Build mixed verification batch (word problems + arithmetic)."""
        half = batch_size // 2
        x1, y1 = self.build_verify_word_problem_batch(half, device)
        x2, y2 = self.build_verify_arithmetic_batch(batch_size - half, device)
        return torch.cat([x1, x2], dim=0), torch.cat([y1, y2], dim=0)

    def build_batch(
        self,
        batch_size: int,
        device: torch.device,
        task_type: Optional[str] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Build batch for the configured or specified task type.

        Args:
            batch_size: Number of samples
            device: Torch device
            task_type: Override task type

        Returns:
            (x, y) tensors
        """
        task = task_type or self.task_type

        # Legacy parity-based tasks
        if task == "openmath":
            return self.build_openmath_batch(batch_size, device)
        elif task == "arithmetic":
            return self.build_arithmetic_batch(batch_size, device, num_ops=2)
        elif task == "arithmetic_easy":
            return self.build_arithmetic_batch(batch_size, device, num_ops=1)
        elif task == "arithmetic_hard":
            return self.build_arithmetic_batch(batch_size, device, num_ops=3)
        elif task == "word_problem":
            return self.build_word_problem_batch(batch_size, device)
        elif task == "mixed":
            half = batch_size // 2
            x1, y1 = self.build_word_problem_batch(half, device)
            x2, y2 = self.build_arithmetic_batch(batch_size - half, device)
            return torch.cat([x1, x2], dim=0), torch.cat([y1, y2], dim=0)

        # Phase 14: Answer verification tasks (correct/incorrect classification)
        elif task == "verify":
            return self.build_verify_openmath_batch(batch_size, device)
        elif task == "verify_arithmetic":
            return self.build_verify_arithmetic_batch(batch_size, device, num_ops=2)
        elif task == "verify_arithmetic_easy":
            return self.build_verify_arithmetic_batch(batch_size, device, num_ops=1)
        elif task == "verify_arithmetic_hard":
            return self.build_verify_arithmetic_batch(batch_size, device, num_ops=3)
        elif task == "verify_word_problem":
            return self.build_verify_word_problem_batch(batch_size, device)
        elif task == "verify_mixed":
            return self.build_verify_mixed_batch(batch_size, device)
        else:
            raise ValueError(
                f"Unknown MathCoT task type: {task}. "
                f"Use: openmath, arithmetic, arithmetic_easy/hard, word_problem, mixed, "
                f"verify, verify_arithmetic, verify_arithmetic_easy/hard, verify_word_problem, verify_mixed"
            )


# =============================================================================
# Standalone Functions
# =============================================================================

def test_math_cot_dataset():
    """Quick test of MathCoT dataset generation."""
    import torch

    print("=" * 60)
    print("MathCoT Dataset Test")
    print("=" * 60)

    ds = MathCoTDataset(
        vocab_size=128,
        seq_len=512,
        task_type="mixed",
        difficulty="easy",
        max_samples=100
    )

    device = torch.device("cpu")

    # Test synthetic generation
    print("\n--- Arithmetic Problem ---")
    for _ in range(2):
        problem, solution, answer = ds._generate_arithmetic_problem(num_ops=2)
        print(f"Problem: {problem}")
        print(f"Solution: {solution}")
        print(f"Answer: {answer}")
        print()

    print("\n--- Word Problem ---")
    for _ in range(2):
        problem, solution, answer = ds._generate_word_problem()
        print(f"Problem: {problem}")
        print(f"Solution: {solution}")
        print(f"Answer: {answer}")
        print()

    # Test batch generation
    print("\n--- Batch Test ---")
    x, y = ds.build_batch(4, device, "mixed")
    print(f"Input shape: {x.shape}")
    print(f"Labels shape: {y.shape}")
    print(f"Labels: {y.tolist()}")

    # Show one decoded sample
    print("\n--- Sample Decode ---")
    idx_to_char = {v: k for k, v in ds.char_to_idx.items()}
    sample = x[0].tolist()
    decoded = ''.join(idx_to_char.get(t, '?') for t in sample if t > 3)[:200]
    print(f"Decoded: {decoded}...")

    print("\n" + "=" * 60)
    print("MathCoT Dataset Test Complete")
    print("=" * 60)


if __name__ == "__main__":
    test_math_cot_dataset()

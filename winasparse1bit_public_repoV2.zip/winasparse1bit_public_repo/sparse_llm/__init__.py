"""
WINASPARSE1BIT sparse-LLM research package.

This package groups the components used to prototype sparse, low-bit
transformer ideas. Modules stay tiny and explicit so individual pieces
(quantizers, sparse layers, transformer blocks, datasets) can be swapped or
extended without dragging in unrelated code.

Public API:
    LowBitLinear, ternary_quantize    -- 1.58-bit ternary quantization
    WINA_MLP                          -- Weight-Informed Neuron Activation MLP
    ToyTransformerBlock,
    SparseTransformer                 -- classification model (Phases 1-14)
    CausalSparseTransformer           -- causal LM model (Phase 15+)
    HybridStack                       -- Sparse-Dense-Sparse hybrid (Phase 10 Track 3)
"""

from .layers import LowBitLinear, ternary_quantize
from .mlp import WINA_MLP
from .transformer import ToyTransformerBlock, SparseTransformer
from .causal_transformer import CausalSparseTransformer
from .hybrid import HybridStack

__all__ = [
    "LowBitLinear",
    "ternary_quantize",
    "WINA_MLP",
    "ToyTransformerBlock",
    "SparseTransformer",
    "CausalSparseTransformer",
    "HybridStack",
]

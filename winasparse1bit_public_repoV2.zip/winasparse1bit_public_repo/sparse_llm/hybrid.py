"""
Hybrid Bridge Architecture for Phase 10 Track 3.

Implements a Sparse-Dense-Sparse "sandwich" pattern where:
- Sparse layers handle efficient feature extraction
- Dense layers provide deep reasoning capacity
- Final sparse layers compress back to efficient representation

This architecture tests whether adding dense reasoning improves
performance on relational datasets while maintaining efficiency.
"""

from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import torch
import torch.nn as nn

from .mlp import WINA_MLP


class DenseTransformerBlock(nn.Module):
    """
    Dense transformer block without sparsity constraints.
    Used in the middle of hybrid architecture for deep reasoning.
    """

    def __init__(
        self,
        dim: int,
        num_heads: int,
        mlp_hidden_dim: int,
    ):
        super().__init__()
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True)
        self.norm1 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, mlp_hidden_dim),
            nn.GELU(),
            nn.Linear(mlp_hidden_dim, dim),
        )
        self.norm2 = nn.LayerNorm(dim)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, float]]:
        """Forward pass with dense computation"""
        attn_out, _ = self.attn(x, x, x, need_weights=False)
        x = self.norm1(x + attn_out)
        mlp_out = self.mlp(x)
        x = self.norm2(x + mlp_out)
        
        # Return empty log for compatibility
        log = {
            "conn_sparsity": 0.0,  # Dense = no sparsity
            "act_sparsity": 0.0,
            "prec_sparsity": 0.0,
        }
        return x, log


class SparseTransformerBlock(nn.Module):
    """
    Sparse transformer block with WINA gating.
    Used at beginning and end of hybrid architecture for efficiency.
    """

    def __init__(
        self,
        dim: int,
        num_heads: int,
        mlp_hidden_dim: int,
        quant_threshold: float = 0.05,
        gate_fc1: bool = True,
        gate_fc2: bool = False,
        gate_score_mode: str = "heuristic_v0",
    ):
        super().__init__()
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True)
        self.norm1 = nn.LayerNorm(dim)
        self.mlp = WINA_MLP(
            dim,
            mlp_hidden_dim,
            dim,
            quant_threshold=quant_threshold,
            gate_fc1=gate_fc1,
            gate_fc2=gate_fc2,
            gate_score_mode=gate_score_mode,
        )
        self.norm2 = nn.LayerNorm(dim)

    def forward(
        self,
        x: torch.Tensor,
        mode: str = "dense",
        neuron_threshold: float = 0.1,
        gate_mode: str = "threshold",
        neuron_topk_fraction: float = 0.5,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """Forward pass with sparse computation"""
        attn_out, _ = self.attn(x, x, x, need_weights=False)
        x = self.norm1(x + attn_out)
        b, s, d = x.shape
        x_flat = x.reshape(b * s, d)
        mlp_out_flat, mlp_log = self.mlp(
            x_flat,
            mode=mode,
            neuron_threshold=neuron_threshold,
            gate_mode=gate_mode,
            neuron_topk_fraction=neuron_topk_fraction,
        )
        mlp_out = mlp_out_flat.reshape(b, s, d)
        x = self.norm2(x + mlp_out)
        return x, mlp_log


class HybridStack(nn.Module):
    """
    Hybrid Sparse-Dense-Sparse architecture for Phase 10 Track 3.
    
    Architecture pattern:
    - Sparse layers (beginning): Efficient feature extraction
    - Dense layers (middle): Deep reasoning without constraints
    - Sparse layers (end): Efficient compression
    
    Example configuration for dim=256:
    - 1 sparse block (input processing)
    - 2 dense blocks (reasoning)
    - 1 sparse block (output compression)
    
    Args:
        vocab_size: Size of vocabulary
        dim: Model dimension
        num_heads: Number of attention heads
        mlp_hidden_dim: Hidden dimension for MLP layers
        num_classes: Number of output classes
        seq_len: Maximum sequence length
        num_sparse_blocks: Number of sparse blocks at start/end
        num_dense_blocks: Number of dense blocks in middle
        quant_threshold: Quantization threshold for sparse blocks
        gate_fc1: Enable gating for first FC layer
        gate_fc2: Enable gating for second FC layer
        gate_score_mode: Gating score mode
    """

    def __init__(
        self,
        vocab_size: int,
        dim: int,
        num_heads: int,
        mlp_hidden_dim: int,
        num_classes: int,
        seq_len: int,
        num_sparse_blocks: int = 1,
        num_dense_blocks: int = 2,
        quant_threshold: float = 0.05,
        gate_fc1: bool = True,
        gate_fc2: bool = False,
        gate_score_mode: str = "heuristic_v0",
    ):
        super().__init__()
        self.dim = dim
        self.seq_len = seq_len
        self.num_sparse_blocks = num_sparse_blocks
        self.num_dense_blocks = num_dense_blocks
        
        # Embeddings
        self.token_emb = nn.Embedding(vocab_size, dim)
        self.pos_emb = nn.Parameter(torch.randn(1, seq_len, dim))
        
        # Sparse blocks (beginning)
        self.sparse_blocks_start = nn.ModuleList([
            SparseTransformerBlock(
                dim,
                num_heads,
                mlp_hidden_dim,
                quant_threshold=quant_threshold,
                gate_fc1=gate_fc1,
                gate_fc2=gate_fc2,
                gate_score_mode=gate_score_mode,
            )
            for _ in range(num_sparse_blocks)
        ])
        
        # Dense blocks (middle - reasoning)
        self.dense_blocks = nn.ModuleList([
            DenseTransformerBlock(
                dim,
                num_heads,
                mlp_hidden_dim,
            )
            for _ in range(num_dense_blocks)
        ])
        
        # Sparse blocks (end)
        self.sparse_blocks_end = nn.ModuleList([
            SparseTransformerBlock(
                dim,
                num_heads,
                mlp_hidden_dim,
                quant_threshold=quant_threshold,
                gate_fc1=gate_fc1,
                gate_fc2=gate_fc2,
                gate_score_mode=gate_score_mode,
            )
            for _ in range(num_sparse_blocks)
        ])
        
        # Classification head
        self.head = nn.Linear(dim, num_classes)

    def forward(
        self,
        x_idx: torch.Tensor,
        mode: str = "dense",
        neuron_threshold: float = 0.1,
        gate_mode: str = "threshold",
        neuron_topk_fraction: float = 0.5,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        """
        Forward pass through hybrid architecture.
        
        Flow:
        1. Embedding
        2. Sparse blocks (efficient feature extraction)
        3. Dense blocks (deep reasoning)
        4. Sparse blocks (efficient compression)
        5. Classification head
        """
        b, s = x_idx.shape
        if s > self.seq_len:
            raise ValueError(f"Sequence length {s} exceeds model limit {self.seq_len}")
        
        # Embedding
        x = self.token_emb(x_idx) + self.pos_emb[:, :s, :]
        
        block_logs: List[Dict[str, float]] = []
        
        # Phase 1: Sparse feature extraction
        for block in self.sparse_blocks_start:
            x, block_log = block(
                x,
                mode=mode,
                neuron_threshold=neuron_threshold,
                gate_mode=gate_mode,
                neuron_topk_fraction=neuron_topk_fraction,
            )
            block_logs.append(block_log)
        
        # Phase 2: Dense reasoning
        for block in self.dense_blocks:
            x, block_log = block(x)
            block_logs.append(block_log)
        
        # Phase 3: Sparse compression
        for block in self.sparse_blocks_end:
            x, block_log = block(
                x,
                mode=mode,
                neuron_threshold=neuron_threshold,
                gate_mode=gate_mode,
                neuron_topk_fraction=neuron_topk_fraction,
            )
            block_logs.append(block_log)
        
        # Classification
        pooled = x.mean(dim=1)
        logits = self.head(pooled)
        
        # Aggregate logs
        combined_log = self._aggregate_block_logs(block_logs)
        combined_log["blocks"] = block_logs
        combined_log["num_sparse_blocks"] = float(self.num_sparse_blocks * 2)
        combined_log["num_dense_blocks"] = float(self.num_dense_blocks)
        
        return logits, combined_log

    @staticmethod
    def _aggregate_block_logs(block_logs: List[Dict[str, float]]) -> Dict[str, float]:
        """Aggregate logs from all blocks"""
        if not block_logs:
            return {}
        
        agg = dict(block_logs[-1])
        agg["num_blocks"] = float(len(block_logs))
        
        # Sum gating diffs across sparse blocks only
        for field in ("gating_l2_diff", "gating_l2_diff_fc1", "gating_l2_diff_fc2"):
            agg[field] = sum(log.get(field, 0.0) for log in block_logs)
        
        # Average sparsity across all blocks
        conn_sparsities = [log.get("conn_sparsity", 0.0) for log in block_logs]
        act_sparsities = [log.get("act_sparsity", 0.0) for log in block_logs]
        prec_sparsities = [log.get("prec_sparsity", 0.0) for log in block_logs]
        
        agg["conn_sparsity"] = sum(conn_sparsities) / len(conn_sparsities) if conn_sparsities else 0.0
        agg["act_sparsity"] = sum(act_sparsities) / len(act_sparsities) if act_sparsities else 0.0
        agg["prec_sparsity"] = sum(prec_sparsities) / len(prec_sparsities) if prec_sparsities else 0.0
        
        return agg

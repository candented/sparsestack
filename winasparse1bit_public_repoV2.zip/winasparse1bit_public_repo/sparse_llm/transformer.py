from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import torch
import torch.nn as nn

from .mlp import WINA_MLP
from .hybrid import HybridStack  # Track 3: Hybrid Bridge Architecture


class ToyTransformerBlock(nn.Module):
    """
    Minimal transformer block with dense attention and sparse MLP.
    """

    def __init__(
        self,
        dim: int,
        num_heads: int,
        mlp_hidden_dim: int,
        quant_threshold: float = 0.05,
        gate_fc1: bool = True,
        gate_fc2: bool = False,
        gate_score_mode: str = "heuristic_v0",
    ):
        super().__init__()
        self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True)
        self.norm1 = nn.LayerNorm(dim)
        self.mlp = WINA_MLP(
            dim,
            mlp_hidden_dim,
            dim,
            quant_threshold=quant_threshold,
            gate_fc1=gate_fc1,
            gate_fc2=gate_fc2,
            gate_score_mode=gate_score_mode,
        )
        self.norm2 = nn.LayerNorm(dim)

    def forward(
        self,
        x: torch.Tensor,
        mode: str = "dense",
        neuron_threshold: float = 0.1,
        gate_mode: str = "threshold",
        neuron_topk_fraction: float = 0.5,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        attn_out, _ = self.attn(x, x, x, need_weights=False)
        x = self.norm1(x + attn_out)
        b, s, d = x.shape
        x_flat = x.reshape(b * s, d)
        mlp_out_flat, mlp_log = self.mlp(
            x_flat,
            mode=mode,
            neuron_threshold=neuron_threshold,
            gate_mode=gate_mode,
            neuron_topk_fraction=neuron_topk_fraction,
        )
        mlp_out = mlp_out_flat.reshape(b, s, d)
        x = self.norm2(x + mlp_out)
        return x, mlp_log


class SparseTransformer(nn.Module):
    """
    Sequence classifier built from a stack of ToyTransformerBlocks.
    """

    def __init__(
        self,
        vocab_size: int,
        dim: int,
        num_heads: int,
        mlp_hidden_dim: int,
        num_classes: int,
        seq_len: int,
        quant_threshold: float = 0.05,
        gate_fc1: bool = True,
        gate_fc2: bool = False,
        gate_score_mode: str = "heuristic_v0",
        num_blocks: int = 1,
    ):
        super().__init__()
        if num_blocks <= 0:
            raise ValueError("num_blocks must be positive")
        self.dim = dim
        self.seq_len = seq_len
        self.token_emb = nn.Embedding(vocab_size, dim)
        self.pos_emb = nn.Parameter(torch.randn(1, seq_len, dim))
        self.blocks = nn.ModuleList(
            [
                ToyTransformerBlock(
                    dim,
                    num_heads,
                    mlp_hidden_dim,
                    quant_threshold=quant_threshold,
                    gate_fc1=gate_fc1,
                    gate_fc2=gate_fc2,
                    gate_score_mode=gate_score_mode,
                )
                for _ in range(num_blocks)
            ]
        )
        self.head = nn.Linear(dim, num_classes)

    def _expand_topk_fraction(self, neuron_topk_fraction: float | Sequence[float] | None) -> List[float] | None:
        if neuron_topk_fraction is None:
            return None
        if isinstance(neuron_topk_fraction, (list, tuple)):
            if len(neuron_topk_fraction) != len(self.blocks):
                raise ValueError("Per-block neuron_topk_fraction length mismatch")
            return [float(val) for val in neuron_topk_fraction]
        return [float(neuron_topk_fraction) for _ in range(len(self.blocks))]

    def forward(
        self,
        x_idx: torch.Tensor,
        mode: str = "dense",
        neuron_threshold: float = 0.1,
        gate_mode: str = "threshold",
        neuron_topk_fraction: float = 0.5,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        b, s = x_idx.shape
        if s > self.seq_len:
            raise ValueError(f"Sequence length {s} exceeds model limit {self.seq_len}")
        x = self.token_emb(x_idx) + self.pos_emb[:, :s, :]
        block_logs: List[Dict[str, float]] = []
        topk_schedule = self._expand_topk_fraction(neuron_topk_fraction)
        for idx, block in enumerate(self.blocks):
            current_topk = None if topk_schedule is None else topk_schedule[idx]
            x, block_log = block(
                x,
                mode=mode,
                neuron_threshold=neuron_threshold,
                gate_mode=gate_mode,
                neuron_topk_fraction=current_topk if current_topk is not None else neuron_topk_fraction,
            )
            block_logs.append(block_log)
        pooled = x.mean(dim=1)
        logits = self.head(pooled)
        combined_log = self._aggregate_block_logs(block_logs)
        combined_log["blocks"] = block_logs
        return logits, combined_log

    @staticmethod
    def _aggregate_block_logs(block_logs: List[Dict[str, float]]) -> Dict[str, float]:
        if not block_logs:
            return {}
        agg = dict(block_logs[-1])
        agg["num_blocks"] = float(len(block_logs))
        for field in ("gating_l2_diff", "gating_l2_diff_fc1", "gating_l2_diff_fc2"):
            agg[field] = sum(log.get(field, 0.0) for log in block_logs)
        return agg

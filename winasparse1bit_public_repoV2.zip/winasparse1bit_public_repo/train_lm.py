"""
Phase 15: Supervised Language Model Training (Multi-GPU DDP).

Trains CausalSparseTransformer on next-token prediction with:
- PyTorch DDP for multi-GPU data parallelism
- AdamW optimizer (weight_decay=0.1)
- Cosine LR schedule with linear warmup
- BF16 mixed precision
- Gradient accumulation
- Periodic evaluation (perplexity)
- Checkpoint saving with resume support

Completely separate from main.py (RL classification pipeline).

Usage:
    # Single GPU:
    python train_lm.py preset=phase15b_tinystories_full

    # Multi-GPU (3x RTX 5090):
    torchrun --nproc_per_node=3 train_lm.py preset=phase15b_tinystories_full

    # Resume from checkpoint:
    torchrun --nproc_per_node=3 train_lm.py preset=phase15c_openwebtext --resume checkpoints/phase15/phase15c_openwebtext/20260214_120000/step_20000

    # CLI overrides:
    torchrun --nproc_per_node=3 train_lm.py preset=phase15c_openwebtext training.max_steps=50000
"""

from __future__ import annotations

import os
import sys
import math
import json
import time
import random
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional
from contextlib import nullcontext

import numpy as np
import torch
import torch.nn.functional as F
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data.distributed import DistributedSampler
import yaml

from config.loader import load_config
from sparse_llm.causal_transformer import CausalSparseTransformer
from sparse_llm.datasets.lm_dataset import build_lm_dataloader, ChunkedLMDataset, StreamingLMDataset


# =============================================================================
# DDP Utilities
# =============================================================================

def setup_ddp():
    """Initialize DDP if launched via torchrun, otherwise return single-GPU info."""
    if "RANK" in os.environ:
        dist.init_process_group(backend="nccl")
        rank = dist.get_rank()
        local_rank = int(os.environ.get("LOCAL_RANK", 0))
        world_size = dist.get_world_size()
        torch.cuda.set_device(local_rank)
        return rank, local_rank, world_size
    else:
        return 0, 0, 1


def cleanup_ddp():
    """Clean up DDP process group."""
    if dist.is_initialized():
        dist.destroy_process_group()


def is_main_process(rank: int) -> bool:
    return rank == 0


def log_print(rank: int, msg: str):
    """Only print from rank 0."""
    if is_main_process(rank):
        print(msg, flush=True)


# =============================================================================
# Config Utilities (reuse pattern from main.py)
# =============================================================================

def apply_overrides(cfg: dict, argv: list[str]) -> dict:
    """Apply command-line key=value overrides to config."""
    for arg in argv:
        if "=" not in arg:
            continue
        if arg.startswith("--"):
            continue
        key, value = arg.split("=", 1)
        target = cfg
        parts = key.split(".")
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        target[parts[-1]] = yaml.safe_load(value)
    return cfg


def apply_preset(cfg: dict) -> dict:
    """Apply a named preset from config, merging its sections."""
    presets = cfg.get("presets", {})
    preset_name = cfg.get("preset")
    if not preset_name or not presets:
        return cfg
    if preset_name not in presets:
        raise ValueError(f"Unknown preset: {preset_name}")
    preset_cfg = presets[preset_name]

    def _merge(base, override):
        merged = dict(base or {})
        if override:
            merged.update(override)
        return merged

    for section in ("training", "model", "lm", "annealing", "reward", "action_space"):
        if section in preset_cfg:
            cfg[section] = _merge(cfg.get(section, {}), preset_cfg[section])
    return cfg


def parse_resume_arg(argv: list[str]) -> Optional[str]:
    """Extract --resume path from argv."""
    for i, arg in enumerate(argv):
        if arg == "--resume" and i + 1 < len(argv):
            return argv[i + 1]
        if arg.startswith("--resume="):
            return arg.split("=", 1)[1]
    return None


# =============================================================================
# Sparse-mode resolution (Phase 15 LM-track sparse unblock)
# =============================================================================
#
# Historical state: train_lm.py hard-coded mode="dense" on the training forward
# pass and the eval forward pass (the Trefoil handoff flagged this as "Phase 15
# LM path is scaffolded but does not yet exercise sparse mode during LM
# training"). That meant Phase 15 LM runs were effectively a dense GPT-style
# baseline, regardless of CausalSparseTransformer's WINA / ternary capability.
#
# Fix: opt-in sparse-mode configuration under `lm.sparse`. When absent or
# disabled, behaviour is identical to the pre-fix code path so existing
# phase15a/b/c presets stay frozen. When enabled, the resolved mode + WINA
# kwargs are threaded through train and eval forward calls.
#
# Schema (all fields optional):
#   lm:
#     sparse:
#       enabled: false                  # default: keep dense behaviour
#       train_mode: "circuit_masked"    # "dense" | "circuit_masked" | "full_sparse"
#       eval_mode: "dense"              # eval mode can differ from train
#       neuron_threshold: 0.1
#       gate_mode: "threshold"          # "threshold" | "topk"
#       neuron_topk_fraction: 0.5
# =============================================================================

_VALID_LM_MODES = ("dense", "circuit_masked", "full_sparse")


def resolve_lm_sparse_cfg(cfg: dict) -> dict:
    """Resolve the LM sparse-mode configuration into concrete kwargs.

    Returns a dict with keys:
        enabled:        bool   (False = preserve legacy mode="dense" behaviour)
        train_mode:     str
        eval_mode:      str
        sparse_kwargs:  dict   (neuron_threshold, gate_mode, neuron_topk_fraction)

    Defaults preserve the pre-fix behaviour (dense everywhere) when `lm.sparse`
    is missing — existing Phase 15 presets continue to behave exactly as before.
    """
    sparse_cfg = cfg.get("lm", {}).get("sparse", {}) or {}
    enabled = bool(sparse_cfg.get("enabled", False))

    train_mode = sparse_cfg.get("train_mode", "dense" if not enabled else "circuit_masked")
    eval_mode = sparse_cfg.get("eval_mode", "dense")

    if train_mode not in _VALID_LM_MODES:
        raise ValueError(
            f"lm.sparse.train_mode={train_mode!r} not in {_VALID_LM_MODES}"
        )
    if eval_mode not in _VALID_LM_MODES:
        raise ValueError(
            f"lm.sparse.eval_mode={eval_mode!r} not in {_VALID_LM_MODES}"
        )

    sparse_kwargs = {
        "neuron_threshold": float(sparse_cfg.get("neuron_threshold", 0.1)),
        "gate_mode": sparse_cfg.get("gate_mode", "threshold"),
        "neuron_topk_fraction": float(sparse_cfg.get("neuron_topk_fraction", 0.5)),
    }
    if sparse_kwargs["gate_mode"] not in ("threshold", "topk"):
        raise ValueError(
            f"lm.sparse.gate_mode={sparse_kwargs['gate_mode']!r} must be 'threshold' or 'topk'"
        )

    return {
        "enabled": enabled,
        "train_mode": train_mode,
        "eval_mode": eval_mode,
        "sparse_kwargs": sparse_kwargs,
    }


# =============================================================================
# Model Builder
# =============================================================================

def build_model(cfg: dict, device: torch.device) -> CausalSparseTransformer:
    """Build CausalSparseTransformer from config."""
    model_cfg = cfg.get("model", {})
    model = CausalSparseTransformer(
        vocab_size=model_cfg.get("vocab_size", 50257),
        dim=model_cfg.get("dim", 1024),
        num_heads=model_cfg.get("num_heads", 16),
        mlp_hidden_dim=model_cfg.get("mlp_hidden_dim", 4096),
        num_layers=model_cfg.get("num_layers", 8),
        max_seq_len=model_cfg.get("max_seq_len", 1024),
        quant_threshold=model_cfg.get("quant_threshold", 0.05),
        gate_fc1=model_cfg.get("gate_fc1", True),
        gate_fc2=model_cfg.get("gate_fc2", False),
        gate_score_mode=model_cfg.get("gate_score_mode", "heuristic_v0"),
        tie_embeddings=model_cfg.get("tie_embeddings", True),
    ).to(device)

    param_info = model.count_parameters()
    print(f"Model: CausalSparseTransformer")
    print(f"  Parameters: {param_info['unique']:,} unique ({param_info['unique']/1e6:.1f}M)")
    print(f"  dim={model_cfg.get('dim', 1024)}, layers={model_cfg.get('num_layers', 8)}, "
          f"heads={model_cfg.get('num_heads', 16)}")

    return model


def _build_model_quiet(cfg: dict, device: torch.device) -> CausalSparseTransformer:
    """Build model without printing (for non-rank-0 processes)."""
    model_cfg = cfg.get("model", {})
    return CausalSparseTransformer(
        vocab_size=model_cfg.get("vocab_size", 50257),
        dim=model_cfg.get("dim", 1024),
        num_heads=model_cfg.get("num_heads", 16),
        mlp_hidden_dim=model_cfg.get("mlp_hidden_dim", 4096),
        num_layers=model_cfg.get("num_layers", 8),
        max_seq_len=model_cfg.get("max_seq_len", 1024),
        quant_threshold=model_cfg.get("quant_threshold", 0.05),
        gate_fc1=model_cfg.get("gate_fc1", True),
        gate_fc2=model_cfg.get("gate_fc2", False),
        gate_score_mode=model_cfg.get("gate_score_mode", "heuristic_v0"),
        tie_embeddings=model_cfg.get("tie_embeddings", True),
    ).to(device)


# =============================================================================
# Data Builder (DDP-aware)
# =============================================================================

def build_train_dataloader_ddp(cfg: dict, rank: int, world_size: int):
    """Build training DataLoader with DistributedSampler for DDP."""
    from torch.utils.data import DataLoader

    lm_cfg = cfg.get("lm", {})
    train_cfg = cfg.get("training", {})
    dataset_name = lm_cfg.get("dataset", "roneneldan/TinyStories")
    seq_len = lm_cfg.get("seq_len", 512)
    tokenizer_name = lm_cfg.get("tokenizer", "gpt2")
    streaming = lm_cfg.get("streaming", False)
    max_tokens = lm_cfg.get("max_tokens", None)
    text_field = lm_cfg.get("text_field", "text")
    bs = train_cfg.get("batch_size", 16)

    if streaming:
        dataset = StreamingLMDataset(
            dataset_name=dataset_name, split="train",
            seq_len=seq_len, tokenizer_name=tokenizer_name,
            text_field=text_field,
        )
        return DataLoader(dataset, batch_size=bs, num_workers=0), None
    else:
        dataset = ChunkedLMDataset(
            dataset_name=dataset_name, split="train",
            seq_len=seq_len, tokenizer_name=tokenizer_name,
            max_tokens=max_tokens, text_field=text_field,
        )
        sampler = DistributedSampler(
            dataset, num_replicas=world_size, rank=rank,
            shuffle=True, drop_last=True,
        )
        return DataLoader(
            dataset, batch_size=bs, sampler=sampler,
            num_workers=2, pin_memory=True,
        ), sampler


# =============================================================================
# LR Scheduler
# =============================================================================

def get_lr(step: int, warmup_steps: int, max_steps: int, max_lr: float, min_lr: float) -> float:
    """Cosine learning rate schedule with linear warmup."""
    if step < warmup_steps:
        return max_lr * (step + 1) / warmup_steps
    if step >= max_steps:
        return min_lr
    progress = (step - warmup_steps) / max(1, max_steps - warmup_steps)
    return min_lr + 0.5 * (max_lr - min_lr) * (1.0 + math.cos(math.pi * progress))


# =============================================================================
# Training Loop (DDP-aware, with resume support)
# =============================================================================

def train(cfg: dict, resume_path: Optional[str] = None) -> None:
    """Main training function with DDP and resume support."""
    rank, local_rank, world_size = setup_ddp()
    is_ddp = world_size > 1

    train_cfg = cfg.get("training", {})

    # Seed (offset by rank for data diversity)
    seed = train_cfg.get("seed", 42)
    random.seed(seed + rank)
    np.random.seed(seed + rank)
    torch.manual_seed(seed + rank)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed + rank)

    # Device
    device = torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu")
    log_print(rank, f"DDP: rank={rank}, local_rank={local_rank}, world_size={world_size}")
    log_print(rank, f"Device: {device} ({torch.cuda.get_device_name(local_rank) if torch.cuda.is_available() else 'cpu'})")

    # Mixed precision
    use_amp = train_cfg.get("mixed_precision", "bf16") != "none" and device.type == "cuda"
    amp_dtype = torch.bfloat16 if train_cfg.get("mixed_precision", "bf16") == "bf16" else torch.float16
    log_print(rank, f"Mixed precision: {amp_dtype if use_amp else 'disabled'}")

    # Sparse-mode configuration for the LM forward pass.
    # Default (when `lm.sparse` is absent or enabled=false) preserves the
    # historical mode="dense" behaviour so frozen presets are untouched.
    lm_sparse = resolve_lm_sparse_cfg(cfg)
    log_print(
        rank,
        f"LM sparse: enabled={lm_sparse['enabled']} "
        f"train_mode={lm_sparse['train_mode']} eval_mode={lm_sparse['eval_mode']} "
        f"gate={lm_sparse['sparse_kwargs']['gate_mode']} "
        f"thr={lm_sparse['sparse_kwargs']['neuron_threshold']} "
        f"topk_frac={lm_sparse['sparse_kwargs']['neuron_topk_fraction']}",
    )

    # Build model (only rank 0 prints info)
    if is_main_process(rank):
        model = build_model(cfg, device)
    else:
        model = _build_model_quiet(cfg, device)
    raw_model = model  # Keep reference before DDP wrap

    # Resume from checkpoint if requested
    start_step = 0
    optimizer_state = None
    best_val_loss = float("inf")

    if resume_path:
        resume_dir = Path(resume_path)
        ckpt_file = resume_dir / "checkpoint.pt" if resume_dir.is_dir() else resume_dir
        if not ckpt_file.exists():
            raise FileNotFoundError(f"Checkpoint not found: {ckpt_file}")

        log_print(rank, f"\nResuming from: {ckpt_file}")
        ckpt = torch.load(ckpt_file, map_location=device, weights_only=False)
        raw_model.load_state_dict(ckpt["model_state_dict"])
        optimizer_state = ckpt.get("optimizer_state_dict")
        start_step = ckpt.get("step", 0)
        best_val_loss = ckpt.get("best_val_loss", float("inf"))
        log_print(rank, f"Resumed at step {start_step}")

    # Wrap in DDP
    if is_ddp:
        model = DDP(raw_model, device_ids=[local_rank], output_device=local_rank)
    else:
        model = raw_model

    # Build data with distributed sampler
    log_print(rank, "\nLoading training data...")
    train_loader, sampler = build_train_dataloader_ddp(cfg, rank, world_size)

    val_loader = None
    if is_main_process(rank):
        try:
            # Streaming datasets (e.g. OpenWebText) have no validation split;
            # use train split as a perplexity proxy (evaluate() caps at max_batches).
            streaming = cfg.get("lm", {}).get("streaming", False)
            val_split = "train" if streaming else "validation"
            val_loader = build_lm_dataloader(cfg, split=val_split, batch_size=train_cfg.get("batch_size", 16))
            log_print(rank, f"Validation set loaded (split={val_split}).")
        except Exception:
            log_print(rank, "No validation split found, skipping eval.")

    # Optimizer
    lr = float(train_cfg.get("learning_rate", 3e-4))
    weight_decay = float(train_cfg.get("weight_decay", 0.1))
    min_lr = float(train_cfg.get("min_lr", lr * 0.1))

    # Separate weight decay: no decay for bias, LayerNorm, embeddings
    decay_params = []
    no_decay_params = []
    for name, param in raw_model.named_parameters():
        if not param.requires_grad:
            continue
        if param.ndim < 2 or "norm" in name or "bias" in name or "emb" in name:
            no_decay_params.append(param)
        else:
            decay_params.append(param)

    optimizer = torch.optim.AdamW([
        {"params": decay_params, "weight_decay": weight_decay},
        {"params": no_decay_params, "weight_decay": 0.0},
    ], lr=lr, betas=(0.9, 0.95), fused=device.type == "cuda")

    # Restore optimizer state if resuming
    if optimizer_state is not None:
        optimizer.load_state_dict(optimizer_state)
        log_print(rank, "Optimizer state restored.")

    # Training params
    max_steps = int(train_cfg.get("max_steps", 50000))
    warmup_steps = int(train_cfg.get("warmup_steps", 500))
    grad_accum = int(train_cfg.get("gradient_accumulation_steps", 16))
    grad_clip = float(train_cfg.get("grad_clip", 1.0))
    eval_interval = int(train_cfg.get("eval_interval", 1000))
    save_interval = int(train_cfg.get("save_interval", 20000))
    log_interval = int(train_cfg.get("log_interval", 100))

    # Checkpoint directory (only rank 0 manages)
    ckpt_dir = None
    if is_main_process(rank):
        if resume_path:
            # Reuse the parent run directory when resuming
            resume_dir = Path(resume_path)
            if resume_dir.is_dir():
                ckpt_dir = resume_dir.parent
            else:
                ckpt_dir = resume_dir.parent.parent
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            preset_name = cfg.get("preset", "custom")
            ckpt_dir = Path(f"checkpoints/phase15/{preset_name}/{timestamp}")

        ckpt_dir.mkdir(parents=True, exist_ok=True)
        log_print(rank, f"\nCheckpoints: {ckpt_dir}")

        # Save config
        with open(ckpt_dir / "config.json", "w") as f:
            save_cfg = {k: v for k, v in cfg.items() if k != "presets"}
            json.dump(save_cfg, f, indent=2, default=str)

    # GradScaler for AMP
    scaler = torch.amp.GradScaler(enabled=use_amp and amp_dtype == torch.float16)

    # Effective batch size accounting
    effective_batch = train_cfg.get("batch_size", 16) * grad_accum * world_size
    remaining_steps = max_steps - start_step
    log_print(rank, f"\nTraining: steps {start_step} -> {max_steps} ({remaining_steps} remaining), "
              f"grad_accum={grad_accum}, world_size={world_size}, effective_batch={effective_batch}")
    log_print(rank, f"LR: {lr} -> {min_lr} (cosine, {warmup_steps} warmup)")
    log_print(rank, f"Checkpoints every {save_interval} steps")
    log_print(rank, "=" * 60)

    model.train()
    global_step = start_step
    total_tokens = 0
    running_loss = 0.0
    train_start = time.time()
    epoch = 0
    data_iter = iter(train_loader)

    while global_step < max_steps:
        optimizer.zero_grad()
        micro_loss_sum = 0.0

        for micro_step in range(grad_accum):
            # Get batch (restart data iterator if exhausted)
            try:
                batch = next(data_iter)
            except StopIteration:
                epoch += 1
                if sampler is not None:
                    sampler.set_epoch(epoch)
                data_iter = iter(train_loader)
                batch = next(data_iter)

            input_ids = batch["input_ids"].to(device)
            labels = batch["labels"].to(device)
            batch_tokens = input_ids.numel()

            # Sync gradients only on the last micro-step
            if is_ddp:
                sync_context = model.no_sync if micro_step < grad_accum - 1 else nullcontext
            else:
                sync_context = nullcontext

            with sync_context():
                # Forward pass with AMP.
                # Mode + sparse kwargs are resolved from lm.sparse config. When
                # lm.sparse is disabled, train_mode defaults to "dense" so the
                # behaviour matches the pre-fix code path.
                with torch.amp.autocast(device_type=device.type, dtype=amp_dtype, enabled=use_amp):
                    logits, _ = model(
                        input_ids,
                        mode=lm_sparse["train_mode"],
                        **lm_sparse["sparse_kwargs"],
                    )
                    loss = F.cross_entropy(
                        logits.view(-1, raw_model.vocab_size),
                        labels.view(-1),
                        ignore_index=-100,
                    )
                    loss = loss / grad_accum

                # Backward
                if use_amp and amp_dtype == torch.float16:
                    scaler.scale(loss).backward()
                else:
                    loss.backward()

            micro_loss_sum += loss.item()
            total_tokens += batch_tokens

        # micro_loss_sum is now avg loss (sum of loss/grad_accum over grad_accum steps)
        # Gradient clipping
        if use_amp and amp_dtype == torch.float16:
            scaler.unscale_(optimizer)
        if grad_clip > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)

        # LR schedule
        current_lr = get_lr(global_step, warmup_steps, max_steps, lr, min_lr)
        for param_group in optimizer.param_groups:
            param_group["lr"] = current_lr

        # Step
        if use_amp and amp_dtype == torch.float16:
            scaler.step(optimizer)
            scaler.update()
        else:
            optimizer.step()

        global_step += 1
        running_loss += micro_loss_sum

        # Log (rank 0 only)
        if global_step % log_interval == 0 and is_main_process(rank):
            avg_loss = running_loss / log_interval
            elapsed = time.time() - train_start
            tokens_per_sec = total_tokens / elapsed
            total_tok_per_sec = tokens_per_sec * world_size if is_ddp else tokens_per_sec
            ppl = math.exp(min(avg_loss, 20))
            print(
                f"step={global_step:>6d} | loss={avg_loss:.4f} | ppl={ppl:.2f} | "
                f"lr={current_lr:.2e} | tok/s={total_tok_per_sec:.0f} | "
                f"elapsed={elapsed/60:.1f}m",
                flush=True,
            )
            running_loss = 0.0

        # Evaluate (rank 0 only)
        if val_loader is not None and global_step % eval_interval == 0 and is_main_process(rank):
            val_loss = evaluate(
                raw_model, val_loader, device, use_amp, amp_dtype,
                eval_mode=lm_sparse["eval_mode"],
                sparse_kwargs=lm_sparse["sparse_kwargs"],
            )
            val_ppl = math.exp(min(val_loss, 20))
            print(f"  [EVAL] step={global_step} | val_loss={val_loss:.4f} | val_ppl={val_ppl:.2f}", flush=True)

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                save_checkpoint(raw_model, optimizer, global_step, cfg, ckpt_dir / "best",
                                best_val_loss=best_val_loss)
                print(f"  [EVAL] New best! Saved to {ckpt_dir / 'best'}", flush=True)

            model.train()

        # Save checkpoint (rank 0 only)
        if global_step % save_interval == 0 and is_main_process(rank):
            save_checkpoint(raw_model, optimizer, global_step, cfg,
                            ckpt_dir / f"step_{global_step}",
                            best_val_loss=best_val_loss)
            print(f"  [SAVE] step={global_step} -> {ckpt_dir / f'step_{global_step}'}", flush=True)

        # Barrier to keep all ranks in sync after eval/save
        if is_ddp and (global_step % eval_interval == 0 or global_step % save_interval == 0):
            dist.barrier()

    # Final save (rank 0 only)
    if is_main_process(rank):
        save_checkpoint(raw_model, optimizer, global_step, cfg, ckpt_dir / "final",
                        best_val_loss=best_val_loss)
        elapsed = time.time() - train_start
        print("=" * 60)
        print(f"Training complete: step {start_step} -> {global_step} in {elapsed/60:.1f} minutes")
        print(f"Total tokens (this rank): {total_tokens:,}")
        print(f"Final checkpoint: {ckpt_dir / 'final'}")
        if best_val_loss < float("inf"):
            print(f"Best val loss: {best_val_loss:.4f} (ppl={math.exp(min(best_val_loss, 20)):.2f})")

    cleanup_ddp()


# =============================================================================
# Evaluation
# =============================================================================

@torch.no_grad()
def evaluate(
    model: CausalSparseTransformer,
    dataloader,
    device: torch.device,
    use_amp: bool = True,
    amp_dtype: torch.dtype = torch.bfloat16,
    max_batches: int = 50,
    eval_mode: str = "dense",
    sparse_kwargs: Optional[Dict] = None,
) -> float:
    """Compute average loss on validation set.

    `eval_mode` and `sparse_kwargs` are resolved by `resolve_lm_sparse_cfg` in
    the training entry point. Defaults preserve the historical dense-eval
    behaviour for any caller that does not pass them (e.g. standalone scripts).
    """
    if sparse_kwargs is None:
        sparse_kwargs = {}
    model.eval()
    total_loss = 0.0
    num_batches = 0

    for batch in dataloader:
        input_ids = batch["input_ids"].to(device)
        labels = batch["labels"].to(device)

        with torch.amp.autocast(device_type=device.type, dtype=amp_dtype, enabled=use_amp):
            logits, _ = model(input_ids, mode=eval_mode, **sparse_kwargs)
            loss = F.cross_entropy(
                logits.view(-1, model.vocab_size),
                labels.view(-1),
                ignore_index=-100,
            )

        total_loss += loss.item()
        num_batches += 1

        if num_batches >= max_batches:
            break

    return total_loss / max(1, num_batches)


# =============================================================================
# Checkpointing
# =============================================================================

def save_checkpoint(model, optimizer, step, cfg, path: Path,
                    best_val_loss: float = float("inf")) -> None:
    """Save model checkpoint (always saves raw model, not DDP wrapper)."""
    path.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "step": step,
        "best_val_loss": best_val_loss,
        "model_config": {
            k: v for k, v in cfg.get("model", {}).items()
        },
    }, path / "checkpoint.pt")


def load_checkpoint(path: Path, device: torch.device, cfg: dict = None):
    """Load a checkpoint, returning (model, optimizer_state, step)."""
    ckpt = torch.load(path / "checkpoint.pt", map_location=device, weights_only=False)
    model_config = ckpt.get("model_config", {})

    # Allow config override
    if cfg:
        model_config.update(cfg.get("model", {}))

    model = CausalSparseTransformer(
        vocab_size=model_config.get("vocab_size", 50257),
        dim=model_config.get("dim", 1024),
        num_heads=model_config.get("num_heads", 16),
        mlp_hidden_dim=model_config.get("mlp_hidden_dim", 4096),
        num_layers=model_config.get("num_layers", 8),
        max_seq_len=model_config.get("max_seq_len", 1024),
        quant_threshold=model_config.get("quant_threshold", 0.05),
        gate_fc1=model_config.get("gate_fc1", True),
        gate_fc2=model_config.get("gate_fc2", False),
        gate_score_mode=model_config.get("gate_score_mode", "heuristic_v0"),
        tie_embeddings=model_config.get("tie_embeddings", True),
    ).to(device)

    model.load_state_dict(ckpt["model_state_dict"])
    return model, ckpt.get("optimizer_state_dict"), ckpt.get("step", 0)


# =============================================================================
# Entry Point
# =============================================================================

def main():
    cfg = load_config()
    cfg = apply_overrides(cfg, sys.argv[1:])  # parse preset=... first
    cfg = apply_preset(cfg)
    cfg = apply_overrides(cfg, sys.argv[1:])  # re-apply so CLI overrides win over preset

    resume_path = parse_resume_arg(sys.argv[1:])
    train(cfg, resume_path=resume_path)


if __name__ == "__main__":
    main()

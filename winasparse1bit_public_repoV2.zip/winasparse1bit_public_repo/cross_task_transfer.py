"""Cross-task transfer experiment: math_cot -> parity_cot_medium.

Three arms test whether the converged sparse circuit from math_cot is
task-general or task-specific:

    A baseline: train parity_cot from scratch (no transfer)
    B frozen:   load math_cot weights + bake circuit into static mask;
                tau locked to 1.0 so runtime_mask = permitted = mask
    C free:     load math_cot weights only; tau action grid unconstrained

If B >= C, the math_cot circuit is task-general and transferring it helps.
If B < C, the circuit is task-specific and the freedom to re-prune helps.
If C ~ A, weight transfer doesn't help, so transfer is structural-only.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import random
import torch
import yaml

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from config.loader import load_config
from main import apply_preset, apply_mode_overrides, build_model_and_optimizer
from rl.config_space import build_action_grids
from rl.env import ConfigEnv
from rl.lambda_scheduler import make_lambda_scheduler
from rl.policy_net import PolicyNet
from rl.trainer import train_phase2
from sparse_llm.layers import LowBitLinear
from rl.config_applier import apply_config_to_model
from utils import EGMHandler


def transfer_weights(source_sd: dict, target_model: torch.nn.Module) -> tuple[int, list]:
    """Load source weights into target with pos_emb truncation."""
    target_sd = target_model.state_dict()
    loaded = {}
    actions = []
    for k, v in source_sd.items():
        if k not in target_sd:
            actions.append((k, "skipped (not in target)"))
            continue
        tv = target_sd[k]
        if v.shape == tv.shape:
            loaded[k] = v
            actions.append((k, "copied"))
        elif "pos_emb" in k and v.dim() == tv.dim():
            # Truncate sequence dim
            sliced = v[..., : tv.shape[-2], :] if v.shape[-2] > tv.shape[-2] else v
            if sliced.shape == tv.shape:
                loaded[k] = sliced
                actions.append((k, f"truncated {tuple(v.shape)} -> {tuple(tv.shape)}"))
            else:
                actions.append((k, f"shape mismatch (kept target init): {v.shape} vs {tv.shape}"))
        else:
            actions.append((k, f"shape mismatch (kept target init): {v.shape} vs {tv.shape}"))
    missing, unexpected = target_model.load_state_dict(loaded, strict=False)
    return len(loaded), actions


def freeze_circuit(target_model: torch.nn.Module) -> tuple[int, dict]:
    """Copy runtime_mask -> mask for each LowBitLinear, locking the topology.

    After this, tau-pruning at runtime can only further-restrict from `mask`,
    so combined with action_space.tau_global=[1.0] the connectivity is frozen.
    """
    n = 0
    by_layer = {}
    for name, mod in target_model.named_modules():
        if isinstance(mod, LowBitLinear) and hasattr(mod, "runtime_mask"):
            with torch.no_grad():
                circuit = mod.runtime_mask.detach().clone()
                mod.mask.copy_(circuit)
                # Reset runtime_mask to ones so first forward is identity wrt mask
                mod.runtime_mask.fill_(1.0)
            kept = float(circuit.float().mean())
            n += 1
            by_layer[name] = {"shape": list(circuit.shape), "active_frac": kept}
    return n, by_layer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["baseline", "frozen", "free"], required=True)
    ap.add_argument(
        "--source-ckpt",
        default="checkpoints/model_zero_math_v1/seed42/final/checkpoint.pt",
    )
    ap.add_argument("--target-preset", default="fld_mixed_v1")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--steps", type=int, default=5000)
    ap.add_argument("--summary-log-steps", type=int, default=500)
    ap.add_argument("--log-prefix", default="xfer")
    ap.add_argument("--fld-no-trace", action="store_true",
                    help="Disable FLD trace (training.fld.include_trace=false) "
                         "to defeat the literal-answer shortcut and force real reasoning.")
    args = ap.parse_args()

    # Load + preset
    cfg = load_config()
    cfg["preset"] = args.target_preset
    cfg = apply_preset(cfg)
    cfg = apply_mode_overrides(cfg)

    # Inject overrides
    cfg["training"]["seed"] = args.seed
    cfg.setdefault("annealing", {})
    cfg["annealing"]["total_steps"] = args.steps
    cfg["training"]["summary_log_steps"] = args.summary_log_steps
    cfg["training"]["save_checkpoints"] = False
    cfg["training"]["debug_scan_actions"] = False
    cfg["training"]["debug_prediction_delta"] = False
    cfg["training"].setdefault("entropy_bonus", 0.003)
    cfg["training"].setdefault("learning_rate", 0.0003)
    cfg.setdefault("reward", {})
    cfg["reward"]["acc_penalty_scale"] = 3.0

    # Frozen mode: lock tau action grid to [1.0]
    if args.mode == "frozen":
        cfg["action_space"] = dict(cfg.get("action_space", {}))
        cfg["action_space"]["tau_global"] = [1.0]
        print(f"[XFER] mode=frozen: action_space.tau_global locked to [1.0]")

    # FLD trace disable: defeats the literal-answer shortcut for clean acc-transfer test
    if args.fld_no_trace:
        cfg["training"].setdefault("fld", {})
        cfg["training"]["fld"]["include_trace"] = False
        print(f"[XFER] FLD trace disabled (include_trace=False)")

    # Set seed
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    device = torch.device(cfg.get("training", {}).get("device", "cuda"))
    print(f"[XFER] mode={args.mode} target={args.target_preset} seed={args.seed} "
          f"steps={args.steps} device={device}")

    # Build target model
    model, optimizer = build_model_and_optimizer(cfg, device)

    # Warm-up: apply a dummy action to register runtime_mask buffers on every
    # LowBitLinear. Necessary because runtime_mask is created lazily by
    # apply_config_to_model on first call -- without it, freeze_circuit() would
    # find no runtime_mask attribute and freeze nothing.
    apply_config_to_model(model, {"tau": 0.10, "delta": 0.01, "k_act": 0.5})
    print("[XFER] runtime_mask buffers initialized via warm-up action")

    # Transfer if applicable
    if args.mode in ("frozen", "free"):
        ckpt_path = ROOT / args.source_ckpt
        print(f"[XFER] loading source: {ckpt_path}")
        ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
        source_sd = ckpt["model_state_dict"]
        n_loaded, actions = transfer_weights(source_sd, model)
        copied = sum(1 for _, a in actions if a == "copied")
        truncated = sum(1 for _, a in actions if a.startswith("truncated"))
        skipped = sum(1 for _, a in actions if a.startswith("shape mismatch") or a.startswith("skipped"))
        print(f"[XFER] transferred {n_loaded} tensors: {copied} copied, "
              f"{truncated} truncated, {skipped} skipped")
        for k, a in actions:
            if a != "copied":
                print(f"  {k}: {a}")

    if args.mode == "frozen":
        n_frozen, by_layer = freeze_circuit(model)
        print(f"[XFER] froze {n_frozen} LowBitLinear circuits")
        for name, info in by_layer.items():
            print(f"  {name}: shape={info['shape']} active_frac={info['active_frac']:.4f}")

    # Set up env + RL
    egm_cfg = cfg.get("egm", {})
    egm_handler = EGMHandler(endpoint=egm_cfg.get("endpoint", ""), api_key=egm_cfg.get("api_key"))
    lambda_scheduler = make_lambda_scheduler(cfg)

    env = ConfigEnv(
        model=model,
        optimizer=optimizer,
        cfg=cfg,
        egm_handler=egm_handler,
        lambda_scheduler=lambda_scheduler,
        device=device,
    )

    grids = build_action_grids(cfg)
    action_sizes = (
        len(grids["tau_values"]),
        len(grids["delta_values"]),
        len(grids["kact_values"]),
        len(grids["mode_values"]),
    )
    print(f"[XFER] action grid sizes: {action_sizes}")
    policy_net = PolicyNet(action_sizes=action_sizes)

    # Run
    train_phase2(env, policy_net, num_steps=args.steps, lr=3e-4, device=device)


if __name__ == "__main__":
    main()

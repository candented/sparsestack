"""Tier A autoresearch loop for WINASparse1bit.

Modeled on karpathy/autoresearch but scoped to config-only overrides
(no code edits, no git rollback needed). Drives main.py via CLI overrides
on a fixed step budget, parses logs, scores composite metric, journals.

Search axes are config keys validated by main.py's allowed-keys check.
Failures don't corrupt state -- invalid overrides raise immediately.

Usage:
    python auto_phase.py --iterations 20
    python auto_phase.py --iterations 5 --budget-steps 1000   # quick scan
    python auto_phase.py --report                             # print top-N from journal

Journal: logs/auto_phase/journal.jsonl  (append-only, one record per (config, seed) run)
Run logs: logs/auto_phase/runs/run_<ts>_seed<N>.log
"""

from __future__ import annotations

import argparse
import json
import random
import re
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).parent
JOURNAL_PATH = ROOT / "logs" / "auto_phase" / "journal.jsonl"
RUN_LOG_DIR = ROOT / "logs" / "auto_phase" / "runs"

# ---------------------------------------------------------------------------
# Search space -- Tier A: config-only overrides
# Each axis = list of option dicts. An option dict is one or more
# key=value pairs that get applied together (e.g. lambda_mix sums to 1).
# ---------------------------------------------------------------------------

SEARCH_AXES: list[dict[str, Any]] = [
    {
        "name": "entropy_bonus",
        "options": [
            {"training.entropy_bonus": 0.003},
            {"training.entropy_bonus": 0.005},
            {"training.entropy_bonus": 0.007},
            {"training.entropy_bonus": 0.008},
        ],
    },
    {
        "name": "lambda_mix",
        "options": [
            # current default
            {"annealing.lambda_final.conn": 0.50,
             "annealing.lambda_final.act":  0.30,
             "annealing.lambda_final.prec": 0.20},
            # connectivity-heavy
            {"annealing.lambda_final.conn": 0.60,
             "annealing.lambda_final.act":  0.20,
             "annealing.lambda_final.prec": 0.20},
            # activation-heavy
            {"annealing.lambda_final.conn": 0.40,
             "annealing.lambda_final.act":  0.40,
             "annealing.lambda_final.prec": 0.20},
            # precision-heavy
            {"annealing.lambda_final.conn": 0.40,
             "annealing.lambda_final.act":  0.30,
             "annealing.lambda_final.prec": 0.30},
        ],
    },
    {
        "name": "model_lr",
        "options": [
            {"training.learning_rate": 0.0001},
            {"training.learning_rate": 0.0003},
            {"training.learning_rate": 0.001},
        ],
    },
    {
        "name": "acc_penalty",
        "options": [
            {"reward.acc_penalty_scale": 1.5},
            {"reward.acc_penalty_scale": 2.0},
            {"reward.acc_penalty_scale": 2.5},
            {"reward.acc_penalty_scale": 3.0},
        ],
    },
]

PRESET = "model_zero_math_v1"
DEFAULT_SEEDS = [42, 43]
DEFAULT_BUDGET_STEPS = 2500          # ~12 min on 4060
DEFAULT_SUMMARY_LOG_STEPS = 500


# ---------------------------------------------------------------------------
# Composite scoring
# ---------------------------------------------------------------------------

def composite_score(metrics: dict | None) -> float:
    """Higher is better.

    Components:
      + acc          (primary objective; weight 0.6)
      - flops        (efficiency; weight 0.2)
      - collapse_pen (max(0, 0.4 - delta_floor); weight 0.3)

    A run with delta_floor < 0.4 is penalized linearly. delta_floor = 0.0 (full collapse)
    costs 0.12. delta_floor >= 0.4 costs 0.
    """
    if metrics is None:
        return -1e9
    acc = metrics.get("acc", 0.0)
    flops = metrics.get("flops", 1.0)
    delta_floor = metrics.get("delta_floor", 0.0)
    collapse_pen = max(0.0, 0.4 - delta_floor)
    return 0.6 * acc - 0.2 * flops - 0.3 * collapse_pen


# ---------------------------------------------------------------------------
# Journal I/O
# ---------------------------------------------------------------------------

def load_journal() -> list[dict]:
    if not JOURNAL_PATH.exists():
        return []
    with open(JOURNAL_PATH, "r") as f:
        return [json.loads(line) for line in f if line.strip()]


def append_journal(entry: dict) -> None:
    JOURNAL_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(JOURNAL_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")


# ---------------------------------------------------------------------------
# Config sampling
# ---------------------------------------------------------------------------

def config_key(config: dict) -> tuple:
    return tuple(sorted(config.items()))


def sample_config(history: list[dict], rng: random.Random, max_attempts: int = 200) -> dict | None:
    """Random sample from search space, dedupe against history."""
    tried_keys = {config_key(h["config"]) for h in history}
    for _ in range(max_attempts):
        cfg: dict = {}
        for axis in SEARCH_AXES:
            choice = rng.choice(axis["options"])
            cfg.update(choice)
        if config_key(cfg) not in tried_keys:
            return cfg
    return None


# ---------------------------------------------------------------------------
# Log parsing
# ---------------------------------------------------------------------------

_SUMMARY_RE = re.compile(
    r"\[SUMMARY\] step=(\d+).*?mean_flops=([\d.]+).*?mean_acc=([\d.]+)"
    r".*?ref_acc=([\d.]+).*?flops_ref=([\d.]+).*?"
    r"entropy=\(tau=([\d.]+) delta=([\d.]+) kact=([\d.]+) bits\)"
    r".*?unique_actions=(\d+)/(\d+)"
)
_TRACE_RE = re.compile(
    r"\[TRACE_UTIL\] step=(\d+) acc_with_trace=([\d.]+) "
    r"acc_without_trace=([\d.]+) delta=([+-]?[\d.]+)"
)


def parse_log(log_path: Path) -> dict | None:
    """Extract final-step metrics + delta-entropy floor across the run."""
    if not log_path.exists():
        return None
    text = log_path.read_text(errors="replace")
    summaries = _SUMMARY_RE.findall(text)
    if not summaries:
        return None
    final = summaries[-1]
    delta_entropies = [float(s[6]) for s in summaries]
    tau_entropies = [float(s[5]) for s in summaries]
    kact_entropies = [float(s[7]) for s in summaries]

    traces = _TRACE_RE.findall(text)
    trace_final = float(traces[-1][3]) if traces else None

    return {
        "step": int(final[0]),
        "flops": float(final[1]),
        "acc": float(final[2]),
        "ref_acc": float(final[3]),
        "flops_ref": float(final[4]),
        "tau_entropy_final": float(final[5]),
        "delta_entropy_final": float(final[6]),
        "kact_entropy_final": float(final[7]),
        "unique_actions": int(final[8]),
        "delta_floor": min(delta_entropies),
        "tau_floor": min(tau_entropies),
        "kact_floor": min(kact_entropies),
        "trace_util_final": trace_final,
    }


# ---------------------------------------------------------------------------
# Experiment runner
# ---------------------------------------------------------------------------

def run_experiment(
    config: dict,
    seed: int,
    budget_steps: int,
    summary_log_steps: int,
    verbose: bool = True,
) -> tuple[dict | None, Path, int]:
    overrides = [f"{k}={v}" for k, v in config.items()]
    overrides += [
        f"training.seed={seed}",
        f"annealing.total_steps={budget_steps}",
        f"training.summary_log_steps={summary_log_steps}",
        "training.save_checkpoints=false",
        "training.debug_scan_actions=false",
        "training.debug_prediction_delta=false",
    ]

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = RUN_LOG_DIR / f"run_{timestamp}_seed{seed}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    cmd = [sys.executable, "main.py", f"preset={PRESET}", "training.device=cuda"] + overrides

    if verbose:
        print(f"[AUTO_PHASE]   cmd: {' '.join(cmd)}")
        print(f"[AUTO_PHASE]   log: {log_path}")

    with open(log_path, "w") as f:
        proc = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, cwd=str(ROOT))

    metrics = parse_log(log_path)
    return metrics, log_path, proc.returncode


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--iterations", type=int, default=20,
                    help="Number of unique configs to evaluate")
    ap.add_argument("--seeds", type=int, nargs="+", default=DEFAULT_SEEDS)
    ap.add_argument("--budget-steps", type=int, default=DEFAULT_BUDGET_STEPS)
    ap.add_argument("--summary-log-steps", type=int, default=DEFAULT_SUMMARY_LOG_STEPS)
    ap.add_argument("--rng-seed", type=int, default=0,
                    help="RNG seed for proposal sampling (does not affect training seeds)")
    ap.add_argument("--report", action="store_true",
                    help="Print top configs from journal and exit (no new runs)")
    ap.add_argument("--top", type=int, default=10)
    args = ap.parse_args()

    history = load_journal()

    if args.report:
        report(history, args.top)
        return

    rng = random.Random(args.rng_seed)
    print(f"[AUTO_PHASE] journal has {len(history)} prior runs")
    if history:
        best = max(history, key=lambda h: h["composite"])
        print(f"[AUTO_PHASE] current best: composite={best['composite']:.4f} "
              f"acc={best['metrics']['acc']:.4f} config={best['config']}")

    for it in range(args.iterations):
        config = sample_config(history, rng)
        if config is None:
            print("[AUTO_PHASE] search space exhausted (or sample failed 200x)")
            break

        scores: list[float] = []
        for seed in args.seeds:
            print(f"\n[AUTO_PHASE] iter {it+1}/{args.iterations} seed={seed}")
            print(f"[AUTO_PHASE]   config={config}")

            t0 = time.time()
            metrics, log_path, rc = run_experiment(
                config, seed, args.budget_steps, args.summary_log_steps
            )
            elapsed = time.time() - t0

            score = composite_score(metrics)
            scores.append(score)

            entry = {
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "iteration": it + 1,
                "seed": seed,
                "config": config,
                "metrics": metrics,
                "composite": score,
                "log_path": str(log_path.relative_to(ROOT)),
                "elapsed_sec": round(elapsed, 1),
                "returncode": rc,
            }
            history.append(entry)
            append_journal(entry)

            if metrics:
                print(f"[AUTO_PHASE]   acc={metrics['acc']:.4f} "
                      f"flops={metrics['flops']:.3f} "
                      f"delta_floor={metrics['delta_floor']:.2f} "
                      f"composite={score:.4f} "
                      f"({elapsed:.0f}s)")
            else:
                print(f"[AUTO_PHASE]   PARSE FAILED rc={rc} composite={score:.4f}")

        mean_score = sum(scores) / len(scores) if scores else float("-inf")
        min_score = min(scores) if scores else float("-inf")
        print(f"[AUTO_PHASE] iter {it+1} done: mean_composite={mean_score:.4f} "
              f"min_composite={min_score:.4f}")

    print("\n" + "=" * 60)
    report(history, args.top)


def report(history: list[dict], top: int) -> None:
    if not history:
        print("[AUTO_PHASE] journal empty")
        return

    # Group by config; aggregate across seeds
    grouped: dict[tuple, list[dict]] = {}
    for h in history:
        grouped.setdefault(config_key(h["config"]), []).append(h)

    rows = []
    for key, runs in grouped.items():
        comps = [r["composite"] for r in runs]
        accs = [r["metrics"]["acc"] for r in runs if r.get("metrics")]
        d_floors = [r["metrics"]["delta_floor"] for r in runs if r.get("metrics")]
        rows.append({
            "config": dict(key),
            "n": len(runs),
            "mean_composite": sum(comps) / len(comps),
            "min_composite": min(comps),
            "mean_acc": (sum(accs) / len(accs)) if accs else None,
            "min_acc": min(accs) if accs else None,
            "max_acc": max(accs) if accs else None,
            "mean_delta_floor": (sum(d_floors) / len(d_floors)) if d_floors else None,
        })

    rows.sort(key=lambda r: -r["mean_composite"])

    print(f"[AUTO_PHASE] top {min(top, len(rows))} configs (of {len(rows)} unique, "
          f"{len(history)} total runs):")
    for rank, r in enumerate(rows[:top], 1):
        acc_str = (f"acc {r['min_acc']:.3f}-{r['max_acc']:.3f} "
                   f"(mean={r['mean_acc']:.3f})") if r["mean_acc"] is not None else "acc n/a"
        df_str = (f"delta_floor mean={r['mean_delta_floor']:.2f}"
                  if r["mean_delta_floor"] is not None else "delta_floor n/a")
        print(f"  {rank:2d}. composite mean={r['mean_composite']:.4f} "
              f"(min {r['min_composite']:.4f}, n={r['n']}) | {acc_str} | {df_str}")
        print(f"      config: {r['config']}")


if __name__ == "__main__":
    main()

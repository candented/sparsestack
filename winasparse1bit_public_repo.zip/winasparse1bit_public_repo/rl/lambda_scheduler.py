from __future__ import annotations

from typing import Callable, Dict


def make_lambda_scheduler(cfg: Dict[str, object]) -> Callable[[int], Dict[str, float]]:
    anneal_cfg = cfg.get("annealing", {})
    total_steps = int(anneal_cfg.get("total_steps", 1))
    warmup_ratio = float(anneal_cfg.get("warmup_ratio", 0.0))
    warmup_steps = max(1, int(total_steps * warmup_ratio))
    lambda_final = anneal_cfg.get("lambda_final", {})
    lambda_conn_final = float(lambda_final.get("conn", 0.0))
    lambda_act_final = float(lambda_final.get("act", 0.0))
    lambda_prec_final = float(lambda_final.get("prec", 0.0))

    def scheduler(step: int) -> Dict[str, float]:
        clamped_step = max(0, step)
        alpha = min(1.0, clamped_step / warmup_steps)
        return {
            "lambda_conn": alpha * lambda_conn_final,
            "lambda_act": alpha * lambda_act_final,
            "lambda_prec": alpha * lambda_prec_final,
        }

    return scheduler

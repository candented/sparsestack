from __future__ import annotations

from typing import Dict
import torch


def compute_reward(
    acc: float,
    ref_acc: float,
    flops: float,
    flops_ref: float,
    conn_sparsity: float,
    prec_sparsity: float,
    lambdas: Dict[str, float],
    config: Dict[str, float] | None = None,
) -> float:
    """
    Compute a simple, interpretable reward:
      - Heavy penalty when accuracy drops below the reference.
      - Hinge penalties when FLOPs/density exceed the reference targets.
      - Optional precision sparsity penalty.
    """

    cfg = config or {}
    lambda_conn = float(lambdas.get("lambda_conn", 0.0))
    lambda_act = float(lambdas.get("lambda_act", 0.0))
    lambda_prec = float(lambdas.get("lambda_prec", 0.0))

    # 1) Accuracy term
    acc_gap = max(0.0, ref_acc - acc)
    acc_penalty_scale = float(cfg.get("acc_penalty_scale", 1.0))
    penalty_acc = acc_penalty_scale * acc_gap

    # 2) FLOPs hinge: penalize only if more expensive than reference (allow override)
    flops_ref_eff = cfg.get("flops_ref_override", flops_ref)
    if flops_ref_eff is None:
        flops_ref_eff = flops_ref
    penalty_flops = max(0.0, flops - flops_ref_eff)

    # 3) Connectivity hinge: penalize if denser than target (default: reference density)
    conn_density = 1.0 - conn_sparsity
    target_conn_sparsity = float(cfg.get("conn_sparsity_ref", conn_sparsity))
    target_conn_density = 1.0 - target_conn_sparsity
    penalty_conn = max(0.0, conn_density - target_conn_density)

    # 4) Precision sparsity term (placeholder but safe)
    penalty_prec = max(0.0, prec_sparsity)

    reward = (
        acc
        - penalty_acc
        - lambda_conn * penalty_flops
        - lambda_act * penalty_conn
        - lambda_prec * penalty_prec
    )
    return float(reward)


def compute_geometric_reward(pred: torch.Tensor, target: torch.Tensor, x_in: torch.Tensor, lambda_mag: float = 0.0) -> torch.Tensor:
    """
    Geometric reward: cosine similarity minus magnitude drift penalty.
    """
    pred_norm = pred.norm(dim=-1).clamp_min(1e-6)
    target_norm = target.norm(dim=-1).clamp_min(1e-6)
    cos = (pred * target).sum(dim=-1) / (pred_norm * target_norm)
    in_norm = x_in.norm(dim=-1).clamp_min(1e-6)
    drift = (pred_norm - in_norm).abs()
    return cos - lambda_mag * drift

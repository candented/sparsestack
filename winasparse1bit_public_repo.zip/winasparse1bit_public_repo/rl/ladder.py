from __future__ import annotations

import copy
from typing import Callable, Dict, List, Sequence

import torch

from rl.config_space import build_action_grids
from rl.env import ConfigEnv
from rl.lambda_scheduler import make_lambda_scheduler
from rl.policy_net import PolicyNet
from rl.trainer import train_phase2
from utils import EGMHandler


class LadderController:
    """
    Optional outer-loop controller that sequences small training stages.

    All behavior is disabled unless training.ladder.enabled is true. The controller reuses
    the existing env/trainer; stages are config-driven and can restart or carry state.
    """

    def __init__(
        self,
        base_cfg: dict,
        device: torch.device,
        build_model_fn: Callable[[dict, torch.device], tuple[torch.nn.Module, torch.optim.Optimizer]],
        apply_preset_fn: Callable[[dict], dict],
        apply_mode_overrides_fn: Callable[[dict], dict],
        train_fn: Callable = train_phase2,
    ) -> None:
        self.base_cfg = copy.deepcopy(base_cfg)
        self.device = device
        self.build_model_fn = build_model_fn
        self.apply_preset_fn = apply_preset_fn
        self.apply_mode_overrides_fn = apply_mode_overrides_fn
        self.train_fn = train_fn
        self.reports: List[dict] = []

    def run(self) -> List[dict]:
        ladder_cfg = (self.base_cfg.get("training", {}).get("ladder", {}) or {})
        stages: Sequence[dict] = ladder_cfg.get("stages") or [self._default_stage()]
        restart_policy = ladder_cfg.get("restart_policy", "carry_state")
        carry_state = restart_policy != "from_scratch"
        model = None
        optimizer = None
        policy_net = None
        reports: List[dict] = []

        for idx, stage in enumerate(stages):
            stage_cfg = self._prepare_stage_cfg(stage)
            stage_device = torch.device(stage_cfg.get("training", {}).get("device", self.device))
            num_steps = int(stage_cfg.get("annealing", {}).get("total_steps", 1000))

            if (not carry_state) or model is None:
                model, optimizer = self.build_model_fn(stage_cfg, stage_device)
                policy_net = None
            else:
                model = model.to(stage_device)
            grids = build_action_grids(stage_cfg)
            action_sizes = (
                len(grids["tau_values"]),
                len(grids["delta_values"]),
                len(grids["kact_values"]),
                len(grids["mode_values"]),
            )
            if (policy_net is None) or (tuple(action_sizes) != getattr(policy_net, "action_sizes", tuple())):
                policy_net = PolicyNet(action_sizes=action_sizes)

            lambda_scheduler = make_lambda_scheduler(stage_cfg)
            egm_cfg = stage_cfg.get("egm", {}) or {}
            egm_handler = EGMHandler(endpoint=egm_cfg.get("endpoint", ""), api_key=egm_cfg.get("api_key"))
            env = ConfigEnv(
                model=model,
                optimizer=optimizer,
                cfg=stage_cfg,
                egm_handler=egm_handler,
                lambda_scheduler=lambda_scheduler,
                device=stage_device,
            )
            self.train_fn(env, policy_net, num_steps=num_steps, lr=3e-4, device=stage_device)
            flops_ratio = None
            try:
                flops_ratio, _, _ = env._gather_model_stats()
            except Exception:
                flops_ratio = None
            report = {
                "stage_index": idx,
                "preset": stage_cfg.get("preset", self.base_cfg.get("preset", "reference_v1")),
                "total_steps": num_steps,
                "acc": env.prev_metrics.get("acc", 0.0),
                "flops_ratio": flops_ratio,
                "model_id": id(model) if model is not None else None,
            }
            reports.append(report)

        self.reports = reports
        return reports

    def _default_stage(self) -> dict:
        return {
            "preset": self.base_cfg.get("preset", "reference_v1"),
            "total_steps": self.base_cfg.get("annealing", {}).get("total_steps", 1000),
            "summary_log_steps": self.base_cfg.get("training", {}).get("summary_log_steps", 500),
        }

    def _prepare_stage_cfg(self, stage: dict) -> dict:
        cfg = copy.deepcopy(self.base_cfg)
        training_cfg = cfg.setdefault("training", {})
        ladder_cfg = training_cfg.setdefault("ladder", {})
        ladder_cfg["enabled"] = False  # prevent recursion
        if "preset" in stage:
            cfg["preset"] = stage["preset"]
        if "summary_log_steps" in stage:
            training_cfg["summary_log_steps"] = stage["summary_log_steps"]
        if "total_steps" in stage:
            cfg.setdefault("annealing", {})["total_steps"] = stage["total_steps"]
        for key, value in stage.items():
            if key in {"preset", "summary_log_steps", "total_steps"}:
                continue
            cfg[key] = copy.deepcopy(value)
        cfg = self.apply_preset_fn(cfg)
        cfg = self.apply_mode_overrides_fn(cfg)
        return cfg

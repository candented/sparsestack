from __future__ import annotations

from typing import Tuple
from pathlib import Path
import json

import torch
from torch.distributions import Categorical

from rl.config_space import ConfigAction
from rl.summary_logger import SummaryLogger


def select_action(policy_net, state: torch.Tensor) -> Tuple[ConfigAction, torch.Tensor]:
    tau_logits, delta_logits, kact_logits, mode_logits = policy_net(state.unsqueeze(0))
    tau_dist = Categorical(logits=tau_logits.squeeze(0))
    delta_dist = Categorical(logits=delta_logits.squeeze(0))
    kact_dist = Categorical(logits=kact_logits.squeeze(0))
    mode_dist = Categorical(logits=mode_logits.squeeze(0))

    tau_idx = tau_dist.sample()
    delta_idx = delta_dist.sample()
    kact_idx = kact_dist.sample()
    mode_idx = mode_dist.sample()

    logp = (
        tau_dist.log_prob(tau_idx)
        + delta_dist.log_prob(delta_idx)
        + kact_dist.log_prob(kact_idx)
        + mode_dist.log_prob(mode_idx)
    )

    action = ConfigAction(
        tau_idx=int(tau_idx.item()),
        delta_idx=int(delta_idx.item()),
        kact_idx=int(kact_idx.item()),
        mode_idx=int(mode_idx.item()),
    )
    return action, logp


def train_phase2(env, policy_net, num_steps: int, lr: float, device: torch.device) -> None:
    optimizer = torch.optim.Adam(policy_net.parameters(), lr=lr)
    policy_net.to(device)
    state = env.reset()
    training_cfg = env.cfg.get("training", {})
    summary_log_steps = int(training_cfg.get("summary_log_steps", 500))
    summary_logger = SummaryLogger(
        window=100,
        log_every=summary_log_steps,
        track_delta=bool(training_cfg.get("log_prediction_delta_summaries", False)),
    )
    
    # Checkpoint configuration
    checkpoint_interval = int(training_cfg.get("checkpoint_interval", 2500))
    save_checkpoints = training_cfg.get("save_checkpoints", True)
    preset_name = env.cfg.get("preset", "unknown")
    seed = training_cfg.get("seed", 42)

    for step in range(num_steps):
        action, logp = select_action(policy_net, state.to(device))
        next_state, reward, done, info = env.step(action)
        loss = -logp * reward
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        state = next_state

        info["reward"] = reward
        if hasattr(env, "last_delta_ratio"):
            info["delta_ratio"] = env.last_delta_ratio
        action_cfg = env.decode_config(action)
        summary_logger.update(step + 1, info, action_cfg)

        if (step + 1) % 100 == 0:
            print(
                f"step={step + 1} reward={reward:.4f} acc={info['acc']:.4f} "
                f"ref_acc={info['ref_acc']:.4f} lambdas={info['lambdas']}"
            )
        if (step + 1) % 500 == 0:
            cfg_vals = env.decode_config(action)
            print(
                f"[DEBUG] step={step + 1} tau={cfg_vals['tau']:.2f} "
                f"delta={cfg_vals['delta']:.3f} k_act={cfg_vals['k_act']:.2f}"
            )
            lambdas = info["lambdas"]
            print(
                f"[DEBUG] step={step + 1} acc={info['acc']:.4f} ref_acc={info['ref_acc']:.4f} "
                f"flops={info['flops_ratio']:.3f} flops_ref={info['flops_ratio_ref']:.3f}"
            )
            print(
                f"[DEBUG] step={step + 1} lambdas="
                f"{lambdas.get('lambda_conn', 0.0):.3f},"
                f"{lambdas.get('lambda_act', 0.0):.3f},"
                f"{lambdas.get('lambda_prec', 0.0):.3f}"
            )
        
        # Periodic checkpoint saving
        if save_checkpoints and checkpoint_interval > 0 and (step + 1) % checkpoint_interval == 0:
            _save_checkpoint(
                env=env,
                policy_net=policy_net,
                optimizer=optimizer,
                step=step + 1,
                preset_name=preset_name,
                seed=seed,
                is_final=False
            )
        
        if done:
            state = env.reset()
    
    # Save final checkpoint
    if save_checkpoints:
        _save_checkpoint(
            env=env,
            policy_net=policy_net,
            optimizer=optimizer,
            step=num_steps,
            preset_name=preset_name,
            seed=seed,
            is_final=True
        )


def _save_checkpoint(env, policy_net, optimizer, step: int, preset_name: str, seed: int, is_final: bool = False):
    """Save model checkpoint with all necessary state for inference and continued training."""
    
    # Create checkpoint directory
    if is_final:
        checkpoint_dir = Path("checkpoints") / preset_name / f"seed{seed}" / "final"
    else:
        checkpoint_dir = Path("checkpoints") / preset_name / f"seed{seed}" / f"step_{step}"
    
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    # Save model and training state
    checkpoint_path = checkpoint_dir / "checkpoint.pt"
    torch.save({
        'step': step,
        'model_state_dict': env.model.state_dict(),
        'optimizer_state_dict': env.optimizer.state_dict(),
        'policy_net_state_dict': policy_net.state_dict(),
        'policy_optimizer_state_dict': optimizer.state_dict(),
        'preset_name': preset_name,
        'seed': seed,
    }, checkpoint_path)
    
    # Save configuration as JSON for easy inspection
    config_path = checkpoint_dir / "config.json"
    with open(config_path, 'w') as f:
        json.dump(env.cfg, f, indent=2)
    
    # Save model architecture info for inference
    model_info_path = checkpoint_dir / "model_info.json"
    model_cfg = env.cfg.get("model", {})
    model_info = {
        'arch': model_cfg.get('arch', 'sparse_transformer'),
        'vocab_size': model_cfg.get('vocab_size', 128),
        'dim': model_cfg.get('dim', 64),
        'num_heads': model_cfg.get('num_heads', 2),
        'mlp_hidden_dim': model_cfg.get('mlp_hidden_dim', 128),
        'num_classes': model_cfg.get('num_classes', 2),
        'seq_len': model_cfg.get('seq_len', 32),
        'num_layers': model_cfg.get('num_layers', 1),
        'quant_threshold': model_cfg.get('quant_threshold', 0.05),
        'gate_fc1': model_cfg.get('gate_fc1', True),
        'gate_fc2': model_cfg.get('gate_fc2', False),
        'gate_score_mode': model_cfg.get('gate_score_mode', 'heuristic_v0'),
    }
    with open(model_info_path, 'w') as f:
        json.dump(model_info, f, indent=2)
    
    checkpoint_type = "FINAL" if is_final else "PERIODIC"
    print(f"[CHECKPOINT] {checkpoint_type} checkpoint saved to {checkpoint_dir}")
    print(f"[CHECKPOINT]   - Model weights: checkpoint.pt")
    print(f"[CHECKPOINT]   - Configuration: config.json")
    print(f"[CHECKPOINT]   - Model info: model_info.json")


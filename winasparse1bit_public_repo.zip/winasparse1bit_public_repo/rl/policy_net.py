from __future__ import annotations

from typing import Dict, Sequence, Tuple

import torch
import torch.nn as nn


class PolicyNet(nn.Module):
    """Simple feed-forward policy with separate heads."""

    def __init__(self, state_dim: int = 8, hidden_dim: int = 64, action_sizes: Sequence[int] | None = None) -> None:
        super().__init__()
        if action_sizes is None:
            action_sizes = (3, 3, 3, 2)
        if len(action_sizes) != 4:
            raise ValueError("action_sizes must contain four entries")
        self.action_sizes = tuple(int(size) for size in action_sizes)
        self.trunk = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.tau_head = nn.Linear(hidden_dim, self.action_sizes[0])
        self.delta_head = nn.Linear(hidden_dim, self.action_sizes[1])
        self.kact_head = nn.Linear(hidden_dim, self.action_sizes[2])
        self.mode_head = nn.Linear(hidden_dim, self.action_sizes[3])

    def forward(self, state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        features = self.trunk(state)
        return (
            self.tau_head(features),
            self.delta_head(features),
            self.kact_head(features),
            self.mode_head(features),
        )

    def action_sizes_dict(self) -> Dict[str, int]:
        return {
            "tau": self.action_sizes[0],
            "delta": self.action_sizes[1],
            "k_act": self.action_sizes[2],
            "mode": self.action_sizes[3],
        }

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class ConfigAction:
    tau_idx: int
    delta_idx: int
    kact_idx: int
    mode_idx: int


def build_action_grids(cfg: Dict[str, object]) -> Dict[str, List[object]]:
    space = cfg.get("action_space", {})
    grids = {
        "tau_values": [float(value) for value in space.get("tau_global", [])],
        "delta_values": [float(value) for value in space.get("delta", [])],
        "kact_values": [float(value) for value in space.get("k_act", [])],
        "mode_values": list(space.get("mode", [])),
    }
    for name, values in grids.items():
        if len(values) == 0:
            raise ValueError(f"Action grid '{name}' is empty; check config/preset action_space for required entries")
    return grids


def decode_action(action: ConfigAction, grids: Dict[str, List[object]]) -> Dict[str, object]:
    return {
        "tau": grids["tau_values"][action.tau_idx],
        "delta": grids["delta_values"][action.delta_idx],
        "k_act": grids["kact_values"][action.kact_idx],
        "mode": grids["mode_values"][action.mode_idx],
    }

from __future__ import annotations

from collections import Counter, deque
from typing import Deque, Dict, Iterable, Tuple


class SummaryLogger:
    def __init__(self, window: int = 100, log_every: int = 500, track_delta: bool = False) -> None:
        self.window = window
        self.log_every = log_every
        self.history: Deque[Dict[str, float]] = deque(maxlen=window)
        self.actions: Deque[Tuple[float, float, float]] = deque(maxlen=window)
        self.track_delta = track_delta
        self.delta_history: Deque[float] = deque(maxlen=window)

    def update(self, step: int, info: Dict[str, float], action_cfg: Dict[str, float]) -> None:
        record = {
            "flops_ratio": info.get("flops_ratio", 0.0),
            "conn_sparsity": info.get("conn_sparsity", 0.0),
            "k_act": action_cfg.get("k_act", 0.0),
            "reward": info.get("reward", 0.0),
            "acc": info.get("acc", 0.0),
            "ref_acc": info.get("ref_acc", 0.0),
        }
        self.history.append(record)
        self.actions.append(
            (
                action_cfg.get("tau", 0.0),
                action_cfg.get("delta", 0.0),
                action_cfg.get("k_act", 0.0),
            )
        )
        if self.track_delta and "delta_ratio" in info and info["delta_ratio"] is not None:
            self.delta_history.append(info["delta_ratio"])
        if self.log_every > 0 and (step % self.log_every == 0):
            self.log(step, info)

    def _mean(self, key: str) -> float:
        if not self.history:
            return 0.0
        return sum(rec.get(key, 0.0) for rec in self.history) / len(self.history)

    def _dominant_action(self) -> Tuple[float, float, float]:
        if not self.actions:
            return 0.0, 0.0, 0.0
        counter = Counter(self.actions)
        return counter.most_common(1)[0][0]

    def log(self, step: int, info: Dict[str, float]) -> None:
        tau, delta, k_act = self._dominant_action()
        delta_term = ""
        if self.track_delta and self.delta_history:
            mean_delta = sum(self.delta_history) / len(self.delta_history)
            delta_term = f" mean_delta={mean_delta:.4f}"
        print(
            f"[SUMMARY] step={step} mean_flops={self._mean('flops_ratio'):.3f} "
            f"mean_conn={self._mean('conn_sparsity'):.3f} mean_k_act={self._mean('k_act'):.3f} "
            f"mean_reward={self._mean('reward'):.4f} mean_acc={self._mean('acc'):.4f} "
            f"ref_acc={self._mean('ref_acc'):.4f} flops_ref={info.get('flops_ratio_ref', 0.0):.3f} "
            f"dom_action=(tau={tau:.2f}, delta={delta:.3f}, k_act={k_act:.2f}){delta_term}"
        )

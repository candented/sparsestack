from __future__ import annotations

import torch
import torch.nn as nn

from sparse_llm.layers import LowBitLinear
from sparse_llm.mlp import WINA_MLP
from sparse_llm.oct_layers import RotationalLinear


def apply_config_to_model(model: nn.Module, config_values: dict) -> None:
    tau = float(config_values.get("tau", 0.0))
    delta = float(config_values.get("delta", 0.0))
    k_act = float(config_values.get("k_act", 0.0))

    for module in model.modules():
        if isinstance(module, LowBitLinear):
            module.delta = delta

    for module in model.modules():
        if isinstance(module, WINA_MLP):
            module.k_act = float(k_act)

    for module in model.modules():
        if isinstance(module, LowBitLinear):
            _apply_tau_to_lowbitlinear(module, tau)
        elif isinstance(module, RotationalLinear):
            module.apply_tau(tau)


def _apply_tau_to_lowbitlinear(layer: LowBitLinear, tau: float) -> None:
    with torch.no_grad():
        tau = float(max(0.0, min(1.0, tau)))
        weight = layer.weight
        base_mask = layer.mask
        masked = weight * base_mask
        permitted = base_mask != 0
        abs_vals = masked.abs()
        num_permitted = int(permitted.sum().item())
        if num_permitted == 0:
            runtime_mask = torch.zeros_like(base_mask)
        else:
            keep = max(1, int(round(tau * num_permitted)))
            flat_vals = abs_vals[permitted]
            if keep >= num_permitted:
                threshold = flat_vals.min()
            else:
                kth_index = num_permitted - keep + 1
                threshold, _ = torch.kthvalue(flat_vals, kth_index)
            runtime_mask = torch.zeros_like(base_mask)
            runtime_mask[permitted & (abs_vals >= threshold)] = 1.0
        if "runtime_mask" in layer._buffers:
            layer.runtime_mask.copy_(runtime_mask)
        else:
            layer.register_buffer("runtime_mask", runtime_mask)

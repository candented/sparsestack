from __future__ import annotations

import sys

import torch
import random
import numpy as np
import torch
import yaml

from config.loader import load_config
from rl.config_space import build_action_grids
from rl.env import ConfigEnv
from rl.lambda_scheduler import make_lambda_scheduler
from rl.policy_net import PolicyNet
from rl.trainer import train_phase2
from sparse_llm.transformer import SparseTransformer
from sparse_llm.oct_layers import OctModel
from sparse_llm.tiny_transformer import TinyTransformer
from rl.ladder import LadderController
from utils import EGMHandler


def build_model_and_optimizer(cfg: dict, device: torch.device):
    task_family = cfg.get("training", {}).get("task_family", "symbolic")
    if task_family == "oct":
        model = OctModel(dim=cfg.get("model", {}).get("oct_dim", 128)).to(device)
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
        return model, optimizer
    model_arch = cfg.get("model", {}).get("arch", "sparse_transformer")
    seq_len = cfg.get("model", {}).get("seq_len", 32)
    vocab_size = cfg.get("model", {}).get("vocab_size", 128)
    dim = cfg.get("model", {}).get("dim", 64)
    num_heads = cfg.get("model", {}).get("num_heads", 2)
    mlp_hidden_dim = cfg.get("model", {}).get("mlp_hidden_dim", 128)
    num_classes = cfg.get("model", {}).get("num_classes", 2)
    quant_threshold = cfg.get("model", {}).get("quant_threshold", 0.05)
    gate_fc1 = cfg.get("model", {}).get("gate_fc1", True)
    gate_fc2 = cfg.get("model", {}).get("gate_fc2", False)
    gate_score_mode = cfg.get("model", {}).get("gate_score_mode", "heuristic_v0")
    num_blocks = cfg.get("model", {}).get("num_layers", cfg.get("model", {}).get("num_blocks", 1))
    if model_arch == "tiny_transformer":
        model = TinyTransformer(
            vocab_size=vocab_size,
            dim=dim,
            num_heads=num_heads,
            mlp_hidden_dim=mlp_hidden_dim,
            num_classes=num_classes,
            seq_len=seq_len,
            quant_threshold=quant_threshold,
            gate_fc1=gate_fc1,
            gate_fc2=gate_fc2,
            gate_score_mode=gate_score_mode,
            num_blocks=num_blocks if num_blocks is not None else 2,
        ).to(device)
    elif model_arch == "sparse_transformer":
        model = SparseTransformer(
            vocab_size=vocab_size,
            dim=dim,
            num_heads=num_heads,
            mlp_hidden_dim=mlp_hidden_dim,
            num_classes=num_classes,
            seq_len=seq_len,
            quant_threshold=quant_threshold,
            gate_fc1=gate_fc1,
            gate_fc2=gate_fc2,
            gate_score_mode=gate_score_mode,
            num_blocks=num_blocks if num_blocks is not None else 1,
        ).to(device)
    else:
        raise ValueError(f"Unknown model.arch: {model_arch}")
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    return model, optimizer


def apply_preset(cfg: dict) -> dict:
    presets = cfg.get("presets", {})
    preset_name = cfg.get("preset", "reference_v1")
    if presets and preset_name not in presets:
        raise ValueError(f"Unknown preset: {preset_name}")
    preset_cfg = presets.get(preset_name, {}) if presets else {}

    def _merge_section(base: dict, override: dict | None) -> dict:
        merged = dict(base or {})
        if override:
            merged.update(override)
        return merged

    if "reward" in preset_cfg:
        cfg["reward"] = _merge_section(cfg.get("reward", {}), preset_cfg.get("reward"))
    if "action_space" in preset_cfg:
        cfg["action_space"] = _merge_section(cfg.get("action_space", {}), preset_cfg.get("action_space"))
    if "prediction_delta" in preset_cfg:
        cfg["prediction_delta"] = _merge_section(cfg.get("prediction_delta", {}), preset_cfg.get("prediction_delta"))
    if "training" in preset_cfg:
        cfg["training"] = _merge_section(cfg.get("training", {}), preset_cfg.get("training"))
    if "model" in preset_cfg:
        cfg["model"] = _merge_section(cfg.get("model", {}), preset_cfg.get("model"))
    _validate_prediction_delta_actions(cfg, preset_name)
    return cfg


def _validate_prediction_delta_actions(cfg: dict, preset_name: str) -> None:
    grids = build_action_grids(cfg)
    pd_cfg = cfg.get("prediction_delta", {}) or {}

    def _assert_in_grid(action: dict | None, label: str) -> None:
        if not action:
            return
        if "tau" in action and action["tau"] not in grids["tau_values"]:
            raise ValueError(f"Preset '{preset_name}': {label}.tau={action['tau']} not in grid {grids['tau_values']}")
        if "delta" in action and action["delta"] not in grids["delta_values"]:
            raise ValueError(f"Preset '{preset_name}': {label}.delta={action['delta']} not in grid {grids['delta_values']}")
        if "k_act" in action and action["k_act"] not in grids["kact_values"]:
            raise ValueError(f"Preset '{preset_name}': {label}.k_act={action['k_act']} not in grid {grids['kact_values']}")
        if "mode" in action and action["mode"] not in grids["mode_values"]:
            raise ValueError(f"Preset '{preset_name}': {label}.mode={action['mode']} not in grid {grids['mode_values']}")

    _assert_in_grid(pd_cfg.get("ref_action"), "prediction_delta.ref_action")
    _assert_in_grid(pd_cfg.get("extreme_action"), "prediction_delta.extreme_action")


def apply_overrides(cfg: dict, argv: list[str]) -> dict:
    allowed_keys = _collect_allowed_keys(cfg)
    allowed_keys.add("preset")  # allow selecting preset even though it is not in the base yaml
    pending: list[tuple[str, str]] = []
    for arg in argv:
        if "=" not in arg:
            continue
        key, value = arg.split("=", 1)
        pending.append((key, value))
    for key, _ in pending:
        if key not in allowed_keys:
            print(f"DEBUG: cfg keys: {list(cfg.keys())}")
            if "training" in cfg:
                print(f"DEBUG: cfg['training']: {cfg['training']}")
            print(f"DEBUG: allowed_keys sample: {list(allowed_keys)[:10]}")
            print(f"DEBUG: 'training.seed' in allowed: {'training.seed' in allowed_keys}")
            raise ValueError(f"Unknown override key: {key}")
    for key, value in pending:
        target = cfg
        parts = key.split(".")
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        target[parts[-1]] = yaml.safe_load(value)
    return cfg


def _collect_allowed_keys(cfg: dict, prefix: str | None = None) -> set[str]:
    allowed: set[str] = set()
    for key, value in cfg.items():
        path = f"{prefix}.{key}" if prefix else key
        allowed.add(path)
        if isinstance(value, dict):
            allowed.update(_collect_allowed_keys(value, path))
    return allowed


def apply_mode_overrides(cfg: dict) -> dict:
    mode = cfg.get("training", {}).get("mode", "full")
    if mode == "fast_debug":
        cfg.setdefault("annealing", {})["total_steps"] = 2000
        training_cfg = cfg.setdefault("training", {})
        training_cfg["summary_log_steps"] = 1000
        training_cfg["debug_scan_actions"] = False
        training_cfg["debug_prediction_delta"] = False
        training_cfg["log_prediction_delta_summaries"] = False
        training_cfg["debug_weights_every"] = 0
    return cfg


def main() -> None:
    cfg = load_config()
    cfg = apply_overrides(cfg, sys.argv[1:])
    cfg = apply_preset(cfg)
    cfg = apply_mode_overrides(cfg)

    # Set seed
    seed = cfg.get("training", {}).get("seed", 42)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    device = torch.device(cfg.get("training", {}).get("device", "cpu"))
    ladder_cfg = cfg.get("training", {}).get("ladder", {}) or {}
    if ladder_cfg.get("enabled", False):
        controller = LadderController(
            base_cfg=cfg,
            device=device,
            build_model_fn=build_model_and_optimizer,
            apply_preset_fn=apply_preset,
            apply_mode_overrides_fn=apply_mode_overrides,
        )
        reports = controller.run()
        for rep in reports:
            flops = rep.get("flops_ratio")
            flops_str = f"{flops:.3f}" if flops is not None else "n/a"
            print(
                f"[LADDER] stage={rep.get('stage_index', -1)} "
                f"preset={rep.get('preset', 'unknown')} steps={rep.get('total_steps', 0)} "
                f"acc={rep.get('acc', 0.0):.4f} flops={flops_str}"
            )
        return

    model, optimizer = build_model_and_optimizer(cfg, device)

    egm_cfg = cfg.get("egm", {})
    egm_handler = EGMHandler(endpoint=egm_cfg.get("endpoint", ""), api_key=egm_cfg.get("api_key"))
    lambda_scheduler = make_lambda_scheduler(cfg)

    env = ConfigEnv(
        model=model,
        optimizer=optimizer,
        cfg=cfg,
        egm_handler=egm_handler,
        lambda_scheduler=lambda_scheduler,
        device=device,
    )

    if cfg.get("training", {}).get("debug_scan_actions", False):
        env.debug_scan_action_grid()
    if cfg.get("training", {}).get("debug_prediction_delta", False):
        env.debug_prediction_delta()

    diagnostics_cfg = cfg.get("diagnostics", {}) or {}
    if diagnostics_cfg.get("save_interpretability", False):
        env.write_interpretability_snapshot(
            log_dir=diagnostics_cfg.get("interpretability_log_dir", "logs/interpretability"),
            preset_name=cfg.get("preset", "unknown"),
        )
    if diagnostics_cfg.get("save_scan", False):
        scan_data = env.debug_scan_action_grid_with_data(return_data=True)
        if scan_data:
            env.write_scan_snapshot(
                scan_data,
                log_dir=diagnostics_cfg.get("interpretability_log_dir", "logs/interpretability"),
                preset_name=cfg.get("preset", "unknown"),
            )

    grids = build_action_grids(cfg)
    action_sizes = (
        len(grids["tau_values"]),
        len(grids["delta_values"]),
        len(grids["kact_values"]),
        len(grids["mode_values"]),
    )
    policy_net = PolicyNet(action_sizes=action_sizes)

    num_steps = int(cfg.get("annealing", {}).get("total_steps", 1000))
    train_phase2(env, policy_net, num_steps=num_steps, lr=3e-4, device=device)


if __name__ == "__main__":
    main()

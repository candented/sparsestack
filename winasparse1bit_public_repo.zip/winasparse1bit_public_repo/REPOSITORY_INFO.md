# WINASPARSE1BIT Public Repository

This repository accompanies the paper:

**"WINASPARSE1BIT: A Triple-Sparse Transformer Architecture Achieving 15× Efficiency via Weight-Informed Neuron Activation"**

by J B Swann (Independent Research)

## Repository Contents

This is a **clean, sanitized version** of the research codebase containing only files necessary for:
- Reproducing paper results
- Scientific review and verification
- Understanding the architecture
- Training new models

**What's included**:
- ✅ Core source code (`sparse_llm/`, `rl/`)
- ✅ Training scripts (`main.py`)
- ✅ Configuration files (`config/`)
- ✅ Dataset generation tools (`tools/`)
- ✅ Paper LaTeX source (`docs/`)
- ✅ Documentation and examples

**What's excluded**:
- ❌ Personal information
- ❌ API keys or credentials
- ❌ Experiment logs and checkpoints (too large)
- ❌ Development/debugging scripts
- ❌ Private notes and internal documentation

## Getting Started

See [README.md](README.md) for:
- Installation instructions
- Quick start guide
- Reproducing paper results
- Architecture details

## Verification

To verify the paper results:

1. Generate dataset: `python tools/generate_lexical_deep.py`
2. Train Phase 8 model: `python main.py preset=model_zero_scaled_v1`
3. Expected: 78.91% accuracy, 0.066 FLOPs, 88.4% sparsity

## Citation

```bibtex
@article{swann2026winasparse1bit,
  title={WINASPARSE1BIT: A Triple-Sparse Transformer Architecture Achieving 15× Efficiency via Weight-Informed Neuron Activation},
  author={Swann, J B},
  journal={arXiv preprint arXiv:XXXX.XXXXX},
  year={2026}
}
```

## License

MIT License - See [LICENSE](LICENSE)

## Contact

For questions about the paper or code, please open an issue on GitHub.

---

**Note**: This is a public research repository. The original development repository contains additional experimental code, logs, and checkpoints not included here for brevity and privacy.

"""
Phase 9c: Deep Lexical Dataset Generation via WordNet Graph Traversal
======================================================================

Objective: Generate >100,000 structured logic pairs by mining the full graph
structure of WordNet (117,000+ synsets) to achieve 10:1 data-to-parameter ratio
for model_zero_scaled_v2_dim512.

Graph Traversal Strategies:
1. Hypernym/Hyponym Chains: Logical entailment pairs
2. Meronym/Holonym Relations: Part-whole relationships
3. Synset Traversal: Synonym/antonym pairs beyond standard lemmas
4. Coordinate Terms: Classification tasks via shared hypernyms

Output: data/lexical_real_deep_v1.jsonl
"""

import json
import random
from collections import defaultdict
from typing import List, Dict, Set, Tuple
from pathlib import Path

try:
    from nltk.corpus import wordnet as wn
except ImportError:
    print("ERROR: nltk not installed. Run: pip install nltk")
    exit(1)


class WordNetDeepGenerator:
    """Generate diverse logic pairs from WordNet graph structure."""
    
    def __init__(self, seed: int = 42):
        self.seed = seed
        random.seed(seed)
        self.generated_pairs: Set[Tuple[str, str]] = set()  # For deduplication
        self.stats = defaultdict(int)
        
    def deduplicate(self, input_text: str, target_text: str) -> bool:
        """Check if this pair has already been generated."""
        pair = (input_text.lower().strip(), target_text.lower().strip())
        if pair in self.generated_pairs:
            return False
        self.generated_pairs.add(pair)
        return True
    
    def create_example(self, input_text: str, target_text: str, category: str) -> Dict:
        """Create a standardized example with deduplication."""
        if not self.deduplicate(input_text, target_text):
            return None
        
        self.stats[category] += 1
        return {
            "input": input_text,
            "target": target_text,
            "category": category
        }
    
    # ========================================================================
    # 1. HYPERNYM/HYPONYM CHAINS: Logical Entailment
    # ========================================================================
    
    def generate_hypernym_entailment(self, max_examples: int = 30000) -> List[Dict]:
        """Generate 'Is X a Y?' entailment questions from hypernym chains."""
        examples = []
        print(f"[1/4] Generating hypernym entailment pairs (target: {max_examples})...")
        
        # Pre-cache all synsets to avoid repeated calls
        all_synsets_list = list(wn.all_synsets())
        print(f"  Processing {len(all_synsets_list)} synsets...")
        
        synset_count = 0
        for synset in all_synsets_list:
            if len(examples) >= max_examples:
                break
            
            synset_count += 1
            if synset_count % 10000 == 0:
                print(f"  Progress: {synset_count}/{len(all_synsets_list)} synsets, {len(examples)} examples generated")
                
            # Get direct hypernyms only (depth=1) for speed
            hypernyms = synset.hypernyms()
            if not hypernyms:
                continue
                
            for hypernym in hypernyms[:2]:  # Limit to 2 hypernyms per synset
                # Positive examples: "Is a beagle a canine?" -> "True"
                for lemma in synset.lemmas()[:1]:  # Limit to 1 lemma
                    for hyp_lemma in hypernym.lemmas()[:1]:
                        input_text = f"Is a {lemma.name().replace('_', ' ')} a {hyp_lemma.name().replace('_', ' ')}?"
                        ex = self.create_example(input_text, "True", "hypernym_entailment_positive")
                        if ex:
                            examples.append(ex)
                            if len(examples) >= max_examples:
                                break
                
                # Negative examples: Sample random non-hypernyms
                if len(examples) < max_examples and random.random() < 0.2:  # 20% negative sampling
                    random_synset = random.choice(all_synsets_list)
                    all_hypernyms = set(synset.closure(lambda s: s.hypernyms()))
                    if random_synset not in all_hypernyms and random_synset != synset:
                        for lemma in synset.lemmas()[:1]:
                            for rand_lemma in random_synset.lemmas()[:1]:
                                input_text = f"Is a {lemma.name().replace('_', ' ')} a {rand_lemma.name().replace('_', ' ')}?"
                                ex = self.create_example(input_text, "False", "hypernym_entailment_negative")
                                if ex:
                                    examples.append(ex)
                                    break
        
        print(f"  ✓ Generated {len(examples)} hypernym entailment pairs")
        return examples
    
    # ========================================================================
    # 2. MERONYM/HOLONYM RELATIONS: Part-Whole Relationships
    # ========================================================================
    
    def generate_meronym_relations(self, max_examples: int = 20000) -> List[Dict]:
        """Generate part-whole relationship questions."""
        examples = []
        print(f"[2/4] Generating meronym/holonym pairs (target: {max_examples})...")
        
        all_synsets_list = list(wn.all_synsets())
        synset_count = 0
        
        for synset in all_synsets_list:
            if len(examples) >= max_examples:
                break
            
            synset_count += 1
            if synset_count % 10000 == 0:
                print(f"  Progress: {synset_count}/{len(all_synsets_list)} synsets, {len(examples)} examples generated")
            
            # Part meronyms: "What are the parts of X?"
            part_meronyms = synset.part_meronyms()
            if len(part_meronyms) >= 2:
                parts = [m.lemmas()[0].name().replace('_', ' ') for m in part_meronyms[:5]]
                whole = synset.lemmas()[0].name().replace('_', ' ')
                
                input_text = f"What are the components of a {whole}?"
                target_text = ", ".join(parts)
                ex = self.create_example(input_text, target_text, "part_meronym")
                if ex:
                    examples.append(ex)
            
            # Member holonyms: "What is X a member of?"
            member_holonyms = synset.member_holonyms()
            for holonym in member_holonyms:
                member = synset.lemmas()[0].name().replace('_', ' ')
                group = holonym.lemmas()[0].name().replace('_', ' ')
                
                input_text = f"What group does a {member} belong to?"
                target_text = group
                ex = self.create_example(input_text, target_text, "member_holonym")
                if ex:
                    examples.append(ex)
            
            # Substance meronyms: "What is X made of?"
            substance_meronyms = synset.substance_meronyms()
            if substance_meronyms:
                substance = substance_meronyms[0].lemmas()[0].name().replace('_', ' ')
                whole = synset.lemmas()[0].name().replace('_', ' ')
                
                input_text = f"What is a {whole} made of?"
                target_text = substance
                ex = self.create_example(input_text, target_text, "substance_meronym")
                if ex:
                    examples.append(ex)
        
        print(f"  ✓ Generated {len(examples)} meronym/holonym pairs")
        return examples
    
    # ========================================================================
    # 3. SYNSET TRAVERSAL: Deep Synonym/Antonym Mining
    # ========================================================================
    
    def generate_synonym_antonym_pairs(self, max_examples: int = 30000) -> List[Dict]:
        """Generate synonym/antonym pairs by walking graph edges."""
        examples = []
        print(f"[3/4] Generating synonym/antonym pairs (target: {max_examples})...")
        
        all_synsets_list = list(wn.all_synsets())
        synset_count = 0
        
        for synset in all_synsets_list:
            if len(examples) >= max_examples:
                break
            
            synset_count += 1
            if synset_count % 10000 == 0:
                print(f"  Progress: {synset_count}/{len(all_synsets_list)} synsets, {len(examples)} examples generated")
            
            # Synonyms within synset
            lemmas = synset.lemmas()
            if len(lemmas) >= 2:
                for i, lemma1 in enumerate(lemmas[:4]):
                    for lemma2 in lemmas[i+1:5]:
                        word1 = lemma1.name().replace('_', ' ')
                        word2 = lemma2.name().replace('_', ' ')
                        
                        input_text = f"Are '{word1}' and '{word2}' synonyms?"
                        ex = self.create_example(input_text, "Yes", "synonym_positive")
                        if ex:
                            examples.append(ex)
            
            # Antonyms via lemma.antonyms()
            for lemma in lemmas[:3]:
                antonyms = lemma.antonyms()
                for antonym in antonyms:
                    word1 = lemma.name().replace('_', ' ')
                    word2 = antonym.name().replace('_', ' ')
                    
                    input_text = f"Are '{word1}' and '{word2}' antonyms?"
                    ex = self.create_example(input_text, "Yes", "antonym_positive")
                    if ex:
                        examples.append(ex)
                    
                    # Also generate synonym negative
                    input_text = f"Are '{word1}' and '{word2}' synonyms?"
                    ex = self.create_example(input_text, "No", "synonym_negative")
                    if ex:
                        examples.append(ex)
            
            # Similar-to relations (for adjectives)
            similar_tos = synset.similar_tos()
            for similar in similar_tos:
                word1 = synset.lemmas()[0].name().replace('_', ' ')
                word2 = similar.lemmas()[0].name().replace('_', ' ')
                
                input_text = f"Is '{word1}' similar to '{word2}'?"
                ex = self.create_example(input_text, "Yes", "similar_to")
                if ex:
                    examples.append(ex)
        
        print(f"  ✓ Generated {len(examples)} synonym/antonym pairs")
        return examples
    
    # ========================================================================
    # 4. COORDINATE TERMS: Classification via Shared Hypernyms
    # ========================================================================
    
    def generate_coordinate_classification(self, max_examples: int = 25000) -> List[Dict]:
        """Generate 'odd one out' classification tasks."""
        examples = []
        print(f"[4/4] Generating coordinate term classification (target: {max_examples})...")
        
        all_synsets_list = list(wn.all_synsets())
        synset_count = 0
        
        for synset in all_synsets_list:
            if len(examples) >= max_examples:
                break
            
            synset_count += 1
            if synset_count % 10000 == 0:
                print(f"  Progress: {synset_count}/{len(all_synsets_list)} synsets, {len(examples)} examples generated")
            
            # Get coordinate terms (siblings with same hypernym)
            hypernyms = synset.hypernyms()
            if not hypernyms:
                continue
            
            parent = hypernyms[0]
            siblings = parent.hyponyms()
            
            if len(siblings) >= 4:
                # Create "odd one out" task
                siblings_sample = random.sample(siblings, min(4, len(siblings)))
                
                # Get random unrelated synset
                random_synset = random.choice(list(wn.all_synsets()))
                if random_synset not in siblings and random_synset != synset:
                    
                    # Build list with 3 siblings + 1 unrelated
                    related = [s.lemmas()[0].name().replace('_', ' ') for s in siblings_sample[:3]]
                    unrelated = random_synset.lemmas()[0].name().replace('_', ' ')
                    
                    options = related + [unrelated]
                    random.shuffle(options)
                    
                    input_text = f"Which word does not belong: {', '.join(options)}?"
                    target_text = unrelated
                    ex = self.create_example(input_text, target_text, "odd_one_out")
                    if ex:
                        examples.append(ex)
            
            # Also generate category membership questions
            if len(siblings) >= 2:
                category = parent.lemmas()[0].name().replace('_', ' ')
                member = synset.lemmas()[0].name().replace('_', ' ')
                
                input_text = f"Is '{member}' a type of {category}?"
                ex = self.create_example(input_text, "Yes", "category_membership_positive")
                if ex:
                    examples.append(ex)
                
                # Negative example
                if random.random() < 0.5:
                    random_synset = random.choice(list(wn.all_synsets()))
                    if random_synset not in siblings:
                        non_member = random_synset.lemmas()[0].name().replace('_', ' ')
                        input_text = f"Is '{non_member}' a type of {category}?"
                        ex = self.create_example(input_text, "No", "category_membership_negative")
                        if ex:
                            examples.append(ex)
        
        print(f"  ✓ Generated {len(examples)} coordinate classification pairs")
        return examples
    
    # ========================================================================
    # MAIN GENERATION PIPELINE
    # ========================================================================
    
    def generate_all(self, target_total: int = 100000) -> List[Dict]:
        """Generate all example types with balanced distribution."""
        print(f"\n{'='*70}")
        print(f"Phase 9c: WordNet Deep Dataset Generation")
        print(f"Target: {target_total:,} examples")
        print(f"{'='*70}\n")
        
        all_examples = []
        
        # Generate each category
        all_examples.extend(self.generate_hypernym_entailment(max_examples=30000))
        all_examples.extend(self.generate_meronym_relations(max_examples=20000))
        all_examples.extend(self.generate_synonym_antonym_pairs(max_examples=30000))
        all_examples.extend(self.generate_coordinate_classification(max_examples=25000))
        
        # Shuffle to mix categories
        random.shuffle(all_examples)
        
        # Trim to target if exceeded
        if len(all_examples) > target_total:
            all_examples = all_examples[:target_total]
        
        print(f"\n{'='*70}")
        print(f"Generation Complete!")
        print(f"{'='*70}")
        print(f"Total examples: {len(all_examples):,}")
        print(f"\nCategory Breakdown:")
        for category, count in sorted(self.stats.items()):
            print(f"  {category:40s}: {count:6,}")
        print(f"{'='*70}\n")
        
        return all_examples
    
    def save_to_jsonl(self, examples: List[Dict], output_path: Path):
        """Save examples to JSONL format."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            for example in examples:
                f.write(json.dumps(example, ensure_ascii=False) + '\n')
        
        print(f"✓ Dataset saved to: {output_path}")
        print(f"  File size: {output_path.stat().st_size / 1024 / 1024:.2f} MB")


def main():
    """Main execution function."""
    # Configuration
    OUTPUT_PATH = Path(__file__).parent.parent / "data" / "lexical_real_deep_v1.jsonl"
    TARGET_EXAMPLES = 100000
    SEED = 42
    
    # Initialize generator
    generator = WordNetDeepGenerator(seed=SEED)
    
    # Generate dataset
    examples = generator.generate_all(target_total=TARGET_EXAMPLES)
    
    # Save to disk
    generator.save_to_jsonl(examples, OUTPUT_PATH)
    
    # Validation report
    print(f"\n{'='*70}")
    print(f"VALIDATION REPORT")
    print(f"{'='*70}")
    print(f"✓ Target examples: {TARGET_EXAMPLES:,}")
    print(f"✓ Generated examples: {len(examples):,}")
    print(f"✓ Deduplication: {len(generator.generated_pairs):,} unique pairs")
    print(f"✓ Coverage: {len(examples) / TARGET_EXAMPLES * 100:.1f}% of target")
    
    # Calculate parameter-to-data ratio for dim=512
    dim512_params = 260000  # Approximate from Phase 9a
    ratio = dim512_params / len(examples)
    print(f"\n{'='*70}")
    print(f"PHASE 9C OBJECTIVE VERIFICATION")
    print(f"{'='*70}")
    print(f"Model: model_zero_scaled_v2_dim512")
    print(f"Parameters: ~{dim512_params:,}")
    print(f"Dataset size: {len(examples):,}")
    print(f"Parameter-to-data ratio: {ratio:.2f}:1")
    
    if ratio <= 10:
        print(f"✅ SUCCESS: Ratio ≤10:1 (Target achieved)")
    else:
        print(f"⚠️  WARNING: Ratio >{ratio:.1f}:1 (Target: ≤10:1)")
    
    print(f"{'='*70}\n")


if __name__ == "__main__":
    main()

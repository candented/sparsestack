# WINASPARSE1BIT Public Repository - File Manifest

## Repository Structure

```
winasparse1bit_public_repo/
├── README.md                    # Main documentation
├── LICENSE                      # MIT License
├── requirements.txt             # Python dependencies
├── REPOSITORY_INFO.md          # What's included/excluded
├── .gitignore                  # Git ignore rules
│
├── sparse_llm/                 # Core architecture
│   ├── __init__.py
│   ├── layers.py               # LowBitLinear (1.58-bit ternary)
│   ├── transformer.py          # SparseStack architecture
│   ├── tiny_transformer.py     # Dense baseline
│   ├── mlp.py                  # MLP components
│   ├── masks.py                # Connectivity masks
│   ├── data.py                 # Data loading
│   ├── utils.py                # Utilities
│   ├── logging_utils.py        # Logging helpers
│   └── oct_layers.py           # Octonary layers (experimental)
│
├── rl/                         # Reinforcement learning
│   ├── __init__.py
│   ├── env.py                  # RL environment (main)
│   ├── trainer.py              # REINFORCE trainer
│   ├── policy_net.py           # Policy network
│   ├── reward_fn.py            # Reward function
│   ├── config_space.py         # Configuration space
│   ├── config_applier.py       # Config application
│   ├── lambda_scheduler.py     # Lambda scheduling
│   ├── ladder.py               # Ladder mechanism
│   └── summary_logger.py       # Summary logging
│
├── config/
│   └── global_params.yaml      # All model presets
│
├── tools/
│   └── generate_lexical_deep.py # Dataset generator
│
├── data/
│   └── sample_data.jsonl       # Sample format (4 examples)
│   # Full dataset generated via tools/generate_lexical_deep.py
│   # Creates: lexical_real_deep_v1.jsonl (99,186 examples)
│
├── docs/
│   └── WINASPARSE1BIT_paper.tex # LaTeX paper source
│
└── main.py                     # Training entry point
```

## File Purposes

### Core Architecture (`sparse_llm/`)
- **layers.py**: 1.58-bit ternary linear layers with WINA gating
- **transformer.py**: SparseStack transformer with learnable masks
- **tiny_transformer.py**: Dense baseline for comparison
- **mlp.py**: Multi-layer perceptron components
- **masks.py**: Boolean connectivity mask management

### RL Training (`rl/`)
- **env.py**: Main RL environment (43KB - core logic)
- **trainer.py**: REINFORCE algorithm implementation
- **policy_net.py**: Policy network for sparsity hyperparameters
- **reward_fn.py**: Accuracy-efficiency reward function

### Configuration
- **global_params.yaml**: All model presets (Phase 7, 8, 9a)

### Tools
- **generate_lexical_deep.py**: WordNet-based dataset generator

### Documentation
- **README.md**: Installation, usage, results
- **WINASPARSE1BIT_paper.tex**: Full paper source

## What's NOT Included

For privacy and repository size:
- ❌ Training logs and checkpoints (too large)
- ❌ Experiment results and analysis
- ❌ Personal development notes
- ❌ API keys or credentials
- ❌ Full dataset (generated locally via tools)

## Generating Missing Files

**Dataset** (required for training):
```bash
python tools/generate_lexical_deep.py
# Creates: data/lexical_real_deep_v1.jsonl (99,186 examples, ~10MB)
```

**Checkpoints** (created during training):
```bash
python main.py preset=model_zero_scaled_v1
# Creates: checkpoints/model_zero_scaled_v1/
```

## Verification

Total file count (excluding generated data/checkpoints):
- Python source files: ~20
- Configuration files: 1
- Documentation files: 5
- Total repository size: ~200KB (before data generation)

All files are sanitized and contain no personal information beyond author name (J B Swann).

"""
Sparse LLM research playground.

This package groups the toy components used to prototype sparse, low-bit
transformer ideas.  Modules intentionally stay tiny and explicit so individual
pieces (quantizers, sparse layers, toy transformer blocks) can be swapped or
extended without dragging in unrelated code.
"""

from .layers import LowBitLinear, ternary_quantize
from .mlp import WINA_MLP
from .transformer import ToyTransformerBlock, SparseTransformer

__all__ = [
    "LowBitLinear",
    "ternary_quantize",
    "WINA_MLP",
    "ToyTransformerBlock",
    "SparseTransformer",
]

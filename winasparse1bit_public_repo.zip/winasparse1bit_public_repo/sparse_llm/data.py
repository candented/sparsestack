from __future__ import annotations

from typing import Tuple

import torch
from torch.utils.data import DataLoader, TensorDataset


def generate_sequence_sum_dataset(
    num_samples: int,
    seq_len: int,
    vocab_size: int,
    num_classes: int,
    seed: int,
) -> TensorDataset:
    """
    Deterministically generate a toy sequence classification dataset.

    Labels are computed as sum(tokens) % num_classes, which is simple but keeps
    the task non-trivial for very small models.
    """

    generator = torch.Generator().manual_seed(seed)
    tokens = torch.randint(0, vocab_size, (num_samples, seq_len), generator=generator)
    labels = tokens.sum(dim=1) % num_classes
    return TensorDataset(tokens, labels)


def generate_noisy_sum_mod_dataset(
    num_samples: int,
    seq_len: int,
    vocab_size: int,
    num_classes: int,
    seed: int,
    noise_prob: float = 0.1,
) -> TensorDataset:
    """
    Harder variation of the sum-mod dataset:
    - label = sum(tokens) % num_classes
    - with probability `noise_prob`, flip to a neighboring class to introduce uncertainty
    """

    generator = torch.Generator().manual_seed(seed)
    tokens = torch.randint(0, vocab_size, (num_samples, seq_len), generator=generator)
    base_labels = tokens.sum(dim=1) % num_classes

    if noise_prob > 0:
        noise_mask = torch.rand(num_samples, generator=generator) < noise_prob
        deltas = torch.randint(1, num_classes, (num_samples,), generator=generator)
        noisy_labels = (base_labels + deltas) % num_classes
        labels = torch.where(noise_mask, noisy_labels, base_labels)
    else:
        labels = base_labels

    return TensorDataset(tokens, labels)


def create_dataloader(dataset: TensorDataset, batch_size: int, shuffle: bool) -> DataLoader:
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle)

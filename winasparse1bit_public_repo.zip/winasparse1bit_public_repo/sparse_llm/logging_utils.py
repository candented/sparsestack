from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from .utils import ensure_dir, to_serializable


def build_run_name(prefix: str, suffix: str | None = None) -> str:
    timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    parts = [prefix]
    if suffix:
        safe_suffix = suffix.strip().replace(" ", "-").replace("/", "-").replace("\\", "-")
        if safe_suffix:
            parts.append(safe_suffix)
    parts.append(timestamp)
    return "_".join(parts)


def write_json_log(log_dir: Path | str, run_name: str, payload: Dict[str, Any]) -> Path:
    log_path = ensure_dir(log_dir) / f"{run_name}.json"
    serializable = {k: to_serializable(v) for k, v in payload.items()}
    with log_path.open("w", encoding="utf-8") as fh:
        json.dump(serializable, fh, indent=2, sort_keys=True)
    return log_path

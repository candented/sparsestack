from __future__ import annotations

import torch
import torch.nn as nn


class RotationalLinear(nn.Module):
    """
    Applies independent 2D rotations across paired dimensions with an optional subspace mask.
    """

    def __init__(self, dim: int, mask: torch.Tensor | None = None) -> None:
        super().__init__()
        if dim % 2 != 0:
            raise ValueError("RotationalLinear requires even dim")
        self.dim = dim
        self.num_subspaces = dim // 2
        init_angles = torch.zeros(self.num_subspaces)
        init_angles.normal_(mean=0.0, std=0.01)
        self.angles = nn.Parameter(init_angles)
        if mask is None:
            mask_tensor = torch.ones(self.num_subspaces)
        else:
            if mask.shape[0] != self.num_subspaces:
                raise ValueError("Mask length must equal dim/2")
            mask_tensor = mask.float()
        self.register_buffer("subspace_mask", mask_tensor)
        self.register_buffer("runtime_mask", torch.ones_like(mask_tensor))

    def apply_tau(self, tau: float) -> None:
        """
        Use tau as a fraction of subspaces to keep (by angle magnitude).
        """
        with torch.no_grad():
            tau = float(max(0.0, min(1.0, tau)))
            keep = max(1, int(round(tau * self.num_subspaces)))
            magnitudes = self.angles.abs()
            if keep >= self.num_subspaces:
                mask = torch.ones_like(self.runtime_mask)
            else:
                _, idx = torch.topk(magnitudes, k=keep)
                mask = torch.zeros_like(self.runtime_mask)
                mask[idx] = 1.0
            self.runtime_mask.copy_(mask)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.shape[-1] != self.dim:
            raise ValueError(f"Expected last dim {self.dim}, got {x.shape[-1]}")
        cos = torch.cos(self.angles).view(1, self.num_subspaces, 1)
        sin = torch.sin(self.angles).view(1, self.num_subspaces, 1)
        x_pairs = x.view(x.shape[0], self.num_subspaces, 2)
        x0 = x_pairs[..., 0:1]
        x1 = x_pairs[..., 1:2]
        rot0 = x0 * cos - x1 * sin
        rot1 = x0 * sin + x1 * cos
        rotated = torch.cat([rot0, rot1], dim=-1)
        mask = (self.subspace_mask * self.runtime_mask).view(1, self.num_subspaces, 1)
        out_pairs = x_pairs + mask * (rotated - x_pairs)
        return out_pairs.view(x.shape[0], self.dim)

    def active_fraction(self) -> float:
        with torch.no_grad():
            return float((self.subspace_mask * self.runtime_mask).mean().item())


class OctModel(nn.Module):
    """
    Minimal model for OCT tasks: rotational layer + linear projection.
    """

    def __init__(self, dim: int = 128, hidden_dim: int | None = None, mask: torch.Tensor | None = None) -> None:
        super().__init__()
        hidden = hidden_dim or dim
        self.oct_dim = dim
        self.rot = RotationalLinear(dim, mask=mask)
        self.head = nn.Linear(dim, hidden)
        self.out = nn.Linear(hidden, dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.rot(x)
        h = torch.tanh(self.head(h))
        return self.out(h)

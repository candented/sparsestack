from __future__ import annotations

from typing import Dict, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from .layers import LowBitLinear


def score_neurons(
    weight: torch.Tensor,
    activations: torch.Tensor,
    mode: str = "heuristic_v0",
    base_mask: torch.Tensor | None = None,
) -> torch.Tensor:
    """
    Compute per-neuron importance scores used by the sparse gating heuristic.
    """

    act_scores = activations.abs().mean(dim=0)
    weight_scores = weight.abs().mean(dim=1)
    if base_mask is not None:
        base_mask = base_mask.to(weight_scores.device, dtype=weight_scores.dtype)
    if mode in {"heuristic_v0", "wina_v0"}:
        scores = act_scores + weight_scores
        if base_mask is not None:
            scores = scores.masked_fill(base_mask == 0, float("-inf"))
        return scores
    if mode == "wina_v1":
        scores = act_scores * weight_scores
        if base_mask is not None:
            scores = scores.masked_fill(base_mask == 0, float("-inf"))
        return scores
    if mode == "wina_exact":
        with torch.no_grad():
            mask = base_mask if base_mask is not None else torch.ones_like(weight_scores)
            mask = mask.to(weight.device, dtype=weight.dtype)
            masked_weights = weight * mask.unsqueeze(1)
            weight_magnitude = masked_weights.pow(2).sum(dim=1).sqrt()
            activation_magnitude = activations.abs().mean(dim=0)
            scores = weight_magnitude * activation_magnitude + 1e-8
            scores = scores.masked_fill(mask == 0, float("-inf"))
            return scores
    raise ValueError(f"Unknown neuron scoring mode: {mode}")


def build_neuron_gate(
    scores: torch.Tensor,
    gate_mode: str,
    neuron_threshold: float,
    neuron_topk_fraction: float,
    base_mask: torch.Tensor | None = None,
) -> tuple[torch.Tensor, Dict[str, float]]:
    if scores.numel() == 0:
        raise RuntimeError("Neuron score tensor is empty")
    meta: Dict[str, float] = {}
    if base_mask is not None:
        base_mask = base_mask.to(scores.device, dtype=scores.dtype)
    total_neurons = int(base_mask.sum().item()) if base_mask is not None else scores.numel()
    total_neurons = max(1, total_neurons)
    if gate_mode == "none":
        gate = torch.ones_like(scores)
        if base_mask is not None:
            gate = gate * base_mask
        meta["active_neurons"] = float(total_neurons)
        meta["total_neurons"] = float(total_neurons)
        return gate, meta
    elif gate_mode == "topk":
        keep = max(1, int(round(total_neurons * neuron_topk_fraction)))
        keep = min(total_neurons, keep)
        gate = torch.zeros_like(scores)
        values, indices = torch.topk(scores, keep)
        gate.scatter_(0, indices, 1.0)
        if base_mask is not None:
            gate = gate * base_mask
        meta["gate_topk_kept"] = float(keep)
    elif gate_mode == "threshold":
        effective_scores = scores if base_mask is None else scores.masked_fill(base_mask == 0, float("-inf"))
        max_score = effective_scores.max()
        gate_threshold = max_score * neuron_threshold
        gate = (effective_scores > gate_threshold).float()
        if gate.sum() == 0:
            gate[torch.argmax(scores)] = 1.0
        meta["gate_threshold_value"] = gate_threshold.item()
    else:
        raise ValueError(f"Unknown gate_mode: {gate_mode}")
    meta["active_neurons"] = gate.sum().item()
    meta["total_neurons"] = float(total_neurons)
    return gate, meta


def summarize_score_stats(scores: torch.Tensor) -> Dict[str, float]:
    finite_mask = torch.isfinite(scores) & (scores > float("-inf"))
    if finite_mask.any():
        filtered = scores[finite_mask]
    else:
        filtered = torch.zeros(1, device=scores.device)
    stats: Dict[str, float] = {
        "mean": filtered.mean().item(),
        "std": filtered.std(unbiased=False).item(),
        "max": filtered.max().item(),
    }
    for quantile, name in zip([0.25, 0.5, 0.75, 0.9], ["p25", "p50", "p75", "p90"]):
        stats[name] = torch.quantile(filtered, quantile).item()
    return stats


class WINA_MLP(nn.Module):
    """
    Two-layer MLP that supports dense, circuit-masked, and full sparse modes.

    The "full sparse" path performs a tiny WINA-inspired neuron gating heuristic
    by disabling neurons whose average activation magnitude falls below
    *neuron_threshold*.
    """

    def __init__(
        self,
        in_features: int,
        hidden_features: int,
        out_features: int,
        quant_threshold: float = 0.05,
        gate_fc1: bool = True,
        gate_fc2: bool = False,
        gate_score_mode: str = "heuristic_v0",
    ):
        super().__init__()
        self.fc1 = LowBitLinear(
            in_features, hidden_features, bias=False, delta=quant_threshold
        )
        self.fc2 = LowBitLinear(
            hidden_features, out_features, bias=False, delta=quant_threshold
        )
        self.gate_fc1 = gate_fc1
        self.gate_fc2 = gate_fc2
        self.gate_score_mode = gate_score_mode

    def forward(
        self,
        x: torch.Tensor,
        mode: str = "dense",
        neuron_threshold: float = 0.1,
        gate_mode: str = "threshold",
        neuron_topk_fraction: float = 0.5,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        if mode == "dense":
            h = F.relu(F.linear(x, self.fc1.weight, self.fc1.bias))
            out = F.linear(h, self.fc2.weight, self.fc2.bias)
            log = {
                "mode": "dense",
                "active_neurons": h.shape[-1],
                "total_neurons": h.shape[-1],
            }
            return out, log

        if mode == "circuit_masked":
            h = F.relu(self.fc1(x))
            out = self.fc2(h)
            stats_fc1 = self.fc1.get_sparsity_stats()
            stats_fc2 = self.fc2.get_sparsity_stats()
            log = {
                "mode": "circuit_masked",
                "active_neurons": h.shape[-1],
                "total_neurons": h.shape[-1],
            }
            log.update({f"{k}_fc1": v for k, v in stats_fc1.items()})
            log.update({f"{k}_fc2": v for k, v in stats_fc2.items()})
            return out, log

        if mode == "full_sparse":
            fc1_dense = F.relu(self.fc1(x))
            score_mode = self.gate_score_mode

            fc1_base_mask = (self.fc1.circuit_mask.sum(dim=1) > 0).float().to(fc1_dense.device)
            fc1_scores = score_neurons(self.fc1.weight, fc1_dense, mode=score_mode, base_mask=fc1_base_mask)
            effective_gate_mode_fc1 = gate_mode if self.gate_fc1 else "none"
            neuron_gate_fc1, fc1_meta = build_neuron_gate(
                fc1_scores,
                effective_gate_mode_fc1,
                neuron_threshold,
                neuron_topk_fraction,
                base_mask=fc1_base_mask,
            )
            fc1_gated = fc1_dense * neuron_gate_fc1.unsqueeze(0)

            fc2_from_dense = self.fc2(fc1_dense)
            fc2_from_fc1_gated = self.fc2(fc1_gated)
            gating_l2_fc1 = torch.norm(fc2_from_dense - fc2_from_fc1_gated, dim=1).mean().item()

            fc2_base_mask = (self.fc2.circuit_mask.sum(dim=1) > 0).float().to(fc2_from_fc1_gated.device)
            fc2_scores = score_neurons(
                self.fc2.weight, fc2_from_fc1_gated, mode=score_mode, base_mask=fc2_base_mask
            )
            effective_gate_mode_fc2 = gate_mode if self.gate_fc2 else "none"
            neuron_gate_fc2, fc2_meta = build_neuron_gate(
                fc2_scores,
                effective_gate_mode_fc2,
                neuron_threshold,
                neuron_topk_fraction,
                base_mask=fc2_base_mask,
            )
            fc2_gated = fc2_from_fc1_gated * neuron_gate_fc2.unsqueeze(0)
            gating_l2_fc2 = torch.norm(fc2_from_fc1_gated - fc2_gated, dim=1).mean().item()

            if self.gate_fc1:
                assert torch.all(neuron_gate_fc1 <= fc1_base_mask + 1e-6), "fc1 gate activated masked neuron"
            if self.gate_fc2:
                assert torch.all(neuron_gate_fc2 <= fc2_base_mask + 1e-6), "fc2 gate activated masked neuron"

            fc1_stats = summarize_score_stats(fc1_scores)
            fc2_stats = summarize_score_stats(fc2_scores)

            log = {
                "mode": "full_sparse",
                "gate_mode": gate_mode,
                "gate_fc1_enabled": bool(self.gate_fc1),
                "gate_fc2_enabled": bool(self.gate_fc2),
                "active_neurons": fc1_meta["active_neurons"],
                "total_neurons": fc1_meta["total_neurons"],
                "active_neurons_fc1": fc1_meta["active_neurons"],
                "total_neurons_fc1": fc1_meta["total_neurons"],
                "active_neurons_fc2": fc2_meta["active_neurons"],
                "total_neurons_fc2": fc2_meta["total_neurons"],
                "gating_l2_diff": gating_l2_fc1,
                "gating_l2_diff_fc1": gating_l2_fc1,
                "gating_l2_diff_fc2": gating_l2_fc2,
                "gate_score_mean_fc1": fc1_stats["mean"],
                "gate_score_std_fc1": fc1_stats["std"],
                "gate_score_max_fc1": fc1_stats["max"],
                "gate_score_p25_fc1": fc1_stats["p25"],
                "gate_score_p50_fc1": fc1_stats["p50"],
                "gate_score_p75_fc1": fc1_stats["p75"],
                "gate_score_p90_fc1": fc1_stats["p90"],
                "gate_score_mode_fc1": score_mode,
                "gate_score_mean_fc2": fc2_stats["mean"],
                "gate_score_std_fc2": fc2_stats["std"],
                "gate_score_max_fc2": fc2_stats["max"],
                "gate_score_p25_fc2": fc2_stats["p25"],
                "gate_score_p50_fc2": fc2_stats["p50"],
                "gate_score_p75_fc2": fc2_stats["p75"],
                "gate_score_p90_fc2": fc2_stats["p90"],
                "gate_score_mode_fc2": score_mode,
            }
            if "gate_topk_kept" in fc1_meta:
                log["gate_topk_kept"] = fc1_meta["gate_topk_kept"]
                log["gate_topk_kept_fc1"] = fc1_meta["gate_topk_kept"]
            if "gate_threshold_value" in fc1_meta:
                log["gate_threshold_value"] = fc1_meta["gate_threshold_value"]
                log["gate_threshold_value_fc1"] = fc1_meta["gate_threshold_value"]
            if "gate_topk_kept" in fc2_meta:
                log["gate_topk_kept_fc2"] = fc2_meta["gate_topk_kept"]
            if "gate_threshold_value" in fc2_meta:
                log["gate_threshold_value_fc2"] = fc2_meta["gate_threshold_value"]
            stats_fc1 = self.fc1.get_sparsity_stats()
            stats_fc2 = self.fc2.get_sparsity_stats()
            log.update({f"{k}_fc1": v for k, v in stats_fc1.items()})
            log.update({f"{k}_fc2": v for k, v in stats_fc2.items()})
            return fc2_gated, log

        raise ValueError(f"Unknown mode: {mode}")

from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from .layers import LowBitLinear
from .mlp import WINA_MLP


class TinySelfAttention(nn.Module):
    """
    Self-attention built from LowBitLinear projections to keep tau/delta wiring consistent.
    """

    def __init__(self, dim: int, num_heads: int, quant_threshold: float = 0.05):
        super().__init__()
        if dim % num_heads != 0:
            raise ValueError("dim must be divisible by num_heads")
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim**-0.5
        self.q_proj = LowBitLinear(dim, dim, bias=False, delta=quant_threshold)
        self.k_proj = LowBitLinear(dim, dim, bias=False, delta=quant_threshold)
        self.v_proj = LowBitLinear(dim, dim, bias=False, delta=quant_threshold)
        self.out_proj = LowBitLinear(dim, dim, bias=False, delta=quant_threshold)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, float]]:
        bsz, seq_len, _ = x.shape
        q = self.q_proj(x).view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        attn_scores = torch.matmul(q, k.transpose(-1, -2)) * self.scale
        attn_probs = attn_scores.softmax(dim=-1)
        attn_out = torch.matmul(attn_probs, v)
        attn_out = attn_out.transpose(1, 2).reshape(bsz, seq_len, self.dim)
        out = self.out_proj(attn_out)
        log = {
            "attn_heads": float(self.num_heads),
            "attn_seq_len": float(seq_len),
            "attn_max_prob": float(attn_probs.max().item()),
        }
        return out, log


class TinyTransformerBlock(nn.Module):
    def __init__(
        self,
        dim: int,
        num_heads: int,
        mlp_hidden_dim: int,
        quant_threshold: float = 0.05,
        gate_fc1: bool = True,
        gate_fc2: bool = False,
        gate_score_mode: str = "heuristic_v0",
    ):
        super().__init__()
        self.attn = TinySelfAttention(dim=dim, num_heads=num_heads, quant_threshold=quant_threshold)
        self.norm1 = nn.LayerNorm(dim)
        self.mlp = WINA_MLP(
            dim,
            mlp_hidden_dim,
            dim,
            quant_threshold=quant_threshold,
            gate_fc1=gate_fc1,
            gate_fc2=gate_fc2,
            gate_score_mode=gate_score_mode,
        )
        self.norm2 = nn.LayerNorm(dim)

    def forward(
        self,
        x: torch.Tensor,
        mode: str = "dense",
        neuron_threshold: float = 0.1,
        gate_mode: str = "threshold",
        neuron_topk_fraction: float = 0.5,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        attn_out, attn_log = self.attn(x)
        x = self.norm1(x + attn_out)
        bsz, seq_len, dim = x.shape
        mlp_in = x.reshape(bsz * seq_len, dim)
        mlp_out, mlp_log = self.mlp(
            mlp_in,
            mode=mode,
            neuron_threshold=neuron_threshold,
            gate_mode=gate_mode,
            neuron_topk_fraction=neuron_topk_fraction,
        )
        mlp_out = mlp_out.view(bsz, seq_len, dim)
        x = self.norm2(x + mlp_out)
        log = dict(attn_log)
        log.update(mlp_log)
        return x, log


class TinyTransformer(nn.Module):
    """
    Compact transformer classifier with LowBitLinear attention/MLP and mean pooling.
    """

    def __init__(
        self,
        vocab_size: int,
        dim: int,
        num_heads: int,
        mlp_hidden_dim: int,
        num_classes: int,
        seq_len: int,
        quant_threshold: float = 0.05,
        gate_fc1: bool = True,
        gate_fc2: bool = False,
        gate_score_mode: str = "heuristic_v0",
        num_blocks: int = 2,
    ):
        super().__init__()
        if num_blocks <= 0:
            raise ValueError("num_blocks must be positive")
        self.dim = dim
        self.seq_len = seq_len
        self.token_emb = nn.Embedding(vocab_size, dim)
        self.pos_emb = nn.Parameter(torch.randn(1, seq_len, dim))
        self.blocks = nn.ModuleList(
            [
                TinyTransformerBlock(
                    dim=dim,
                    num_heads=num_heads,
                    mlp_hidden_dim=mlp_hidden_dim,
                    quant_threshold=quant_threshold,
                    gate_fc1=gate_fc1,
                    gate_fc2=gate_fc2,
                    gate_score_mode=gate_score_mode,
                )
                for _ in range(num_blocks)
            ]
        )
        self.head = LowBitLinear(dim, num_classes, bias=True, delta=quant_threshold)

    def _expand_topk_fraction(self, neuron_topk_fraction: float | Sequence[float] | None) -> List[float] | None:
        if neuron_topk_fraction is None:
            return None
        if isinstance(neuron_topk_fraction, (list, tuple)):
            if len(neuron_topk_fraction) != len(self.blocks):
                raise ValueError("Per-block neuron_topk_fraction length mismatch")
            return [float(val) for val in neuron_topk_fraction]
        return [float(neuron_topk_fraction) for _ in range(len(self.blocks))]

    def forward(
        self,
        x_idx: torch.Tensor,
        mode: str = "dense",
        neuron_threshold: float = 0.1,
        gate_mode: str = "threshold",
        neuron_topk_fraction: float | Sequence[float] = 0.5,
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        bsz, seq_len = x_idx.shape
        if seq_len > self.seq_len:
            raise ValueError(f"Sequence length {seq_len} exceeds model limit {self.seq_len}")
        x = self.token_emb(x_idx) + self.pos_emb[:, :seq_len, :]
        block_logs: List[Dict[str, float]] = []
        topk_schedule = self._expand_topk_fraction(neuron_topk_fraction)
        for idx, block in enumerate(self.blocks):
            current_topk = None if topk_schedule is None else topk_schedule[idx]
            x, block_log = block(
                x,
                mode=mode,
                neuron_threshold=neuron_threshold,
                gate_mode=gate_mode,
                neuron_topk_fraction=current_topk if current_topk is not None else neuron_topk_fraction,
            )
            block_logs.append(block_log)
        pooled = x.mean(dim=1)
        logits = self.head(pooled)
        combined_log = self._aggregate_block_logs(block_logs)
        combined_log["blocks"] = block_logs
        return logits, combined_log

    @staticmethod
    def _aggregate_block_logs(block_logs: List[Dict[str, float]]) -> Dict[str, float]:
        if not block_logs:
            return {}
        agg = dict(block_logs[-1])
        agg["num_blocks"] = float(len(block_logs))
        for field in ("gating_l2_diff", "gating_l2_diff_fc1", "gating_l2_diff_fc2"):
            agg[field] = sum(log.get(field, 0.0) for log in block_logs)
        return agg

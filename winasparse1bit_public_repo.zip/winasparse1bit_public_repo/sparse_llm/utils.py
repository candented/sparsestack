from __future__ import annotations

import os
import random
from pathlib import Path
from typing import Iterable

import numpy as np
import torch


def set_seed(seed: int) -> None:
    """
    Set random seeds across Python, NumPy, and Torch for reproducibility.

    Torch's deterministic flags slow things down, so callers can opt in if they
    need bitwise reproducibility.  Here we just set the generators.
    """

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def ensure_dir(path: Path | str) -> Path:
    """
    Create *path* if needed and return it as a Path object.
    """

    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def to_serializable(value):
    """
    Convert tensors and numpy scalars to built-in Python types for logging.
    """

    if isinstance(value, torch.Tensor):
        if value.ndim == 0:
            return value.item()
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, (list, tuple)):
        return [to_serializable(v) for v in value]
    if isinstance(value, dict):
        return {k: to_serializable(v) for k, v in value.items()}
    return value

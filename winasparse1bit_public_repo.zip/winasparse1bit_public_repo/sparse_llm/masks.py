from __future__ import annotations

import math
from typing import Tuple

import numpy as np
import torch


def topk_row_mask(weight: torch.Tensor, keep_fraction: float) -> Tuple[torch.Tensor, int, int]:
    """
    Build a binary mask that keeps the top |row| L1 norms, returning metadata.
    """

    if not 0 < keep_fraction <= 1:
        raise ValueError("keep_fraction must be in (0, 1]")
    num_rows = weight.shape[0]
    keep_rows = max(1, math.ceil(num_rows * keep_fraction))
    l1_norms = weight.detach().abs().sum(dim=1)
    top_indices = torch.topk(l1_norms, keep_rows).indices
    mask = torch.zeros_like(weight)
    mask[top_indices] = 1.0
    return mask, keep_rows, num_rows


def apply_learned_circuit(fc1: torch.Tensor, fc2: torch.Tensor, keep_fraction: float) -> Tuple[Tuple[torch.Tensor, int, int], Tuple[torch.Tensor, int, int]]:
    """
    Convenience helper that returns masks plus metadata for both fc1/fc2 matrices.
    """

    fc1_mask = topk_row_mask(fc1, keep_fraction)
    fc2_mask = topk_row_mask(fc2, keep_fraction)
    return fc1_mask, fc2_mask


def load_mask_from_npy(path: str, expected_shape: torch.Size) -> torch.Tensor:
    """
    Load a binary mask from a .npy file and validate its shape.
    """

    arr = np.load(path)
    mask = torch.from_numpy(arr).float()
    if mask.shape != expected_shape:
        raise ValueError(f"Mask {path} has shape {mask.shape}, expected {expected_shape}")
    mask = (mask > 0.5).float()
    return mask


def save_mask_to_npy(mask: torch.Tensor, path: str) -> None:
    np.save(path, mask.detach().cpu().numpy())

from __future__ import annotations

from typing import Dict

import torch
import torch.nn as nn
import torch.nn.functional as F


def ternary_quantize(weights: torch.Tensor, threshold: float = 0.05) -> torch.Tensor:
    """
    Quantize *weights* into {-1, 0, +1}.

    The *threshold* is interpreted as a factor applied to the mean absolute
    weight value, matching the "v3.1" refinement described in the notes.
    """

    if threshold <= 0:
        raise ValueError("threshold must be positive")
    scale = weights.abs().mean()
    thr = scale * threshold
    quantized = torch.zeros_like(weights)
    quantized[weights > thr] = 1.0
    quantized[weights < -thr] = -1.0
    return quantized


class LowBitLinear(nn.Linear):
    """
    Linear layer that applies a fixed connectivity mask and ternary precision.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        mask: torch.Tensor | None = None,
        delta: float = 0.05,
    ):
        if delta <= 0:
            raise ValueError("delta must be positive")
        super().__init__(in_features, out_features, bias=bias)
        if mask is None:
            mask_tensor = torch.ones_like(self.weight)
        else:
            if mask.shape != self.weight.shape:
                raise ValueError(
                    f"Mask shape {mask.shape} does not match weight shape {self.weight.shape}"
                )
            mask_tensor = mask.to(device=self.weight.device, dtype=self.weight.dtype)
        self.register_buffer("mask", mask_tensor)
        self.delta = float(delta)

    @property
    def circuit_mask(self) -> torch.Tensor:
        # Keep backward compatibility with older code paths.
        return self.mask

    @torch.no_grad()
    def set_circuit_mask(self, mask: torch.Tensor) -> None:
        if mask.shape != self.mask.shape:
            raise ValueError("Mask shape mismatch")
        self.mask.copy_(mask.to(device=self.mask.device, dtype=self.mask.dtype))

    @torch.no_grad()
    def reset_circuit_mask(self) -> None:
        self.mask.fill_(1.0)

    def get_effective_weight(self) -> torch.Tensor:
        w_latent = self.weight
        effective_mask = self.mask
        if hasattr(self, "runtime_mask"):
            effective_mask = effective_mask * self.runtime_mask
        w_masked = w_latent * effective_mask
        with torch.no_grad():
            w_ternary = torch.zeros_like(w_masked)
            w_ternary[w_masked > self.delta] = 1.0
            w_ternary[w_masked < -self.delta] = -1.0
            nz = (w_masked != 0).sum()
            denom = nz.clamp_min(1).to(w_masked.dtype)
            alpha = w_masked.abs().sum() / denom
            w_ternary_scaled = w_ternary * alpha
        w_eff = (w_ternary_scaled - w_masked).detach() + w_masked
        return w_eff

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        w_eff = self.get_effective_weight()
        return F.linear(x, w_eff, self.bias)

    def get_sparsity_stats(self) -> Dict[str, float]:
        """
        Report connectivity sparsity (structural + runtime) and precision sparsity on active edges.
        """
        with torch.no_grad():
            effective_mask = self.mask
            if hasattr(self, "runtime_mask"):
                effective_mask = effective_mask * self.runtime_mask
            connectivity_sparsity = 1.0 - effective_mask.float().mean().item()

            w_eff = self.get_effective_weight()
            active = effective_mask.bool()
            if active.any():
                zeros_on_active = (w_eff[active] == 0).float().mean().item()
            else:
                zeros_on_active = 0.0

        return {
            "connectivity_sparsity": connectivity_sparsity,
            "precision_sparsity": zeros_on_active,
        }
